package com.multicache4j.simplepool;

public interface Factory {
	public Object newInstance();
}
