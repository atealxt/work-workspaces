package com.multicache4j.simplepool;

public class MyFactory implements Factory {

	public Object newInstance() {
		return new Object();
	}

}
