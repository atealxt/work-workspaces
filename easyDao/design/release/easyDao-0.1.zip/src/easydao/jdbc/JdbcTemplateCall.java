package easydao.jdbc;

import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import easydao.utils.ConnectionUtils;

//TODO
public abstract class JdbcTemplateCall extends JdbcTemplate {

    private static Logger logger = Logger.getLogger(JdbcTemplateCall.class);
    private String sql;
    private Object[] param;
    private PreparedStatement pstmt;
    private ResultSet rs;

    public JdbcTemplateCall(String sql) {
        this.sql = sql;
    }

    public JdbcTemplateCall(String sql, Object... param) {
        this.sql = sql;
        this.param = param;
    }

    @Override
    protected void doConnect() throws SQLException {

        try {

            String procedureName = sql.substring(sql.indexOf("call") + 4, sql.indexOf("(")).trim();
            DatabaseMetaData meta = ConnectionUtils.getMetaData(getCon());
            rs = meta.getProcedures(null, null, procedureName);
            if (rs.next()) {

            }

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                logger.error(e.getMessage(), e);
            }
        }
    }

    private void setParam() throws SQLException {
        if (param != null) {
            int iCnt = 0;
            for (Object obj : param) {
                pstmt.setObject(++iCnt, obj);
            }
        }
    }

}
