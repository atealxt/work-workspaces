package easydao.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public abstract class JdbcTemplate {

    private static Logger logger = Logger.getLogger(JdbcTemplate.class);

    private Connector connector;
    private Connection con;

    protected JdbcTemplate() {
        this.connector = ConnectorDriverManager.getInstance();
    }

    protected JdbcTemplate(final Connector connector) {
        this.connector = connector;
    }

    public Connection getCon() {
        return con;
    }

    public void connect() {

        try {
            con = connector.getConnection();
            con.setAutoCommit(isAutoCommit());

            doConnect();

            if (!isAutoCommit()) {
                con.commit();
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (!isAutoCommit()) {
                try {
                    if (con != null) {
                        con.rollback();
                    }
                } catch (SQLException se) {
                    logger.error(se.getMessage(), se);
                }
            }
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                logger.error(e.getMessage(), e);
            }
        }
    }

    protected abstract void doConnect() throws SQLException;

    protected abstract boolean isAutoCommit();

}
