package easydao.jdbc;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.ResultSetMetaData;
import java.util.List;

import org.apache.log4j.Logger;

import easydao.utils.JpaUtils;
import easydao.utils.StringUtils;

public class JdbcTemplateSupport {

    private static Logger logger = Logger.getLogger(JdbcTemplateSupport.class);

    private JdbcTemplateSupport() {}

    private static JdbcTemplateSupport INSTANCE = new JdbcTemplateSupport();

    public static JdbcTemplateSupport getINSTANCE() {
        return INSTANCE;
    }

    public <T> T get(final Class<T> clazz, final String sql, final Object... param) {
        List<T> tList = getList(clazz, sql, param);
        if (tList.size() == 0) {
            return null;
        }
        return tList.get(0);
    }

    public <T> List<T> getList(final Class<T> clazz, final String sql, final Object... param) {
        JdbcTemplateResult jdbcTemplateResult = new JdbcTemplateResult(sql, param) {

            @Override
            protected void doResultSet() {

                try {
                    while (getResultSet().next()) {

                        // GenDTO
                        T t = clazz.newInstance();

                        String[] colms = null;
                        if (sql.indexOf("*") != -1) {
                            ResultSetMetaData metaData = getResultSet().getMetaData();
                            colms = new String[metaData.getColumnCount()];
                            for (int i = 0; i < colms.length; i++) {
                                colms[i] = metaData.getColumnName(i + 1);
                            }
                        } else {
                            int indexSelect = sql.indexOf("SELECT");
                            if (indexSelect == -1) {
                                indexSelect = sql.indexOf("select");
                            }
                            if (indexSelect == -1) {
                                indexSelect = 0;
                            }
                            int indexFrom = sql.indexOf("FROM");
                            if (indexFrom == -1) {
                                indexFrom = sql.indexOf("from");
                            }
                            colms = sql.substring(indexSelect + 6, indexFrom).split(",");
                        }

                        Field[] fs = clazz.getDeclaredFields();
                        for (int i = 0; i < colms.length; i++) {
                            String colm = colms[i].trim();

                            boolean hasSuitableField = false;
                            for (Field element : fs) {

                                if (colm.equalsIgnoreCase(JpaUtils.getColumnName(element))) {
                                    // by annotation
                                    Method setMethod = clazz.getDeclaredMethod("set"
                                            + StringUtils.getInitial(JpaUtils.getColumnName(element)), element
                                            .getType());
                                    setMethod.invoke(t, getResultSet().getObject(i + 1));
                                    hasSuitableField = true;
                                    break;
                                } else if (StringUtils.convertColm2Field(colm).equalsIgnoreCase(element.getName())) {
                                    // by field name
                                    Method setMethod = clazz.getDeclaredMethod("set"
                                            + StringUtils.getInitial(element.getName()), element.getType());
                                    setMethod.invoke(t, getResultSet().getObject(i + 1));
                                    hasSuitableField = true;
                                    break;
                                }
                            }
                            if (!hasSuitableField) {
                                logger.warn("No suitable field found in " + clazz.getName()//
                                        + "(DB colm: " + colm + ").");
                            }
                        }

                        getResults().add(t);
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        };
        jdbcTemplateResult.connect();
        @SuppressWarnings("unchecked") List<T> t = (List<T>) jdbcTemplateResult.getResults();
        return t;
    }

    protected int excute(final String sql, final Object... param) {
        JdbcTemplateResult jdbcTemplateResult = new JdbcTemplateResult(sql, param) {

            @Override
            protected void doResultSet() {}
        };
        jdbcTemplateResult.connect();
        return jdbcTemplateResult.getUpdateCount();
    }

    public int insert(final String sql, final Object... param) {
        return excute(sql, param);
    }

    public int update(final String sql, final Object... param) {
        return excute(sql, param);
    }

    public int delete(final String sql, final Object... param) {
        return excute(sql, param);
    }

    // TODO CallableStatement
    public Object callStatement() {

        return null;
    }

}
