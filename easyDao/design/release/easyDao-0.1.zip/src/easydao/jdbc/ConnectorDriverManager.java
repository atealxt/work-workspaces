package easydao.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import easydao.utils.PropertiesUtils;

public class ConnectorDriverManager implements Connector {

    private static Logger logger = Logger.getLogger(ConnectorDriverManager.class);
    private static final ConnectorDriverManager INSTANCE = new ConnectorDriverManager();
    private static String URL = PropertiesUtils.getValue("jdbc.url");
    private static String USERNAME = PropertiesUtils.getValue("jdbc.username");
    private static String PASSWORD = PropertiesUtils.getValue("jdbc.password");

    static {
        try {
            Class.forName(PropertiesUtils.getValue("jdbc.driverClassName"));//.newInstance();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private ConnectorDriverManager() {}

    public static Connector getInstance() {
        return INSTANCE;
    }

    @Override
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
