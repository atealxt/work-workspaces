package easydao.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public abstract class JdbcTemplateResult extends JdbcTemplate {

    private static Logger logger = Logger.getLogger(JdbcTemplateResult.class);
    private String sql;
    private Object[] param;
    private PreparedStatement pstmt;
    private ResultSet rs;
    private List<Object> results = new ArrayList<Object>(0);
    private int updateCount;

    public JdbcTemplateResult(final String sql) {
        this.sql = sql;
    }

    public JdbcTemplateResult(final String sql, final Object... param) {
        this.sql = sql;
        this.param = param;
    }

    @Override
    protected void doConnect() throws SQLException {

        try {
            pstmt = getCon().prepareStatement(sql);
            setParam();
            logger.info(sql);

            pstmt.execute();
            rs = pstmt.getResultSet();
            updateCount = pstmt.getUpdateCount();

            doResultSet();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                logger.error(e.getMessage(), e);
            }
        }
    }

    private void setParam() throws SQLException {
        if (param != null) {
            int iCnt = 0;
            for (Object obj : param) {
                pstmt.setObject(++iCnt, obj);
            }
        }
    }

    protected abstract void doResultSet();

    protected ResultSet getResultSet() {
        return rs;
    }

    public List<Object> getResults() {
        return results;
    }

    public int getUpdateCount() {
        return updateCount;
    }

    @Override
    protected boolean isAutoCommit() {
        // TODO Auto-generated method stub
        return false;
    }

}
