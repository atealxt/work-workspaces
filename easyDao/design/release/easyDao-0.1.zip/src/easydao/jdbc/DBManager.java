package easydao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import easydao.utils.PropertiesUtils;

public class DBManager {

    private static Logger logger = Logger.getLogger(DBManager.class);

    private static ThreadLocal<Connection> CONNECTIONS = new ThreadLocal<Connection>();

    /** 是否在每次执行完SQL后自动关闭连接。如果为否，需要手动调用closeConnection() */
    private static boolean AUTO_CLOSE_CONNECTION;

    /** 是否输出SQL日志 */
    private static boolean SHOW_SQL;

    static {
        if ("true".equals(PropertiesUtils.getValue("jdbc.showSQL"))) {
            SHOW_SQL = true;
        }
        if ("true".equals(PropertiesUtils.getValue("jdbc.autoCloseConnection"))) {
            AUTO_CLOSE_CONNECTION = true;
        }
    }

    private DBManager() {}

    public static void beginTransaction() {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                conn.setAutoCommit(false);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage(), e);
        }
    }

    public static void commitTransaction() {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                conn.commit();
            }
        } catch (SQLException e) {
            logger.error(e.getMessage(), e);
        }
    }

    public static void rollbackTransaction() {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                conn.rollback();
            }
        } catch (SQLException e) {
            logger.error(e.getMessage(), e);
        }
    }

    public static Connection getConnection() {
        Connection conn = CONNECTIONS.get();
        try {
            if (conn == null || conn.isClosed()) {
                conn = ConnectorDriverManager.getInstance().getConnection();
                conn.setAutoCommit(true);
                CONNECTIONS.set(conn);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage(), e);
        }
        return conn;
    }

    public static void closeConnection() {
        Connection conn = CONNECTIONS.get();
        if (conn != null) {
            CONNECTIONS.set(null);
            try {
                if (!conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                logger.error(e.getMessage(), e);
            }
        }
    }

    public static void execute(final String sql) throws SQLException {
        execute(sql, null);
    }

    public static void execute(final String sql, final List<Object> params) throws SQLException {

        log(sql, params);
        PreparedStatement pstmt = null;
        try {
            pstmt = getConnection().prepareStatement(sql);
            if (params != null) {
                for (int parameterIndex = 0; parameterIndex < params.size(); parameterIndex++) {
                    pstmt.setObject(parameterIndex + 1, params.get(parameterIndex));
                }
            }
            pstmt.execute();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                logger.error(e.getMessage(), e);
            }
            if (AUTO_CLOSE_CONNECTION) {
                autoCloseConn();
            }
        }
    }

    public static List<Map<String, Object>> query(final String sql) throws SQLException {
        return query(sql, null);
    }

    public static List<Map<String, Object>> query(final String sql, final List<Object> params) throws SQLException {

        log(sql, params);
        List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = getConnection().prepareStatement(sql);
            if (params != null) {
                for (int parameterIndex = 0; parameterIndex < params.size(); parameterIndex++) {
                    pstmt.setObject(parameterIndex + 1, params.get(parameterIndex));
                }
            }

            rs = pstmt.executeQuery();
            int columnCount = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                Map<String, Object> keyvalue = new HashMap<String, Object>();
                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    Object value = rs.getObject(columnIndex);
                    String key = rs.getMetaData().getColumnName(columnIndex);
                    keyvalue.put(key, value);
                }
                data.add(keyvalue);
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                logger.error(e.getMessage(), e);
            }
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                logger.error(e.getMessage(), e);
            }
            if (AUTO_CLOSE_CONNECTION) {
                autoCloseConn();
            }
        }
        return data;
    }

    /** 如果AutoCommit=false，则<b><i>不</i></b>关闭 */
    private static void autoCloseConn() {

        Connection conn = CONNECTIONS.get();
        if (conn != null) {
            try {
                if (conn.getAutoCommit() && !conn.isClosed()) {
                    conn.close();
                    CONNECTIONS.set(null);
                }
            } catch (SQLException e) {
                logger.error(e.getMessage(), e);
            }
        }
    }

    private static void log(final String sql, final List<Object> params) {

        if (SHOW_SQL) {
            logger.debug("Execute SQL: " + sql);
            if (params != null) {
                logger.debug("Paramters: " + params);
            }
        }
    }

}
