package easydao.jpa;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.log4j.Logger;

import easydao.jdbc.JdbcTemplateSupport;
import easydao.utils.JpaUtils;

public class JpaTemplate {

    private static Logger logger = Logger.getLogger(JpaTemplate.class);

    public <T> T get(final Class<T> clazz, final Serializable id) {

        StringBuilder sql = new StringBuilder("select ");

        Field[] fs = clazz.getDeclaredFields();
        for (int i = 0; i < fs.length; i++) {
            if (JpaUtils.getColumnName(fs[i]) != null) {
                sql.append(JpaUtils.getColumnName(fs[i]));
            } else {
                sql.append(fs[i].getName());
            }

            if (i < fs.length - 1) {
                sql.append(", ");
            }
        }

        sql.append(" from ");

        Table annoTable = clazz.getAnnotation(Table.class);
        String catalog = annoTable.catalog();
        sql.append(catalog);
        sql.append(".");
        sql.append(annoTable.name());
        sql.append(" where ");
        sql.append(annoTable.name());
        sql.append(".");

        for (Field f : clazz.getDeclaredFields()) {
            if (f.getAnnotation(Id.class) != null) {
                if (JpaUtils.getColumnName(f) != null) {
                    sql.append(JpaUtils.getColumnName(f));
                } else {
                    sql.append(f.getName());
                }
                break;
            }
        }
        sql.append(" = ?");

        // call jdbc module, excute native sql
        return JdbcTemplateSupport.getINSTANCE().get(clazz, sql.toString(), id);
    }

    public <T> void save(final T t) {

        StringBuilder sql = new StringBuilder("insert into ");

        Table annoTable = t.getClass().getAnnotation(Table.class);
        String catalog = annoTable.catalog();
        sql.append(catalog);
        sql.append(".");
        sql.append(annoTable.name());

        sql.append(" (");

        StringBuilder colms = new StringBuilder();
        StringBuilder colmsQuestion = new StringBuilder();
        List<Object> colmsValue = new ArrayList<Object>();
        Field[] fs = t.getClass().getDeclaredFields();
        for (int i = 0; i < fs.length; i++) {// TODO 优化逻辑

            if (fs[i].getAnnotation(Id.class) != null) {
                GeneratedValue genId = fs[i].getAnnotation(GeneratedValue.class);
                if (genId != null) {
                    if (!GenerationType.AUTO.equals(genId.strategy())) {
                        throw new UnsupportedOperationException("Unsupported GenerationType: " + genId.strategy());
                    }
                } else {
                    if (JpaUtils.getColumnName(fs[i]) != null) {
                        colms.append(JpaUtils.getColumnName(fs[i]));
                    } else {
                        colms.append(fs[i].getName());
                    }
                    colmsQuestion.append("?");
                    try {
                        fs[i].setAccessible(true);
                        colmsValue.add(fs[i].get(t));
                    } catch (IllegalArgumentException e) {
                        logger.error(e.getMessage(),e);
                    } catch (IllegalAccessException e) {
                        logger.error(e.getMessage(),e);
                    }

                    if (i < fs.length - 1) {
                        colms.append(", ");
                        colmsQuestion.append(", ");
                    }
                }
            } else {
                if (JpaUtils.getColumnName(fs[i]) != null) {
                    colms.append(JpaUtils.getColumnName(fs[i]));
                } else {
                    colms.append(fs[i].getName());
                }
                colmsQuestion.append("?");
                try {
                    fs[i].setAccessible(true);
                    colmsValue.add(fs[i].get(t));
                } catch (IllegalArgumentException e) {
                    logger.error(e.getMessage(),e);
                } catch (IllegalAccessException e) {
                    logger.error(e.getMessage(),e);
                }

                if (i < fs.length - 1) {
                    colms.append(", ");
                    colmsQuestion.append(", ");
                }
            }
        }

        sql.append(colms);
        sql.append(") values");
        sql.append(" (");
        sql.append(colmsQuestion);
        sql.append(");");

        // call jdbc module, excute native sql
        JdbcTemplateSupport.getINSTANCE().insert(sql.toString(), colmsValue.toArray());

        //TODO 保存之后，取得主键的值
    }

}
