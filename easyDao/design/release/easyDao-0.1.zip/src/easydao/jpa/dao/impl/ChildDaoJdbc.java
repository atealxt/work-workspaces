package easydao.jpa.dao.impl;

import easydao.jpa.JpaTemplate;
import easydao.jpa.dao.ChildDao;
import easydao.jpa.entity.Child;

public class ChildDaoJdbc implements ChildDao {

    private JpaTemplate jpaTemplate;

    @Override
    public Child findById(Integer id) {
        return jpaTemplate.get(Child.class, id);
    }

}
