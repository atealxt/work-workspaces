package easydao.jpa.dao;

import easydao.jpa.entity.Child;

public interface ChildDao {

    Child findById(Integer id);

}
