package easydao.dbutils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.log4j.Logger;

import easydao.jdbc.ConnectorDriverManager;

public final class DBUtils {

    private static Logger logger = Logger.getLogger(DBUtils.class.getName());
    public static final String POOL_NAME = "user_source";


    public static <T> T querySingle(final Class<T> clazz, final String sql, final Object... params) throws SQLException {

        ResultSetHandler<T> handler = new BeanHandler(clazz);

        QueryRunner run = new QueryRunner(true);

        T t = null;
        Connection connection = null;
        try {
            connection = ConnectorDriverManager.getInstance().getConnection(); // open a connection
            logger.debug(sql);
            t = run.query(connection, sql, handler, params);
        } finally {
            DbUtils.close(connection);
        }
        return t;
    }

    public static <T> List<T> queryList(final Class<T> clazz, final String sql, final Object... params)
            throws SQLException {

        ResultSetHandler<List<T>> handler = new BeanListHandler(clazz);

        QueryRunner run = new QueryRunner();

        List<T> tList = null;
        Connection connection = null;
        try {
            connection = ConnectorDriverManager.getInstance().getConnection(); // open a connection
            logger.debug(sql);
            tList = run.query(connection, sql, handler, params);
        } finally {
            DbUtils.close(connection);
        }
        return tList;
    }

    private final static ResultSetHandler<Object[]> HANDEL = new ResultSetHandler<Object[]>() {

        public Object[] handle(final ResultSet rs) throws SQLException {
            if (!rs.next()) {
                return null;
            }

            ResultSetMetaData meta = rs.getMetaData();
            int cols = meta.getColumnCount();
            Object[] result = new Object[cols];

            for (int i = 0; i < cols; i++) {
                result[i] = rs.getObject(i + 1);
            }

            return result;
        }
    };

    public static int count(final String sql, final Object... params) throws SQLException {

        QueryRunner run = new QueryRunner(true);

        Connection connection = null;
        Object[] result = null;
        try {
            connection = ConnectorDriverManager.getInstance().getConnection(); // open a connection
            logger.debug(sql);
            result = run.query(connection, sql, HANDEL, params);
        } finally {
            DbUtils.close(connection);
        }

        return Integer.parseInt(result[0].toString());
    }
}