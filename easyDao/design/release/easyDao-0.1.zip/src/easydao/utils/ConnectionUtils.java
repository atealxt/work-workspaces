package easydao.utils;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.Logger;

public final class ConnectionUtils {

    private static Logger logger = Logger.getLogger(ConnectionUtils.class);

    private transient final static ReentrantLock lock = new ReentrantLock();
    private static Connection currentConnection;// TODO 缓存效果有限:P
    private static DatabaseMetaData currentMeta;

    private ConnectionUtils() {}

    public static DatabaseMetaData getMetaData(Connection con) {

        if (currentConnection != null && currentConnection.equals(con)) {
            return currentMeta;
        }

        final ReentrantLock localLock = lock;
        localLock.lock();
        try {
            currentMeta = con.getMetaData();
        } catch (SQLException e) {
            logger.error(e.getMessage(), e);
            return null;
        }
        localLock.unlock();

        return currentMeta;
    }
}
