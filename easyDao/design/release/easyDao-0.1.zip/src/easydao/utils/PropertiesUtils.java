package easydao.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public final class PropertiesUtils {

    private static Logger logger = Logger.getLogger(PropertiesUtils.class);
    private static Properties properties = new Properties();

    public static void load(String file) throws FileNotFoundException, IOException {
        String baseDir = PropertiesUtils.class.getResource("/").getPath();
        properties.load(new FileInputStream(new File(baseDir.concat(file))));
    }

    static {
        try {
            PropertiesUtils.load("/jdbc.properties");
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    public static String getValue(String key) {
        return properties.getProperty(key);
    }

    /** 如果取值为空，则装载指定文件后再做一次取值 */
    public static String getValue(String key, String fileName) {
        String value = getValue(key);
        if (value != null) {
            return value;
        }
        try {
            load(fileName);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return getValue(key);
    }

}
