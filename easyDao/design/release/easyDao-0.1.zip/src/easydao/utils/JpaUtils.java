package easydao.utils;

import java.lang.reflect.Field;

import javax.persistence.Column;

public final class JpaUtils {

    public static String getColumnName(Field field) {
        Column annoColumn = field.getAnnotation(Column.class);
        if (annoColumn == null) {
            return null;
        }
        return annoColumn.name();
    }

}
