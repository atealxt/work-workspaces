package easydao.utils;

public final class StringUtils {

    public static boolean isEmpty(String str) {
        return isEmpty(str, false);
    }

    public static boolean isEmpty(String str, boolean trim) {
        if (str == null) {
            return true;
        } else if ("".equals(str)) {
            return true;
        } else if (trim && "".equals(str.trim())) {
            return true;
        }
        return false;
    }

    /** 取得首字母大写的字符串 */
    public static String getInitial(String src) {
        if (isEmpty(src)) {
            return src;
        }
        return src.substring(0, 1).toUpperCase() + src.substring(1);
    }

    /** 取得DB COLM在java bean中的规范表示形式 */
    public static String convertColm2Field(String src) {
        if (isEmpty(src)) {
            return src;
        }
        String[] sSplitBy_ = src.split("_");
        StringBuilder sb = new StringBuilder(sSplitBy_[0].toLowerCase());
        for (int i = 1; i < sSplitBy_.length; i++) {
            sb.append(getInitial(sSplitBy_[i].toLowerCase()));
        }
        return sb.toString();
    }

}
