package easydao.test.jdbc;

import org.junit.Assert;
import org.junit.Test;

import easydao.jdbc.JdbcTemplateSupport;
import easydao.jpa.entity.Child;
import easydao.test.core.TestBase;

public class JdbcTemplateSupportTest extends TestBase {

    public void excute() throws Exception {

        // normal CRUD
        Assert.assertEquals(JdbcTemplateSupport.getINSTANCE()//
                .insert("insert child(name) values (?)", "haha"), 1);

        System.out.println(JdbcTemplateSupport.getINSTANCE().getList(Child.class, "select name from child"));

        Assert.assertEquals(JdbcTemplateSupport.getINSTANCE()//
                .update("update child set name = ? where name = ?", "hoho", "haha"), 1);

        System.out.println(JdbcTemplateSupport.getINSTANCE().get(Child.class, "select * from child where name = ?",
                                                                 "hoho"));

        Assert.assertEquals(JdbcTemplateSupport.getINSTANCE()//
                .delete("delete from child where name = ?", "hoho"), 1);

        System.out.println(JdbcTemplateSupport.getINSTANCE().getList(Child.class, "select * from child"));
    }

    @Test
    public void exception() {

        // No such field warning
        System.out.println(JdbcTemplateSupport.getINSTANCE().getList(Child.class, "select father_id from child"));
    }

}
