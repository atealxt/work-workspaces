package easydao.test.jdbc;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import easydao.jdbc.DBManager;

public class DBManagerTest {

    @Test
    public void testGetConnection() {
        Assert.assertNotNull(DBManager.getConnection());
    }

    @Test
    public void testCloseConnection() {
        DBManager.closeConnection();
    }

    @Test
    public void testExecuteString() {
        try {
            DBManager.execute("update child set name = 'testdatachange1' where name = 'testdata1'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testExecuteStringListOfObject() {
        try {
            DBManager.execute("update child set name = 'testdatachange2' where name = ?",//
                              Arrays.asList((Object) "testdata2"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testQueryString() {
        try {
            List<Map<String, Object>> list = DBManager.query("select * from child");
            Assert.assertTrue(list.size() > 0);
            System.out.println(list);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testQueryStringListOfObject() {
        try {
            List<Map<String, Object>> list = DBManager.query("select * from child where name = ?",//
                                                             Arrays.asList((Object) "jerry"));
            Assert.assertTrue(list.size() > 0);
            System.out.println(list);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testWithTransactionOK() {

        DBManager.beginTransaction();
        try {

            DBManager.execute("update child set name = 'testdatachange3' where name = ?",//
                              Arrays.asList((Object) "testdata3"));

            List<Map<String, Object>> list = DBManager.query("select * from child where name = ?",//
                                                             Arrays.asList((Object) "testdatachange3"));
            Assert.assertTrue(list.size() > 0);

            DBManager.commitTransaction();
        } catch (SQLException e) {
            DBManager.rollbackTransaction();
        }
        DBManager.closeConnection();
    }

    @Test
    public void testWithTransactionError() {

        DBManager.beginTransaction();
        try {

            DBManager.execute("update child set name = 'testdatachange4' where name = ?",//
                              Arrays.asList((Object) "testdata4"));

            List<Map<String, Object>> list = DBManager.query("select * from child where name = ?",//
                                                             Arrays.asList((Object) "testdatachange4"));
            Assert.assertTrue(list.size() > 0);

            list = DBManager.query("select * from no_this_table");//invoke error

            DBManager.commitTransaction();
        } catch (SQLException e) {
            DBManager.rollbackTransaction();
        }
        DBManager.closeConnection();

        try {
            List<Map<String, Object>> list = DBManager.query("select * from child where name = ?",//
                                                             Arrays.asList((Object) "testdatachange4"));
            Assert.assertTrue(list.size() == 0);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testWithoutTransaction() {

        try {
            DBManager.execute("update child set name = 'testdatachange5' where name = ?",//
                              Arrays.asList((Object) "testdata5"));

            List<Map<String, Object>> list = DBManager.query("select * from child where name = ?",//
                                                             Arrays.asList((Object) "testdatachange5"));
            Assert.assertTrue(list.size() > 0);

            DBManager.query("select * from no_this_table");
        } catch (SQLException e) {
        }

        try {
            List<Map<String, Object>> list = DBManager.query("select * from child where name = ?",//
                                                             Arrays.asList((Object) "testdatachange5"));
            Assert.assertTrue(list.size() > 0);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
