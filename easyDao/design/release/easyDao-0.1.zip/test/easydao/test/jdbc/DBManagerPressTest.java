package easydao.test.jdbc;

import easydao.test.core.TestBase;

public class DBManagerPressTest extends TestBase {

    @Override
    public void excute() throws Exception {

        newPress();
        newPress();
        newPress();
    }

    private void newPress() {
        // TODO Auto-generated method stub

    }

}
