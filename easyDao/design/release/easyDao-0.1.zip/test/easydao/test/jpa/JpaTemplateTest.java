package easydao.test.jpa;

import org.junit.Test;

import easydao.jpa.JpaTemplate;
import easydao.jpa.entity.Child;
import easydao.test.core.TestBase;

public class JpaTemplateTest extends TestBase {

    @Override
    public void excute() throws Exception {

        JpaTemplate template = new JpaTemplate();
        logger.debug(template.get(Child.class, 1));
    }

    @Test
    public void CRUD() throws Exception {

        Child c = new Child();
        c.setName("aaa");

        JpaTemplate template = new JpaTemplate();
        template.save(c);
    }

}
