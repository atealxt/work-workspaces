package easydao.test.dbutils;

import java.sql.SQLException;

import easydao.dbutils.DBUtils;
import easydao.dbutils.Template;
import easydao.test.core.TestBase;

public class BeanHandlerTest extends TestBase {

    @Override
    public void excute() throws Exception {
        single();
        list();
    }

    private void single() throws Exception {

//        Child child = DBUtils.querySingle(Child.class, "select * from child where name = ?", "jerry");
//        System.out.println(child);
        System.out.println(DBUtils.querySingle(Template.class, "select * from t_template where name like ?","a"));
        System.out.println(DBUtils.count("select count(*) from t_template where 1=1"));
    }

    private void list() throws SQLException {

//        List<Child> children = DBUtils.queryList(Child.class, "select * from child");
//        System.out.println(children);

    }

}
