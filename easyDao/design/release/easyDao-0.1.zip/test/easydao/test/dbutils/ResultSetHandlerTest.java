package easydao.test.dbutils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;

import easydao.jdbc.ConnectorDriverManager;
import easydao.test.core.TestBase;

public class ResultSetHandlerTest extends TestBase {

    @Override
    public void excute() throws Exception {

        ResultSetHandler<List<Map<String, Object>>> handler = new ResultSetHandler<List<Map<String, Object>>>() {

            public List<Map<String, Object>> handle(final ResultSet rs) throws SQLException {

                List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
                int columnCount = rs.getMetaData().getColumnCount();
                while (rs.next()) {
                    Map<String, Object> keyvalue = new HashMap<String, Object>();
                    for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                        Object value = rs.getObject(columnIndex);
                        String key = rs.getMetaData().getColumnName(columnIndex);
                        keyvalue.put(key, value);
                    }
                    data.add(keyvalue);
                }

                return data;
            }
        };

        // No DataSource so we must handle Connections manually
        QueryRunner run = new QueryRunner();

        Connection conn = ConnectorDriverManager.getInstance().getConnection(); // open a connection
        try {
            List<Map<String, Object>> result = run.query(conn, "select * from child", handler);
            // do something with the result

            System.out.println(result);
        } finally {
            // Use this helper method so we don't have to check for null
            DbUtils.close(conn);
        }

    }
}
