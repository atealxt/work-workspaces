package easydao.test.utils;

import junit.framework.Assert;

import org.junit.Test;

import easydao.utils.StringUtils;

public class StringUtilsTest {

    @Test
    public void testConvertColm2Field() {
        Assert.assertEquals("twoBadBoys", StringUtils.convertColm2Field("TWO_BAD_BOYS"));
    }
}
