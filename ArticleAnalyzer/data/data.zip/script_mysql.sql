# --------------------------------------------------------
# Host:                         127.0.0.1
# Server version:               5.0.27-community-nt
# Server OS:                    Win32
# HeidiSQL version:             6.0.0.3603
# Date/time:                    2011-02-19 21:29:27
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

# Dumping database structure for article_analyzer
CREATE DATABASE IF NOT EXISTS `article_analyzer` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `article_analyzer`;

# Dumping structure for table article_analyzer.article_type
CREATE TABLE IF NOT EXISTS `article_type` (
  `ID` smallint(6) NOT NULL auto_increment,
  `NAME` varchar(50) default NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

# Dumping structure for table article_analyzer.article_keyword
CREATE TABLE IF NOT EXISTS `article_keyword` (
  `ID` int(10) NOT NULL auto_increment,
  `type` smallint(6) NOT NULL,
  `keyword` varchar(100) default NULL,
  `weight` double(10,4) default NULL COMMENT '单词平均权重',
  PRIMARY KEY  (`ID`),
  KEY `FK_article_keyword_article_type` (`type`),
  CONSTRAINT `FK_article_keyword_article_type` FOREIGN KEY (`type`) REFERENCES `article_type` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
