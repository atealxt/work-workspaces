package minademo.stream;

import java.net.InetSocketAddress;

import minademo.Constants;

import org.apache.mina.common.ConnectFuture;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.serialization.ObjectSerializationCodecFactory;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;
import org.apache.mina.transport.socket.nio.SocketConnector;

public class StreamClient {

    public void sendFile() {

        SocketConnector connector = new SocketConnector();
        connector.setWorkerTimeout(5); // 5秒钟（默认超时60秒）

        SocketAcceptorConfig cfg = new SocketAcceptorConfig();
        ObjectSerializationCodecFactory factory = new ObjectSerializationCodecFactory();
        factory.setDecoderMaxObjectSize(Integer.MAX_VALUE);
        factory.setEncoderMaxObjectSize(Integer.MAX_VALUE);
        cfg.getFilterChain().addLast("codec", new ProtocolCodecFilter(factory));

        ConnectFuture future = connector.connect(new InetSocketAddress(Constants.ADDRESS_SERVER_FILE,
                                                                       Constants.PORT_FILE),
                                                 new StreamSendHandler(Constants.TEST_FILE_FROM), cfg);

        // Wait for the asynchronous operation to end.
        future.join();
    }

    public static void main(final String[] args) {
        new StreamClient().sendFile();
    }
}