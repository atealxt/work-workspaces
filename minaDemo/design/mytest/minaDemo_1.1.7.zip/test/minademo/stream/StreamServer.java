package minademo.stream;

import java.io.IOException;
import java.net.InetSocketAddress;

import minademo.Constants;

import org.apache.log4j.Logger;
import org.apache.mina.common.IoAcceptor;
import org.apache.mina.common.IoAcceptorConfig;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;

public class StreamServer {

    private static Logger logger = Logger.getLogger(StreamServer.class.getName());

    public void listen() throws IOException {

        IoAcceptor acceptor = new SocketAcceptor();
        IoAcceptorConfig cfg = new SocketAcceptorConfig();

        // 不能写这几句话，否则Server死锁..
//         ObjectSerializationCodecFactory factory = new ObjectSerializationCodecFactory();
        // factory.setDecoderMaxObjectSize(Integer.MAX_VALUE);
        // factory.setEncoderMaxObjectSize(Integer.MAX_VALUE);
//         cfg.getFilterChain().addLast("codec", new ProtocolCodecFilter(factory));

        acceptor.bind(new InetSocketAddress(Constants.ADDRESS_SERVER_FILE, Constants.PORT_FILE),
                      new StreamReceiveHandler(Constants.TEST_FILE_TO), cfg);
    }

    public static void main(final String[] args) throws IOException {
        new StreamServer().listen();
        logger.debug("File server started.");
    }
}
