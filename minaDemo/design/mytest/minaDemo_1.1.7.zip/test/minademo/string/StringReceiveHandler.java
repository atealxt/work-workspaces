package minademo.string;

import java.util.Date;

import org.apache.mina.common.IdleStatus;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.TransportType;
import org.apache.mina.transport.socket.nio.SocketSessionConfig;

public class StringReceiveHandler extends IoHandlerAdapter {

    @Override
    public void messageReceived(final IoSession session, final Object msg) throws Exception {

        System.out.println("messageReceived: " + msg);

        Date date = new Date();
        session.write(date.toString());
        System.out.println("Message written...");
    }

    @Override
    public void sessionCreated(final IoSession session) throws Exception {
        System.out.println("Session created...");

        if (session.getTransportType() == TransportType.SOCKET) {
            ((SocketSessionConfig) session.getConfig()).setReceiveBufferSize(2048);
        }

        //Idle time settings are all disabled by default
        session.setIdleTime(IdleStatus.READER_IDLE, 10);//seconds
//        session.getConfig().setIdleTime(IdleStatus.BOTH_IDLE, 10);
    }


    /**
     * 当连接空闲时被触发。使用IoSessionConfig中的setIdleTime(IdleStatus status, int idleTime)方法可以设置session的空闲时间。如果该Session的空闲时间超过设置的值，该方法被触发，可以通过 session.getIdleCount(status)来获取sessionIdle被触发的次数。(类似心跳)
     */
    @Override
    public void sessionIdle(final IoSession session, final IdleStatus status) throws Exception {

        System.out.println(status);//TODO 有错，测试不成功
        super.sessionIdle(session, status);
    }

    @Override
    public void exceptionCaught(final IoSession session, final Throwable t) throws Exception {
        t.printStackTrace();
        session.close();
    }
}
