package minademo.string;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.Charset;

import minademo.Constants;

import org.apache.mina.common.ByteBuffer;
import org.apache.mina.common.IoAcceptor;
import org.apache.mina.common.SimpleByteBufferAllocator;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;

/**
 * 测试1. "telnet 127.0.0.1 9123" （注意Windows下中文默认编码为GB2312）<br>
 * 测试2. "java SocketClient"
 */
public class StringServer {

    public void listen() throws IOException {

        ByteBuffer.setUseDirectBuffers(false);
        ByteBuffer.setAllocator(new SimpleByteBufferAllocator());

        IoAcceptor acceptor = new SocketAcceptor();

        SocketAcceptorConfig cfg = new SocketAcceptorConfig();
        // cfg.getFilterChain().addLast("logger", new LoggingFilter());
        TextLineCodecFactory textLineCodecFactory = new TextLineCodecFactory(Charset.forName("UTF-8"));
        cfg.getFilterChain().addLast("codec", new ProtocolCodecFilter(textLineCodecFactory));

        acceptor.bind(new InetSocketAddress(Constants.PORT), new StringReceiveHandler(), cfg);
        System.out.println("String server started.");
    }

    public static void main(final String[] args) throws IOException {
        new StringServer().listen();
    }
}
