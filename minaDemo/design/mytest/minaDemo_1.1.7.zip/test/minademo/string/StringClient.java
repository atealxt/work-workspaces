package minademo.string;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.Charset;

import minademo.Constants;

import org.apache.mina.common.ConnectFuture;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;
import org.apache.mina.transport.socket.nio.SocketConnector;

public class StringClient {

    public void sendMsgSocket() throws UnknownHostException, IOException {
        Socket server = new Socket(InetAddress.getLocalHost(), Constants.PORT);

        PrintWriter serverOutput = new PrintWriter(server.getOutputStream());
        serverOutput.println("Hello MySocketClient");
        serverOutput.flush();

        BufferedReader in = new BufferedReader(new InputStreamReader(server.getInputStream()));
        System.out.println(in.readLine());

        server.close();
    }

    public void sendMsg() {

        SocketConnector connector = new SocketConnector();
        connector.setWorkerTimeout(5); // 5秒钟（默认超时60秒）

        SocketAcceptorConfig cfg = new SocketAcceptorConfig();
        // cfg.getFilterChain().addLast("logger", new LoggingFilter());
        TextLineCodecFactory textLineCodecFactory = new TextLineCodecFactory(Charset.forName("UTF-8"));
        cfg.getFilterChain().addLast("codec", new ProtocolCodecFilter(textLineCodecFactory));

        ConnectFuture future = connector.connect(new InetSocketAddress(Constants.PORT),//
                                                 new StringSendHandler("hello mina"), cfg);

        // Wait for the asynchronous operation to end.
        future.join();
    }

    public static void main(final String[] args) throws Exception {

        // new StringClient().sendMsgSocket();
        new StringClient().sendMsg();
    }
}
