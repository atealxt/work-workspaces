package minademo.string.protocolcodecfilter;

/**
 * 格式 <br>
 * id|name|age|sex
 */
public class PassedMessage {

    private long id;
    private String name;
    private int age;
    private String sex;

    public PassedMessage(final long id, final String name, final int age, final String sex) {
        super();
        this.id = id;
        this.name = name;
        this.age = age;
        this.sex = sex;
    }

    public long getId() {
        return id;
    }

    public void setId(final long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(final int age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(final String sex) {
        this.sex = sex;
    }

    @Override
    public String toString() {
        return "PassedMessage [age=" + age + ", id=" + id + ", name=" + name + ", sex=" + sex + "]";
    }

}
