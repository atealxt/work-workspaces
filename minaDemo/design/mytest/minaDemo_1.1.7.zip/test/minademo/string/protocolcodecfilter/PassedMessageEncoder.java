package minademo.string.protocolcodecfilter;

import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.mina.common.ByteBuffer;
import org.apache.mina.common.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;
import org.apache.mina.filter.codec.demux.MessageEncoder;

public class PassedMessageEncoder implements MessageEncoder {

    private final static String SEPARATOR = "|";

    @Override
    public void encode(final IoSession paramIoSession, final Object message, final ProtocolEncoderOutput out)
            throws Exception {

        PassedMessage msg = (PassedMessage) message;
        ByteBuffer buf = ByteBuffer.allocate(256);
        buf.setAutoExpand(true);
        CharsetEncoder utf8 = Charset.forName("utf-8").newEncoder();

        buf.putLong(msg.getId());
        buf.putString(SEPARATOR, utf8);
        buf.putString(msg.getName(), utf8);
        buf.putString(SEPARATOR, utf8);
        buf.putInt(msg.getAge());
        buf.putString(SEPARATOR, utf8);
        buf.putString(msg.getSex(), utf8);

        buf.flip();
        out.write(buf);
    }

    private static final Set<Class<?>> TYPES;

    static {
        Set<Class<?>> types = new HashSet<Class<?>>();
        types.add(PassedMessage.class);
        TYPES = Collections.unmodifiableSet(types);
    }

    public Set<Class<?>> getMessageTypes() {
        return TYPES;
    }
}
