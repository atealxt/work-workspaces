package minademo.string.protocolcodecfilter;

import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;

public class PassedMessageReceiveHandler extends IoHandlerAdapter {

    @Override
    public void messageReceived(final IoSession session, final Object msg) throws Exception {
        System.out.println("messageReceived: " + msg);
    }

    @Override
    public void exceptionCaught(final IoSession session, final Throwable t) throws Exception {
        t.printStackTrace();
        session.close();
    }
}
