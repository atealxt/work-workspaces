package minademo.string.protocolcodecfilter;

import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;

public class PassedMessageSendHandler extends IoHandlerAdapter {

    private PassedMessage message;

    public PassedMessageSendHandler(final PassedMessage message) {
        super();
        this.message = message;
    }

    @Override
    public void sessionOpened(final IoSession session) throws Exception {
        session.write(message);
    }

    @Override
    public void messageSent(final IoSession session, final Object message) throws Exception {
        System.out.println("messageSent: " + message);
        session.close();
    }

    @Override
    public void exceptionCaught(final IoSession session, final Throwable t) throws Exception {
        t.printStackTrace();
        session.close();
    }



}
