package minademo.string.protocolcodecfilter;

import org.apache.mina.filter.codec.demux.DemuxingProtocolCodecFactory;

public class PassedMessageProtocolCodecFactory extends DemuxingProtocolCodecFactory {

    public PassedMessageProtocolCodecFactory() {
        super.register(PassedMessageDecoder.class);
        super.register(PassedMessageEncoder.class);
    }
}
