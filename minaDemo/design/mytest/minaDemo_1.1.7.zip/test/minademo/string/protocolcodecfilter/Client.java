package minademo.string.protocolcodecfilter;

import java.net.InetSocketAddress;

import minademo.Constants;

import org.apache.mina.common.ConnectFuture;
import org.apache.mina.filter.LoggingFilter;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;
import org.apache.mina.transport.socket.nio.SocketConnector;

public class Client {

    public void sendMsg() {

        PassedMessage message = new PassedMessage(1234L, "tom", 20, "male");

        SocketConnector connector = new SocketConnector();
        connector.setWorkerTimeout(5);

        SocketAcceptorConfig cfg = new SocketAcceptorConfig();
        cfg.getFilterChain().addLast("logger", new LoggingFilter());
        cfg.getFilterChain().addLast("protocolFilter",//
                                     new ProtocolCodecFilter(new PassedMessageProtocolCodecFactory()));

        ConnectFuture future = connector.connect(new InetSocketAddress(Constants.PORT),//
                                                 new PassedMessageSendHandler(message), cfg);
        future.join();
    }

    public static void main(final String[] args) throws Exception {
        new Client().sendMsg();
    }
}
