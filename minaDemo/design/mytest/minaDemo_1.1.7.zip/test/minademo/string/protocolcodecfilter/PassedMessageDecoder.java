package minademo.string.protocolcodecfilter;

import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;

import org.apache.mina.common.ByteBuffer;
import org.apache.mina.common.IoSession;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.apache.mina.filter.codec.demux.MessageDecoderAdapter;
import org.apache.mina.filter.codec.demux.MessageDecoderResult;

/** MessageDecoderAdapter包含了完整性check，还有一个简单的Decoder叫CumulativeProtocolDecoder */
public class PassedMessageDecoder extends MessageDecoderAdapter {

    private static CharsetDecoder utf8 = Charset.forName("utf-8").newDecoder();

    @Override
    public MessageDecoderResult decodable(final IoSession paramIoSession, final ByteBuffer in) {

        // Return NEED_DATA if the whole header is not read yet.
        try {
            return messageComplete(in) ? MessageDecoderResult.OK : MessageDecoderResult.NEED_DATA;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return MessageDecoderResult.NOT_OK;
    }

    private boolean messageComplete(final ByteBuffer in) {

        if (in.prefixedDataAvailable(4)) {
            return true;
        }
        // the message is not complete and we need more data
        return false;
    }

    @Override
    public MessageDecoderResult decode(
            final IoSession paramIoSession,
            final ByteBuffer in,
            final ProtocolDecoderOutput out) throws Exception {

        // Try to decode body
        PassedMessage m = decodeBody(in);

        // Return NEED_DATA if the body is not fully read.
        if (m == null) {
            return MessageDecoderResult.NEED_DATA;
        }

        out.write(m);

        return MessageDecoderResult.OK;
    }

    private PassedMessage decodeBody(final ByteBuffer in) {

        try {
            long id = in.getLong();

            String separator = in.getString(utf8);
            System.out.println(separator);

            String name = in.getString(utf8);

            separator = in.getString(utf8);
            System.out.println(separator);

            int age = in.getInt();

            separator = in.getString(utf8);
            System.out.println(separator);

            String sex = in.getString(utf8);

            return new PassedMessage(id, name, age, sex);
        } catch (CharacterCodingException e) {
            e.printStackTrace();
        }
        return null;
    }

}
