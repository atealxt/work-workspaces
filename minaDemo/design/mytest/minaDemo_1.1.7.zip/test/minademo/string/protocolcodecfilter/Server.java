package minademo.string.protocolcodecfilter;

import java.io.IOException;
import java.net.InetSocketAddress;

import minademo.Constants;

import org.apache.mina.filter.LoggingFilter;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;

public class Server {

    public void listen() throws IOException {

        SocketAcceptor acceptor = new SocketAcceptor();

        SocketAcceptorConfig cfg = new SocketAcceptorConfig();
//        cfg.setReuseAddress(true);
        cfg.getFilterChain().addLast("logger", new LoggingFilter());
        cfg.getFilterChain().addLast("protocolFilter",//
                                     new ProtocolCodecFilter(new PassedMessageProtocolCodecFactory()));
        acceptor.bind(new InetSocketAddress(Constants.PORT), new PassedMessageReceiveHandler(), cfg);

        System.out.println("PassedMessage server started.");
    }

    public static void main(final String[] args) throws IOException {
        new Server().listen();
    }
}
