package minademo;

import java.text.SimpleDateFormat;
import java.util.Date;

public final class Utils {

    private static SimpleDateFormat TIME = new SimpleDateFormat("yyyyMMddHHmmss");

    public static String addCurrentTime4File(final String fileName) {

        StringBuilder trueFileName = new StringBuilder();

        int indexDot = fileName.lastIndexOf(".");
        trueFileName.append(fileName.substring(0, indexDot));
        trueFileName.append("_");
        trueFileName.append(TIME.format(new Date()));
        trueFileName.append(fileName.substring(indexDot));

        return trueFileName.toString();
    }
}
