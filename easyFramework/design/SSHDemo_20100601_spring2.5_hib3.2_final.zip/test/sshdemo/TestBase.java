package sshdemo;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 测试基类
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@TestExecutionListeners( {})
public abstract class TestBase extends AbstractTransactionalJUnit4SpringContextTests {

    protected MockHttpServletRequest request = new MockHttpServletRequest("POST", "/index.do");
    private long costTime = System.currentTimeMillis();
    
    @Autowired
    public void setDataSource(@Qualifier("dataSource") DataSource dataSource) {
        super.setDataSource(dataSource);
    }

    @Before
    public void setUp() {
        logger.debug("test start");
    }

    @After
    public void tearDown() throws Exception {
        logger.debug("test end");
        logger.debug("cost time: " + (System.currentTimeMillis() - costTime) + "ms");
    }
    
    @Test
    public void test() {
        try {
            excute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public abstract void excute() throws Exception;
}
