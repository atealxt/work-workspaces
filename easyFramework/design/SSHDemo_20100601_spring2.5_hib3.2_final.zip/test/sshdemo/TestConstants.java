package sshdemo;

public final class TestConstants {

    public final static String TEST_RESOURCES_PATH_BASE = "sshdemo/";

}
