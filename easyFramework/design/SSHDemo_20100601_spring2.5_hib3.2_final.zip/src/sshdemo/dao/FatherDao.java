package sshdemo.dao;

import sshdemo.core.dao.IBaseDaoOrm;
import sshdemo.entity.Father;

public interface FatherDao extends IBaseDaoOrm {

    Father findByName(String name);
}
