package sshdemo.dao;

import sshdemo.core.dao.IBaseDaoOrm;

public interface TeacherDao extends IBaseDaoOrm {

}
