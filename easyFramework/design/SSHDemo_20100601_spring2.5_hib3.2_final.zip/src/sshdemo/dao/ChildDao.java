package sshdemo.dao;

import sshdemo.core.dao.IBaseDaoOrm;
import sshdemo.entity.Child;

public interface ChildDao extends IBaseDaoOrm {

    Child findByName(String name);
}
