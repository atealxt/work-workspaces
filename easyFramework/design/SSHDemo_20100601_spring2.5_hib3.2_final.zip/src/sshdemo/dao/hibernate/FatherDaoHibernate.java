package sshdemo.dao.hibernate;

import java.util.List;

import sshdemo.core.dao.BaseDaoHibernate;
import sshdemo.dao.FatherDao;
import sshdemo.entity.Father;

public class FatherDaoHibernate extends BaseDaoHibernate implements FatherDao {

    @SuppressWarnings("unchecked")
    @Override
    public Father findByName(String name) {
        List list = findByQuery("from Father where name = ?", name);
        if (list.size() > 0) {
            return (Father) list.get(0);
        }
        return null;
    }
}
