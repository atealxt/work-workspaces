package sshdemo.dao.hibernate;

import java.util.List;

import sshdemo.core.dao.BaseDaoHibernate;
import sshdemo.dao.ChildDao;
import sshdemo.entity.Child;

public class ChildDaoHibernate extends BaseDaoHibernate implements ChildDao {

    @SuppressWarnings("unchecked")
    @Override
    public Child findByName(String name) {
        List list = findByQuery("from Child where name = ?", name);
        if (list.size() > 0) {
            return (Child) list.get(0);
        }
        return null;
    }
}
