package sshdemo.dao.hibernate;

import sshdemo.core.dao.BaseDaoHibernate;
import sshdemo.dao.TeacherDao;

public class TeacherDaoHibernate extends BaseDaoHibernate implements TeacherDao {

}
