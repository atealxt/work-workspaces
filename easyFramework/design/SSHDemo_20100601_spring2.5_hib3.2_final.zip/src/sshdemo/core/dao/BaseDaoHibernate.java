package sshdemo.core.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * Hibernate BaseDao class
 */
public abstract class BaseDaoHibernate extends HibernateDaoSupport implements IBaseDaoOrm {

    /** getHibernateTemplate().load */
    @Override
    public <T> T findById(final Class<T> clazz, java.io.Serializable id) {
        final Object o = getHibernateTemplate().load(clazz, id);
        if (o == null) {
            return null;
        }
        final T bean = clazz.cast(o);
        return bean;
    }

    /** getHibernateTemplate().get */
    @Override
    public <T> T getById(final Class<T> clazz, java.io.Serializable id) {
        final Object o = getHibernateTemplate().get(clazz, id);
        if (o == null) {
            return null;
        }
        final T bean = clazz.cast(o);
        return bean;
    }

    /** getHibernateTemplate().find */
    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> findByQuery(String hql) {
        return getHibernateTemplate().find(hql);
    }

    /** getHibernateTemplate().executeFind */
    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> findByQuery(final String hql, final Pager pager) {
        
        return getHibernateTemplate().executeFind(new HibernateCallback() {

            public Object doInHibernate(Session s) throws RuntimeException {
                Query query = s.createQuery(hql);
                query.setFirstResult(pager.getFirstResult());
                query.setMaxResults(pager.getMaxResults());
                return query.list();
            }
        });

    }

    /** getHibernateTemplate().find */
    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> findByQuery(String hql, Object... values) {
        return getHibernateTemplate().find(hql, values);
    }

    /** getHibernateTemplate().executeFind */
    @SuppressWarnings("unchecked")
    @Override
    public <T> List<T> findByQuery(final String hql, final Pager pager, final Object... values) {
        return getHibernateTemplate().executeFind(new HibernateCallback() {

            public Object doInHibernate(Session s) throws RuntimeException {
                Query query = s.createQuery(hql);
                for (int i = 0; i < values.length; i++) {
                    query.setParameter(i, values[i]);
                }
                query.setFirstResult(pager.getFirstResult());
                query.setMaxResults(pager.getMaxResults());
                return query.list();
            }
        });
    }

    /** getHibernateTemplate().find */
    @SuppressWarnings("unchecked")
    @Override
    public <T> long count(Class<? extends Object> clazz) {
        StringBuilder hql = new StringBuilder("SELECT COUNT(*) FROM ").append(clazz.getSimpleName());
        List list = getHibernateTemplate().find(hql.toString());
        Long count = (Long) list.get(0);
        return count.longValue();
    }

    /** getHibernateTemplate().save */
    @Override
    public <T> T save(T transientInstance) {
        getHibernateTemplate().save(transientInstance);
        return transientInstance;
    }

    /** getHibernateTemplate().delete */
    @Override
    public <T> void delete(T persistentInstance) {
        getHibernateTemplate().delete(persistentInstance);
    }

    /** getHibernateTemplate().merge */
    @Override
    public <T> T merge(T detachedInstance, final Class<T> clazz) {
        final Object o = getHibernateTemplate().merge(detachedInstance);
        if (o == null) {
            return null;
        }
        final T bean = clazz.cast(o);
        return bean;
    }

    /** getHibernateTemplate().flush */
    @Override
    public void flush() {
        getHibernateTemplate().flush();
    }

    /** getHibernateTemplate().initialize */
    @Override
    public void initialize(Object obj) {
        getHibernateTemplate().initialize(obj);
    }

}
