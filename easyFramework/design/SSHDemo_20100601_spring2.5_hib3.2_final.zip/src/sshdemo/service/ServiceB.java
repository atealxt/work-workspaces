package sshdemo.service;

public class ServiceB {

    public void testTransaction() {
        System.out.println("will auto rollback");
        throw new UnsupportedOperationException();
    }
}
