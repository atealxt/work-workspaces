package sshdemo.service;

import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.transaction.annotation.Transactional;

import sshdemo.dao.FatherDao;
import sshdemo.entity.Father;

public class FatherService {

    @Autowired
    @Qualifier("FatherDao")
    private FatherDao fatherDao;
    
    @Resource
    protected MessageSource messageSource;

    @Transactional
    public Father getFather() {
        
        MessageSourceAccessor text = new MessageSourceAccessor(messageSource, Locale.SIMPLIFIED_CHINESE);
        System.out.println(text.getMessage("helloworld"));
        
        Father f = fatherDao.findByName("tom");
        Hibernate.initialize(f.getChildren());
        return f;
    }

    @Transactional
    public List<Father> getFathers() {
        List<Father> fathers = fatherDao.findByQuery("from Father");
        for (Father f : fathers) {
            Hibernate.initialize(f.getChildren());
        }
        return fathers;
    }
}
