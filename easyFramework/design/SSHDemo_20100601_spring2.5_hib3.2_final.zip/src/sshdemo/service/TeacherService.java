package sshdemo.service;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import sshdemo.dao.TeacherDao;
import sshdemo.entity.Teacher;

public class TeacherService {

    @Autowired
    @Qualifier("TeacherDao")
    private TeacherDao teacherDao;

    @Transactional
    public List<Teacher> getTeathers() {
        List<Teacher> teathers = teacherDao.findByQuery("from Teacher");
        for (Teacher t : teathers) {
            Hibernate.initialize(t.getStudents());
        }
        return teathers;
    }

    /**
     * 由于涉及到了lazy load，根函数（如getTeathers2）也需要配在事务里，Propagation.NEVER或SUPPORTS就行
     */
    @Transactional(propagation = Propagation.SUPPORTS)
    public List<Teacher> getTeathers2() {
        return confirmTeathers();
    }

    @Transactional
    // 居然注释了也行？？
    private List<Teacher> confirmTeathers() {
        List<Teacher> teathers = teacherDao.findByQuery("from Teacher");
        for (Teacher t : teathers) {
            // 这行纯在后台调用时不用加，但要需要回前台显示时就必须加了。
            teacherDao.initialize(t.getStudents());
            // Hibernate.initialize(t.getStudents());
        }
        return teathers;
    }
}
