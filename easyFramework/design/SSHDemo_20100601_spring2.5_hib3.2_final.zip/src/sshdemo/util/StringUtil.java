package sshdemo.util;

import java.io.UnsupportedEncodingException;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.anakia.Escape;

public class StringUtil {

    private static Log logger = LogFactory.getLog(StringUtil.class);

    private StringUtil() {}

    public static int getByteSize(final String psStr) {
        if (psStr == null) {
            return -1;
        }
        int size = -1;
        try {
            size = psStr.getBytes("UTF-8").length;
        } catch (UnsupportedEncodingException e) {
            logger.error(e);
        }
        return size;
    }

    public static boolean isEmpty(String str) {
        return isEmpty(str, false);
    }

    public static boolean isEmpty(String str, boolean trim) {
        if (str == null) {
            return true;
        } else if ("".equals(str)) {
            return true;
        } else if (trim && "".equals(str.trim())) {
            return true;
        }
        return false;
    }

    public static String delHtmlTag(String src) {
        if (isEmpty(src)) {
            return src;
        }
        return src.replaceAll("<[^>]*>", "").replaceAll("&[a-zA-Z0-9]{1,4};", "");
    }

    public static String escape(String s) {
        String escaped = Escape.getText(s);
        return escaped.replace("\n", "<br>");
    }

    /**
     * 取得指定长度的字符串<br>
     * 实际结果可能有出入，只在使用系统支持字符的情况下保证返回结果的正确性
     * 
     * @param src 字符串
     * @param len 长度
     */
    public static String getFirstStr(String src, int len) {
        String str = null;
        try {
            str = new String(src.getBytes("UTF-8"), "ISO8859_1");
        } catch (UnsupportedEncodingException ex) {
            logger.error(ex);
            return src;
        }
        if (str.length() > len) {
            // UTF-8特点
            str = str.substring(0, len - 1 + 2);
            try {
                str = new String(str.getBytes("ISO8859_1"), "UTF-8");
            } catch (UnsupportedEncodingException ex) {
                logger.error(ex);
            }
            return str;
        } else {
            return src;
        }
    }

    public static String getContactUrl(String contact) {
        if (StringUtil.isEmpty(contact)) {
            return contact;
        }
        if (contact.contains("@")) {
            return "mailto:".concat(contact);
        }
        if (!contact.startsWith("http://")) {
            return "http://".concat(contact);
        }
        return contact;
    }

    public static boolean isCharOrNum(String src) {
        return Pattern.matches("^[0-9a-zA-Z-_]+$", src);
    }

}
