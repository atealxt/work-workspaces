package sshdemo.core;

public final class DataSourceMap {
    
    private DataSourceMap(){}

    public static final String MYSQL = "MYSQL";
    public static final String ORACLE = "ORACLE";
}
