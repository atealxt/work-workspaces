package sshdemo.core.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * Hibernate BaseDao class
 */
public abstract class BaseDaoHibernate<T, PK extends Serializable> extends HibernateDaoSupport implements
        BaseDao<T, PK> {

    private Class<T> persistentClass;

    public BaseDaoHibernate(final Class<T> persistentClass) {
        this.persistentClass = persistentClass;
    }

    @Autowired
    public void setSuperSessionFactory(final SessionFactory sessionFactory) {
        super.setSessionFactory(sessionFactory);
    }

    /** getHibernateTemplate().load */
    @Override
    public T findById(final PK id) {
        final Object o = getHibernateTemplate().load(persistentClass, id);
        if (o == null) {
            return null;
        }
        final T bean = persistentClass.cast(o);
        return bean;
    }

    /** getHibernateTemplate().get */
    @Override
    public T getById(final PK id) {
        final Object o = getHibernateTemplate().get(persistentClass, id);
        if (o == null) {
            return null;
        }
        final T bean = persistentClass.cast(o);
        return bean;
    }

    /** getHibernateTemplate().find */
    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByQuery(final String hql) {
        return getHibernateTemplate().find(hql);
    }

    /** getHibernateTemplate().executeFind */
    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByQuery(final String hql, final Pager pager) {
        return getHibernateTemplate().executeFind(new HibernateCallback<T>() {

            public T doInHibernate(final Session s) throws RuntimeException {
                Query query = s.createQuery(hql);
                query.setFirstResult(pager.getFirstResult());
                query.setMaxResults(pager.getMaxResults());
                return (T) query.list();
            }
        });
    }

    /** getHibernateTemplate().find */
    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByQuery(final String hql, final Object... values) {
        return getHibernateTemplate().find(hql, values);
    }

    /** getHibernateTemplate().executeFind */
    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByQuery(final String hql, final Pager pager, final Object... values) {
        return getHibernateTemplate().executeFind(new HibernateCallback<T>() {

            public T doInHibernate(final Session s) throws RuntimeException {
                Query query = s.createQuery(hql);
                for (int i = 0; i < values.length; i++) {
                    query.setParameter(i, values[i]);
                }
                query.setFirstResult(pager.getFirstResult());
                query.setMaxResults(pager.getMaxResults());
                return (T) query.list();
            }
        });
    }

    /** getHibernateTemplate().find */
    @Override
    public long count() {
        StringBuilder hql = new StringBuilder("SELECT COUNT(*) FROM ").append(persistentClass.getSimpleName());
        @SuppressWarnings("rawtypes") List list = getHibernateTemplate().find(hql.toString());
        Long count = (Long) list.get(0);
        return count.longValue();
    }

    /** getHibernateTemplate().save */
    @Override
    public T save(final T transientInstance) {
        getHibernateTemplate().save(transientInstance);
        return transientInstance;
    }

    /** getHibernateTemplate().delete */
    @Override
    public void delete(final T persistentInstance) {
        getHibernateTemplate().delete(persistentInstance);
    }

    /** getHibernateTemplate().merge */
    @Override
    public T merge(final T detachedInstance) {
        final Object o = getHibernateTemplate().merge(detachedInstance);
        if (o == null) {
            return null;
        }
        final T bean = persistentClass.cast(o);
        return bean;
    }

    /** getHibernateTemplate().flush */
    @Override
    public void flush() {
        getHibernateTemplate().flush();
    }

    /** getHibernateTemplate().initialize */
    @Override
    public void initialize(final Object obj) {
        getHibernateTemplate().initialize(obj);
    }
}
