package sshdemo.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import sshdemo.core.DSContextHolder;
import sshdemo.core.DataSourceMap;
import sshdemo.dao.FatherDao;
import sshdemo.entity.Father;

@Service("MultiDataSourceService")
public class MultiDataSourceService {

    @Autowired
    @Qualifier("FatherDao")
    protected FatherDao fatherDao;

    // @Autowired
    // @Qualifier("FatherDaoOracle")
    // protected FatherDao fatherDaoOracle;

    @Transactional(readOnly = false, propagation = Propagation.REQUIRED)
    public void execute(final Father f) {

        fatherDao.save(f);
        fatherDao.flush();

        // // 多数据源的session测试，原理看findById和getById
        // assertNotNull(fatherDaoOracle.findById(f.getId()));
        // assertNull(fatherDaoOracle.getById(f.getId()));
        // assertNotNull(fatherDaoOracle.findByName("tom"));
        // assertNull(fatherDaoOracle.findByName("spring"));
    }

    // @Transactional(readOnly = false, propagation = Propagation.REQUIRED)
    // public void executeOracle(Father f) {
    //
    // // OSIV机制决定了，不能同时更新别的DataSource。
    // // fatherDaoOracle.insert(f);
    // }

    public void multiDSSearch(final Integer id) {
        try {
            assertNotNull(fatherDao.findById(id));// ds 1

            // wrong,use get!
            assertNotNull(fatherDao.findById(id));// ds 2

            assertNull(fatherDao.getById(id));// ds 2

            DSContextHolder.setDSContext(DataSourceMap.ORACLE);
            assertNotNull(fatherDao.getById(id));// ds 2
            DSContextHolder.clearDSContext();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
