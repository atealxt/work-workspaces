package sshdemo.dao.hibernate;

import java.util.List;

import org.springframework.stereotype.Repository;

import sshdemo.core.dao.BaseDaoHibernate;
import sshdemo.dao.FatherDao;
import sshdemo.entity.Father;

@Repository("FatherDao")
public class FatherDaoHibernate extends BaseDaoHibernate<Father, Integer> implements FatherDao {

    public FatherDaoHibernate() {
        super(Father.class);
    }

    @Override
    public Father findByName(final String name) {
        List<Father> list = findByQuery("from Father where name = ?", name);
        if (list.size() > 0) {
            return list.get(0);
        }
        return null;
    }
}
