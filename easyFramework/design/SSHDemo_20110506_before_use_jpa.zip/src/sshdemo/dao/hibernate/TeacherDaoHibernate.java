package sshdemo.dao.hibernate;

import org.springframework.stereotype.Repository;

import sshdemo.core.dao.BaseDaoHibernate;
import sshdemo.dao.TeacherDao;
import sshdemo.entity.Teacher;

@Repository("TeacherDao")
public class TeacherDaoHibernate extends BaseDaoHibernate<Teacher, String> implements TeacherDao {

    public TeacherDaoHibernate() {
        super(Teacher.class);
    }
}
