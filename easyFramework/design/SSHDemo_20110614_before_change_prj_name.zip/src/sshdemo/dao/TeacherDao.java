package sshdemo.dao;

import sshdemo.core.dao.BaseDao;
import sshdemo.entity.Teacher;

public interface TeacherDao extends BaseDao<Teacher, String> {

}
