package test.client;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import dao.FatherDao;

import po.Father;
import test.TestUtils;

public class Flush extends TestUtils {

    @Autowired
    @Qualifier("FatherDao")
    protected FatherDao fatherDao;

    @Test
    public void hello() {
        try {
            Father f = new Father();
            f.setName("spring");
            fatherDao.save(f);
            // 不flush的话，缓存有，db不一定马上有。尽可能不要写这句话。
            // fatherDao.getHibernateTemplate().flush();
            assertNotNull(fatherDao.findById(f.getId()));
            assertNotNull(fatherDao.getById(f.getId()));
            System.out.println("以上的操作优先在缓存中进行，很可能还没更新至DB");

            // 估计是直接检索DB时的处理，控制程序先触发flush了。所以先Commit后再检索，DB里就有了。
            // flush在这里可以表现出工作的很好:P
            assertNotNull(fatherDao.findByName("spring"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
