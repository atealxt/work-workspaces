package test.client;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import po.Father;
import service.FatherAndChildService;
import test.TestUtils;
import constant.DataSourceMap;
import core.DSContextHolder;
import dao.FatherDao;

public class MultiDataSource extends TestUtils {

    @Autowired
    @Qualifier("FatherDao")
    protected FatherDao fatherDao;

    @Autowired
    @Qualifier("FatherAndChildService")
    protected FatherAndChildService fatherAndChildService;

    // @Autowired
    // @Qualifier("FatherDaoOracle")
    // protected FatherDao fatherDaoOracle;

    @Test
    public void hello() {
        try {
            Father f = new Father();
            f.setName("spring");
            fatherDao.save(f);

            // 不flush的话，缓存有，db不一定马上有。尽可能不要写这句话。
            fatherDao.flush();

            // 多数据源的session测试，原理看findById和getById
            // assertNotNull(fatherDaoOracle.findById(f.getId()));
            // assertNull(fatherDaoOracle.getById(f.getId()));
            // assertNotNull(fatherDaoOracle.findByName("tom"));
            // assertNull(fatherDaoOracle.findByName("spring"));

            // 不能同时对多个datasource进行更新，不论他们是在一个事务里还是在各自的事务里。因为它们共用一个Session
            // fatherDaoOracle.insert(f);
            // 实在要更新，必须另写TestCase，或新起线程，如函数anotherThread

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // @Test
    public void anotherThread() {
        try {
            Father f = new Father();
            f.setName("spring");
            // fatherDaoOracle.insert(f);

            // // spring测试框架的commit机制决定了，只能同时管理一个DataSource，体现为必须指定DataSource(TestUtils)。
            // // 要想实现spring的commit，就必须要手动处理。
            // fatherDaoOracle.getHibernateTemplate().flush();
            //          
            // //另外，就不可能实现对其他DataSource的"恢复现场"（自动回滚）了。

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** 使用AbstractRoutingDataSource后，可以解决Spring测试框架的自动提交、自动回滚 */
    @Test
    public void dSContextHolder() {
        try {
            Father f = new Father();
            f.setName("spring");

            DSContextHolder.setDSContext(DataSourceMap.ORACLE);
            fatherDao.save(f);
            fatherDao.flush();
            DSContextHolder.clearDSContext();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void autoRollBack() {
        System.out.println("test TransactionMultiDS start");
        try {
            fatherAndChildService.testTransactionMultiDS_DS1();
        } catch (Exception e) {
        }
        try {
            fatherAndChildService.testTransactionMultiDS_DS2();
        } catch (Exception e) {
        }
    }

}
