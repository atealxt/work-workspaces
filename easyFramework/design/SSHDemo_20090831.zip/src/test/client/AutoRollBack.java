package test.client;

import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import service.FatherAndChildService;
import service.ServiceA;
import test.TestUtils;
import dao.ChildDao;
import dao.FatherDao;

public class AutoRollBack extends TestUtils {

    @Autowired
    @Qualifier("FatherAndChildService")
    protected FatherAndChildService fatherAndChildService;
    @Autowired
    @Qualifier("ServiceA")
    protected ServiceA serviceA;
    @Autowired
    @Qualifier("ChildDao")
    protected ChildDao childDao;
    @Autowired
    @Qualifier("FatherDao")
    protected FatherDao fatherDao;

    @Test
    public void testAutoRollback1() {
        try {
            fatherAndChildService.testTransaction();
            assertNull(childDao.findByName("ff"));
        } catch (Exception e) {
            // e.printStackTrace();
        }
    }

    @Test
    public void testAutoRollback2() {
        try {
            serviceA.testTransaction();
            assertNull(childDao.findByName("ff"));
        } catch (Exception e) {
            // e.printStackTrace();
        }
    }

}
