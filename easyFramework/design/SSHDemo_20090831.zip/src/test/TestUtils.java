package test;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Spring的测试框架为自动回滚
 * 
 * DEBUG时用MySQL QueryBrowser看是看不到即时的数据的，但用MySQL Adiministrator却能看到实际row的数量变化。
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@TestExecutionListeners( {})
public class TestUtils extends AbstractTransactionalJUnit4SpringContextTests {

    @Autowired
    public void setDataSource(@Qualifier("dataSource") DataSource dataSource) {
        super.setDataSource(dataSource);
    }

    @Before
    public void setUp() {
        System.out.println("test start");
    }

    @After
    public void tearDown() throws Exception {
        System.out.println("test end");
    }
}
