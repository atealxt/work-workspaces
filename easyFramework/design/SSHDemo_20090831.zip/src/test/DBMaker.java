package test;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import po.Child;
import po.Father;

/**
 * DB环境初始化类
 * 
 */
public class DBMaker {

    private Configuration conf;
    private SessionFactory sf;

    @Before
    public void setUp() {
        conf = new Configuration().configure();
        sf = conf.buildSessionFactory();
    }

    @After
    public void tearDown() throws Exception {
        sf.close();
        System.out.println("test end");
    }

    @Test
    public void createTable() {
        try {
            SchemaExport export = new SchemaExport(conf);
            // export.setOutputFile("D:/test.sql");
            export.create(true, true);

            createOne2Many();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createOne2Many() {
        Father f = new Father();
        f.setName("tom");
        f.setAge(30);
        sf.getCurrentSession().beginTransaction();
        sf.getCurrentSession().save(f);
        sf.getCurrentSession().getTransaction().commit();
        sf.getCurrentSession().close();

        Child c = new Child();
        c.setName("jerry");
        c.setFather(f);
        sf.getCurrentSession().beginTransaction();
        sf.getCurrentSession().save(c);
        sf.getCurrentSession().getTransaction().commit();
        sf.getCurrentSession().close();
    }

}
