package dao.hibernate;

import java.util.List;

import core.BaseDaoHibernate;

import po.Father;
import dao.FatherDao;

public class FatherDaoImpl extends BaseDaoHibernate implements FatherDao {

    public Father findById(String id) {
        return findById(Father.class, id);
    }

    public Father getById(String id) {
        return getById(Father.class, id);
    }

    @SuppressWarnings("unchecked")
    public Father findByName(String name) {
        List list = findByQuery("from Father where name = ?", name);
        if (list.size() > 0) {
            return (Father) list.get(0);
        }
        return null;
    }
}
