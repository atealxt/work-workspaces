package dao.hibernate;

import java.util.List;

import core.BaseDaoHibernate;

import po.Child;
import dao.ChildDao;


public class ChildDaoImpl extends BaseDaoHibernate implements ChildDao{

    public Child findById(String id) {
        return findById(Child.class, id);
    }

    @SuppressWarnings("unchecked")
    public Child findByName(String name) {
        List list = findByQuery("from Child where name = ?", name);
        if (list.size() > 0) {
            return (Child) list.get(0);
        }
        return null;
    }
}
