package dao.hibernate;

import core.BaseDaoHibernate;
import dao.TeacherDao;

public class TeacherDaoImpl extends BaseDaoHibernate implements TeacherDao {

}
