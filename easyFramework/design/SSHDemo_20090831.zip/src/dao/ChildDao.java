package dao;

import po.Child;
import core.BaseDao;

public interface ChildDao extends BaseDao {

    Child findById(String id);

    Child findByName(String name);

}
