package dao;

import core.BaseDao;

public interface TeacherDao extends BaseDao{

}
