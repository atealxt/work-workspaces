package dao;

import po.Father;
import core.BaseDao;

/** 
 * DAO类都不能直接配事务
 */
public interface FatherDao extends BaseDao {

    /**
     * 不保证线程安全,多数据源可能共用一个Session<br>
     * 所以在一个线程内使用到多数据源的话，请用getById函数
     */
    Father findById(String id);

    Father getById(String id);

    Father findByName(String name);
}
