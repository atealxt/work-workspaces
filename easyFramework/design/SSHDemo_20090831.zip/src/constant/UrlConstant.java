package constant;

public class UrlConstant {

    private UrlConstant() {
    }

    public static String TEST = "test";
}
