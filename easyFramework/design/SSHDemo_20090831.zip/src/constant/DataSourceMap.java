package constant;

public class DataSourceMap {

    public static final String MYSQL = "MYSQL";
    public static final String ORACLE = "ORACLE";
}
