package core;

/**
 * 数据库分页信息类
 */
public class Pager {

    // 起始数据行号
    private int firstResult;

    // 最大取得件数
    private int maxResults;

    /**
     * 分页信息类
     * 
     * @param firstResult 起始数据行号(numbered from 0)
     * @param maxResults 最大取得件数
     */
    public Pager(int firstResult, int maxResults) {
        super();
        this.firstResult = firstResult;
        this.maxResults = maxResults;
    }

    public int getFirstResult() {
        return firstResult;
    }

    public void setFirstResult(int firstResult) {
        this.firstResult = firstResult;
    }

    public int getMaxResults() {
        return maxResults;
    }

    public void setMaxResults(int maxResults) {
        this.maxResults = maxResults;
    }

}
