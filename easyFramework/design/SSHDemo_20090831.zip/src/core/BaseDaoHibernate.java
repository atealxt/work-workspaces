package core;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * 每种对数据的操作机制,实现一个BaseDao
 */
public abstract class BaseDaoHibernate extends HibernateDaoSupport implements BaseDao {

    /**
     * <p>
     * getHibernateTemplate().load
     * </p>
     * 不保证线程安全,例如多数据源可能共用一个Session<br>
     * 所以需要保证线程安全的话，请用getById函数
     */
    public <T> T findById(final Class<T> clazz, java.io.Serializable id) {
        try {
            final Object o = getHibernateTemplate().load(clazz, id);
            if (o == null) {
                return null;
            }
            final T bean = clazz.cast(o);
            return bean;
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    /** getHibernateTemplate().get */
    public <T> T getById(final Class<T> clazz, java.io.Serializable id) {
        try {
            final Object o = getHibernateTemplate().get(clazz, id);
            if (o == null) {
                return null;
            }
            final T bean = clazz.cast(o);
            return bean;
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    /** getHibernateTemplate().find */
    @SuppressWarnings("unchecked")
    public <T> List<T> findByQuery(String query) {
        try {
            return getHibernateTemplate().find(query);
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    /**
     * getHibernateTemplate().executeFind
     * 
     * @param pager 分页信息，包含firstResult与maxResults
     */
    @SuppressWarnings("unchecked")
    public <T> List<T> findByQuery(final String hql, final Pager pager) {
        return getHibernateTemplate().executeFind(new HibernateCallback() {

            public Object doInHibernate(Session s) throws RuntimeException {
                Query query = s.createQuery(hql);
                query.setFirstResult(pager.getFirstResult());
                query.setMaxResults(pager.getMaxResults());
                return query.list();
            }
        });
    }

    /**
     * getHibernateTemplate().find
     * 
     * @param values HQL参数的值
     */
    @SuppressWarnings("unchecked")
    public <T> List<T> findByQuery(String query, Object... values) {
        try {
            return getHibernateTemplate().find(query, values);
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    /**
     * getHibernateTemplate().executeFind
     * 
     * @param pager 分页信息，包含firstResult与maxResults
     * @param values HQL参数的值
     */
    @SuppressWarnings("unchecked")
    public <T> List<T> findByQuery(final String hql, final Pager pager, final Object... values) {
        return getHibernateTemplate().executeFind(new HibernateCallback() {

            public Object doInHibernate(Session s) throws RuntimeException {
                Query query = s.createQuery(hql);
                for (int i = 0; i < values.length; i++) {
                    query.setParameter(i, values[i]);
                }
                query.setFirstResult(pager.getFirstResult());
                query.setMaxResults(pager.getMaxResults());
                return query.list();
            }
        });
    }

    /**
     * getHibernateTemplate().find
     * 
     * @param clazz POJO的Class
     */
    @SuppressWarnings("unchecked")
    public long count(Class clazz) {
        StringBuilder query = new StringBuilder("SELECT COUNT(*) FROM ").append(clazz.getSimpleName());
        Long count = null;
        try {
            List list = this.getHibernateTemplate().find(query.toString());
            count = (Long) list.get(0);
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
        return count.longValue();
    }

    /** getHibernateTemplate().save */
    public <T> void save(T transientInstance) {
        try {
            getHibernateTemplate().save(transientInstance);
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    /** getHibernateTemplate().delete */
    public <T> void delete(T persistentInstance) {
        try {
            getHibernateTemplate().delete(persistentInstance);
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    /** getHibernateTemplate().merge */
    public <T> T merge(T detachedInstance, final Class<T> clazz) {
        try {
            final Object o = getHibernateTemplate().merge(detachedInstance);
            if (o == null) {
                return null;
            }
            final T bean = clazz.cast(o);
            return bean;
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    /** getHibernateTemplate().flush */
    public void flush() {
        try {
            getHibernateTemplate().flush();
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    public void initialize(Object obj) {
        try {
            getHibernateTemplate().initialize(obj);
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

}
