package core;

import javax.servlet.ServletContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public final class DIManager {

    private static Log logger = LogFactory.getLog(DIManager.class);
    private static AbstractApplicationContext applicationContext;// for client
    private static WebApplicationContext ctx;// for web

    private DIManager() {
    }

    static {
        ServletContext sc = contextBySpring();
        if (sc != null) {
            logger.info("DIManager WebApplicationContext init");
            ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(sc);
        }
        if (ctx == null) {
            logger.info("DIManager ClassPathXmlApplicationContext init");
            applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
            applicationContext.registerShutdownHook();
        }
    }

    private static ServletContext contextBySpring() {
        WebApplicationContext wctx = ContextLoader.getCurrentWebApplicationContext();
        if (wctx != null) {
            return wctx.getServletContext();
        }
        return null;
    }

    /**
     * get DI object
     */
    @SuppressWarnings("unchecked")
    public static <T> T getBean(String name) {
        return (T) get(name);
    }

    /**
     * get DI object
     */
    public static <T> T getBean(final Class<T> clazz, String name) {
        final Object o = get(name);
        try {
            final T bean = clazz.cast(o);
            return bean;
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }

    private static Object get(String name) {
        try {
            if (ctx != null) {
                return ctx.getBean(name);
            } else if (applicationContext != null) {
                return applicationContext.getBean(name);
            } else {
                logger.error("DIManager setting up error!");
                return null;
            }
        } catch (RuntimeException re) {
            logger.error(re);
            throw re;
        }
    }
}
