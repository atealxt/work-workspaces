package core;

import java.util.List;

/**
 * 此interface应脱离于具体ORM实现而存在
 */
public interface BaseDao {

    /**
     * <p>
     * 按主键检索数据
     * </p>
     * 优先从缓存中取，取不到再从DB中取<br>
     * 本函数不保证线程安全，所以需要线程安全的话，请用getById函数
     * 
     * @see getById
     */
    <T> T findById(final Class<T> clazz, java.io.Serializable id);

    /**
     * <p>
     * 按主键检索数据
     * </p>
     * 
     * @see findById
     */
    <T> T getById(final Class<T> clazz, java.io.Serializable id);

    /** 检索数据 */
    <T> List<T> findByQuery(String query);

    /**
     * 检索数据
     * 
     * @param pager 分页信息，包含firstResult与maxResults
     */
    <T> List<T> findByQuery(final String query, final Pager pager);

    /**
     * 检索数据
     * 
     * @param values query的参数的值
     */
    <T> List<T> findByQuery(String query, Object... values);

    /**
     * 检索数据
     * 
     * @param pager 分页信息，包含firstResult与maxResults
     * @param values query的参数的值
     */
    <T> List<T> findByQuery(final String query, final Pager pager, final Object... values);

    /**
     * 检索数据数量
     * 
     * @param clazz POJO的Class
     */
    <T> long count(Class<T> clazz);

    /** 保存数据 */
    <T> void save(T transientInstance);

    /** 删除数据 */
    <T> void delete(T persistentInstance);

    /** 更新数据 */
    <T> T merge(T detachedInstance, final Class<T> clazz);

    /** 刷新缓存 */
    void flush();

    /**
     * 主动加载<br>
     * 例如xxDao.initialize(Parent.getChildren())
     * 
     * @param obj 欲加载的对象
     */
    void initialize(Object obj);
}
