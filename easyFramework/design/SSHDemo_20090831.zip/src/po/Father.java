package po;

import java.util.HashSet;
import java.util.Set;

/**
 * @hibernate.class table="father"
 */
@SuppressWarnings("serial")
public class Father implements java.io.Serializable {

    private String id;

    private String name;

    private Integer age;
    
    private boolean old;

    private Set<Child> children = new HashSet<Child>(0);

//    public Father() {
//    }

    /**
     * @hibernate.id generator-class="uuid.hex" column="id" length="32"
     */
    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * @hibernate.property column="name" length="32" not-null="true" type="java.lang.String"
     */
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @hibernate.property column="age" length="32" type="java.lang.Integer"
     */
    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     * @hibernate.set table="child"
     * @hibernate.key column="father_id"
     * @hibernate.one-to-many class="po.Child"
     */
    public Set<Child> getChildren() {
        return children;
    }

    public void setChildren(Set<Child> children) {
        this.children = children;
    }

    
    public boolean isOld() {
        return old;
    }

    
    public void setOld(boolean old) {
        this.old = old;
    }
    
    
}
