package po;

import java.util.HashSet;
import java.util.Set;

/**
 * @hibernate.class table="student"
 */
@SuppressWarnings("serial")
public class Student implements java.io.Serializable {

    private String id;
    private String name;
    private Set<Teacher> teachers = new HashSet<Teacher>(0);

    /**
     * @hibernate.id generator-class="uuid.hex" column="id" length="32"
     */
    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * @hibernate.property column="name" length="32" not-null="true" type="java.lang.String"
     */
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @hibernate.set table="teacher_student_relation"
     * @hibernate.key column="student_id"
     * @hibernate.many-to-many class="po.Teacher" column="teacher_id"
     */
    public Set<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(Set<Teacher> teachers) {
        this.teachers = teachers;
    }
}
