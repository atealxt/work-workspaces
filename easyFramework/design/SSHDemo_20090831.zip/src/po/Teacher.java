package po;

import java.util.HashSet;
import java.util.Set;

/**
 * @hibernate.class table="teacher"
 */
@SuppressWarnings("serial")
public class Teacher implements java.io.Serializable {

    private String id;
    private String name;
    private Set<Student> students = new HashSet<Student>(0);

    /**
     * @hibernate.id generator-class="uuid.hex" column="id" length="32"
     */
    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * @hibernate.property column="name" length="32" not-null="true" type="java.lang.String"
     */
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @hibernate.set table="teacher_student_relation"
     * @hibernate.key column="teacher_id"
     * @hibernate.many-to-many class="po.Student" column="student_id"
     */
    public Set<Student> getStudents() {
        return students;
    }

    public void setStudents(Set<Student> students) {
        this.students = students;
    }

}
