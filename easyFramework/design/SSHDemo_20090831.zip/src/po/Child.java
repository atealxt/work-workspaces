package po;

/**
 * @hibernate.class table="child"
 */
@SuppressWarnings("serial")
public class Child implements java.io.Serializable {

    private String id;
    private String name;
    private Father father;

    /**
     * @hibernate.id generator-class="uuid.hex" column="id" length="32"
     */
    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * @hibernate.property column="name" length="32" not-null="true" type="java.lang.String" lazy="true"
     */
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @hibernate.many-to-one column="father_id" not-null="true"
     */
    public Father getFather() {
        return this.father;
    }

    public void setFather(Father father) {
        this.father = father;
    }

}
