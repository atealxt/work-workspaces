package action;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import po.Father;
import service.FatherService;
import service.TeacherService;
import constant.UrlConstant;

@Controller
public class TestAction {

    @Autowired
    @Qualifier("FatherService")
    private FatherService fatherService;
    @Autowired
    @Qualifier("TeacherService")
    protected TeacherService teacherService;

    @RequestMapping("/test.action")
    public String test(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        Father f = fatherService.getFather();
        model.addAttribute("Father", f);

        model.addAttribute("dataList", Arrays.asList("a", "啊", "<a href=\"aa\">&1１</a>"));
        model.addAttribute("dt", new Date());
        model.addAttribute("num", 1234.56789);
        model.addAttribute("map", ArrayUtils.toMap(new Object[][] { //
                { "key1", "value1" }, { "key2", "value2" }, { "key3", "value3" } }//
                ));
                
//        model.addAttribute("Teachers", teacherService.getTeathers());
        model.addAttribute("Teachers", teacherService.getTeathers2());//TODO Freemarker显示错误(不能直接输出list，只能输出单条)

        return UrlConstant.TEST;
    }

}
