package service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import constant.DataSourceMap;
import core.DSContextHolder;

import po.Father;

import dao.FatherDao;

public class MultiDataSourceService {

    @Autowired
    @Qualifier("FatherDao")
    protected FatherDao fatherDao;

//    @Autowired
//    @Qualifier("FatherDaoOracle")
//    protected FatherDao fatherDaoOracle;

    @Transactional(readOnly = false, propagation = Propagation.REQUIRED)
    public void execute(Father f) {

        fatherDao.save(f);
        fatherDao.flush();

//        // 多数据源的session测试，原理看findById和getById
//        assertNotNull(fatherDaoOracle.findById(f.getId()));
//        assertNull(fatherDaoOracle.getById(f.getId()));
//        assertNotNull(fatherDaoOracle.findByName("tom"));
//        assertNull(fatherDaoOracle.findByName("spring"));
    }

//    @Transactional(readOnly = false, propagation = Propagation.REQUIRED)
//    public void executeOracle(Father f) {
//
//        // OSIV机制决定了，不能同时更新别的DataSource。
//        // fatherDaoOracle.insert(f);
//    }
    
    public void multiDSSearch() {
        try {
            assertNotNull(fatherDao.findById("8a808085230358400123035843050001"));// ds 1
            
            //wrong,use get!
            assertNotNull(fatherDao.findById("8a80808822e936a80122e936b7f30001"));// ds 2
            
            assertNull(fatherDao.getById("8a80808822e936a80122e936b7f30001"));// ds 2

            DSContextHolder.setDSContext(DataSourceMap.ORACLE);
            assertNotNull(fatherDao.getById("8a80808822e936a80122e936b7f30001"));// ds 2
            DSContextHolder.clearDSContext();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
