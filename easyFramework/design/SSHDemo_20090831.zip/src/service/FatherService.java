package service;

import java.util.List;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;

import po.Father;
import dao.FatherDao;

public class FatherService {

    @Autowired
    @Qualifier("FatherDao")
    private FatherDao fatherDao;

    @Transactional
    public Father getFather() {
        Father f = fatherDao.findByName("tom");
        Hibernate.initialize(f.getChildren());
        return f;
    }

    @Transactional
    public List<Father> getFathers() {
        List<Father> fathers = fatherDao.findByQuery("from Father");
        for (Father f : fathers) {
            Hibernate.initialize(f.getChildren());
        }
        return fathers;
    }
}
