package com.jeecms.core.manager;

import com.jeecms.core.JeeCoreManager;
import com.jeecms.core.entity.Role;

public interface RoleMng extends JeeCoreManager<Role> {

}