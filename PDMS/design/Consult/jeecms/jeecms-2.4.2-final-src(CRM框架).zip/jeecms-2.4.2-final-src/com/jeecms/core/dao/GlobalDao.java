package com.jeecms.core.dao;

import com.jeecms.core.JeeCoreDao;
import com.jeecms.core.entity.Global;

public interface GlobalDao extends JeeCoreDao<Global> {

}