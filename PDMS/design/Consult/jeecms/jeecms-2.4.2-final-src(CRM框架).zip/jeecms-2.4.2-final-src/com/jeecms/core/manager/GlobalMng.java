package com.jeecms.core.manager;

import com.jeecms.core.JeeCoreManager;
import com.jeecms.core.entity.Global;

public interface GlobalMng extends JeeCoreManager<Global> {
}