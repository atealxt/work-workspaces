package com.jeecms.core;

import java.io.Serializable;

import com.jeecms.common.hibernate3.BaseDao;

public interface JeeCoreDao<T extends Serializable> extends BaseDao<T> {

}
