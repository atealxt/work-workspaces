package com.jeecms.cms.dao;

import com.jeecms.cms.entity.CmsAdmin;
import com.jeecms.core.JeeCoreDao;

public interface CmsAdminDao extends JeeCoreDao<CmsAdmin> {

}