package com.jeecms.cms.dao;

import com.jeecms.cms.entity.CmsConfig;
import com.jeecms.core.JeeCoreDao;

public interface CmsConfigDao extends JeeCoreDao<CmsConfig> {

}