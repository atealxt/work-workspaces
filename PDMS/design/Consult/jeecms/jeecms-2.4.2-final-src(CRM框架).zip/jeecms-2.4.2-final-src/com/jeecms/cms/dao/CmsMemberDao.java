package com.jeecms.cms.dao;

import com.jeecms.cms.entity.CmsMember;
import com.jeecms.core.JeeCoreDao;

public interface CmsMemberDao extends JeeCoreDao<CmsMember> {

}