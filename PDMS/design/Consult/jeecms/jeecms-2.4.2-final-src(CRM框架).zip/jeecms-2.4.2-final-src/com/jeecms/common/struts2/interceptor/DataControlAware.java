package com.jeecms.common.struts2.interceptor;

public interface DataControlAware {
}
