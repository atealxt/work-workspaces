package com.jeecms.core.entity;

public class Template implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

}
