package com.jeecms.cms.dao.impl;

import org.springframework.stereotype.Repository;

import com.jeecms.cms.entity.ChnlModelItem;
import com.jeecms.cms.dao.ChnlModelItemDao;
import com.jeecms.core.JeeCoreDaoImpl;

@Repository
public class ChnlModelItemDaoImpl extends JeeCoreDaoImpl<ChnlModelItem> implements ChnlModelItemDao {

}