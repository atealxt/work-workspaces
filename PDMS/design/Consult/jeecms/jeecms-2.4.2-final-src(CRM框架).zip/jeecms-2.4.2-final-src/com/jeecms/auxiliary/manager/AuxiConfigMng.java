package com.jeecms.auxiliary.manager;

import com.jeecms.core.JeeCoreManager;
import com.jeecms.auxiliary.entity.AuxiConfig;

public interface AuxiConfigMng extends JeeCoreManager<AuxiConfig> {

}