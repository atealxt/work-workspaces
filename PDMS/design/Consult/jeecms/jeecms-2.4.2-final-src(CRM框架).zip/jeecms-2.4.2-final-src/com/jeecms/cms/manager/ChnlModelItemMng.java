package com.jeecms.cms.manager;

import com.jeecms.core.JeeCoreManager;
import com.jeecms.cms.entity.ChnlModelItem;

public interface ChnlModelItemMng extends JeeCoreManager<ChnlModelItem> {

}