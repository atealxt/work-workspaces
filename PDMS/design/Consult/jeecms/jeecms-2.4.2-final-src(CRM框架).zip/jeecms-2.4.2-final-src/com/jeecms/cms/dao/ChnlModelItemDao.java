package com.jeecms.cms.dao;

import com.jeecms.cms.entity.ChnlModelItem;
import com.jeecms.core.JeeCoreDao;

public interface ChnlModelItemDao extends JeeCoreDao<ChnlModelItem> {

}