package com.jeecms.auxiliary.exception;

/**
 * ͶƱ�쳣
 * 
 * @author liufang
 * 
 */
@SuppressWarnings("serial")
public class VoteException extends Exception {
	public VoteException() {

	}

	public VoteException(String msg) {
		super(msg);
	}
}