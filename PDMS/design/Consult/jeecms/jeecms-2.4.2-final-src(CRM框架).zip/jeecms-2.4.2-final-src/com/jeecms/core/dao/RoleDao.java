package com.jeecms.core.dao;

import com.jeecms.core.JeeCoreDao;
import com.jeecms.core.entity.Role;

public interface RoleDao extends JeeCoreDao<Role> {

}