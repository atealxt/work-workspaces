package com.jeecms.core;

import java.io.Serializable;

import com.jeecms.common.hibernate3.BaseManager;

public interface JeeCoreManager<T extends Serializable> extends BaseManager<T> {
}
