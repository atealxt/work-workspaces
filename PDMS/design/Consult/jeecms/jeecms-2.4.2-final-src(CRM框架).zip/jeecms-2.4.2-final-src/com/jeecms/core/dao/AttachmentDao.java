package com.jeecms.core.dao;

import com.jeecms.core.entity.Attachment;
import com.jeecms.core.JeeCoreDao;

public interface AttachmentDao extends JeeCoreDao<Attachment> {

}