<?php

$sample_data = array(
  array(
		'company' => '3m Co',
		'price' => 71.72, 
		'change' => 0.02, 
		'pct_change' => 0.03, 
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Alcoa Inc',
		'price' => 29.01,
		'change' => 0.42,
		'pct_change' => 1.47,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Altria Group Inc',
		'price' => 83.81,
		'change' => 0.28,
		'pct_change' => 0.34,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'American Express Company',
		'price' => 52.55,
		'change' => 0.01,
		'pct_change' => 0.02,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'American International Group, Inc.',
		'price' => 64.13,
		'change' => 0.31,
		'pct_change' => 0.49,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'AT&T Inc.',
		'price' => 31.61,
		'change' => -0.48,
		'pct_change' => -1.54,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Boeing Co.',
		'price' => 75.43,
		'change' => 0.53,
		'pct_change' => 0.71,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Caterpillar Inc.',
		'price' => 67.27,
		'change' => 0.92,
		'pct_change' => 1.39,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Citigroup, Inc.',
		'price' => 49.37,
		'change' => 0.02,
		'pct_change' => 0.04,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'E.I. du Pont de Nemours and Company',
		'price' => 40.48,
		'change' => 0.51,
		'pct_change' => 1.28,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Exxon Mobil Corp',
		'price' => 68.1,
		'change' => -0.43,
		'pct_change' => -0.64,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'General Electric Company',
		'price' => 34.14,
		'change' => -0.08,
		'pct_change' => -0.23,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'General Motors Corporation',
		'price' => 30.27,
		'change' => 1.09,
		'pct_change' => 3.74,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Hewlett-Packard Co.',
		'price' => 36.53,
		'change' => -0.03,
		'pct_change' => -0.08,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Honeywell Intl Inc',
		'price' => 38.77,
		'change' => 0.05,
		'pct_change' => 0.13,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Intel Corporation',
		'price' => 19.88,
		'change' => 0.31,
		'pct_change' => 1.58,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'International Business Machines',
		'price' => 81.41,
		'change' => 0.44,
		'pct_change' => 0.54,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Johnson & Johnson',
		'price' => 64.72,
		'change' => 0.06,
		'pct_change' => 0.09,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'JP Morgan & Chase & Co',
		'price' => 45.73,
		'change' => 0.07,
		'pct_change' => 0.15,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'McDonald\'s Corporation',
		'price' => 36.76,
		'change' => 0.86,
		'pct_change' => 2.40,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Merck & Co., Inc.',
		'price' => 40.96,
		'change' => 0.41,
		'pct_change' => 1.01,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Microsoft Corporation',
		'price' => 25.84,
		'change' => 0.14,
		'pct_change' => 0.54,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Pfizer Inc',
		'price' => 27.96,
		'change' => 0.4,
		'pct_change' => 1.45,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'The Coca-Cola Company',
		'price' => 45.07,
		'change' => 0.26,
		'pct_change' => 0.58,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'The Home Depot, Inc.',
		'price' => 34.64,
		'change' => 0.35,
		'pct_change' => 1.02,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'The Procter & Gamble Company',
		'price' => 61.91,
		'change' => 0.01,
		'pct_change' => 0.02,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'United Technologies Corporation',
		'price' => 63.26,
		'change' => 0.55,
		'pct_change' => 0.88,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Verizon Communications',
		'price' => 35.57,
		'change' => 0.39,
		'pct_change' => 1.11,
		'last_change' => '9/1 12:00am'
	),
  array(
		'company' => 'Wal-Mart Stores, Inc.',
		'price' => 45.45,
		'change' => 0.73,
		'pct_change' => 1.63,
		'last_change' => '9/1 12:00am'
	)
);