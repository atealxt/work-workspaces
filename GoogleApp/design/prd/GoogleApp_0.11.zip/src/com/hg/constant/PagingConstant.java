package com.hg.constant;

/**
 * Data paging key
 */
public class PagingConstant {

    public final static int ARTICLE_MANAGE = 10;

    public final static int ARTICLE_VIEW = 5;

    public final static int LATEST_COMMENT = 5;

    public final static int COMMENT_MANAGE = 10;

}
