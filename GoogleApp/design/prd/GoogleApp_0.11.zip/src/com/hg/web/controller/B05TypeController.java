package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.EasyController;
import com.hg.dto.TypeInfo;
import com.hg.service.TypeService;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/typelist.html")
public class B05TypeController extends EasyController {

    @Autowired
    private TypeService typeService;

    @RequestMapping
    public String main(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootMain(req, model);
        return "admin/type";
    }

    private void makeRootMain(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Type");
        model.addAttribute("types", typeService.getTypes());
    }

    @RequestMapping(params = "m=add")
    public String addType(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (StringUtil.isEmpty(req.getParameter("Category"), true)) {
            setErr(req, resp, "名称不能为空！(name cannot be null)");
        } else {
            TypeInfo info = new TypeInfo();
            info.setName(req.getParameter("Category"));
            if (!typeService.postType(info)) {
                setErr(req, resp, "不能添加重复的分类！(The type has been exist)");
            }
        }

        return "redirect:/typelist.html";
    }

    @RequestMapping(params = "m=del")
    public String delType(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!typeService.removeType(req.getParameter("id"))) {
            setErr(req, resp, "不能删除默认分类！(cannot delete default type)");
        }
        return "redirect:/typelist.html";
    }

    @RequestMapping(params = "m=upd")
    public String updType(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        TypeInfo info = new TypeInfo();
        info.setId(req.getParameter("id"));
        info.setName(req.getParameter("Category"));
        if (!typeService.updateType(info)) {
            setErr(req, resp, "更新失败！(update fail)");
        }
        return "redirect:/typelist.html";
    }

    private void setErr(HttpServletRequest req, HttpServletResponse resp, String errMsg) throws IOException {
        StringBuilder sb = new StringBuilder("<b>");
        sb.append(errMsg);
        sb.append("</b>");
        sb.append("<a href=\"");
        sb.append(req.getRequestURI());
        sb.append("\">返回(return)</a>");

        initResponse(resp);
        resp.getWriter().println(sb.toString());
    }
}
