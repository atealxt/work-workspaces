package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.EasyController;
import com.hg.service.GreetingService;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/guestbooklist.html")
public class B06GuestbookController extends EasyController {

    @Autowired
    private GreetingService greetingService;

    @RequestMapping
    public String list(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        if ("d".equals(req.getParameter("m"))) {
            if (!StringUtil.isEmpty(req.getParameter("id"))) {
                greetingService.removeGreeting(req.getParameter("id"));
            } else {
                for (String id : req.getParameterValues("sel")) {
                    greetingService.removeGreeting(id);
                }
            }
        }

        makeRootList(req, model);
        return "admin/guestbook";
    }

    private void makeRootList(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Guest book list");

        int maxP = greetingService.getMaxPage();
        int iPage = getCurrentPage(req, maxP);
        model.addAttribute("currentP", iPage);
        model.addAttribute("maxP", maxP);
        model.addAttribute("greetings", greetingService.getList(iPage));
    }
}
