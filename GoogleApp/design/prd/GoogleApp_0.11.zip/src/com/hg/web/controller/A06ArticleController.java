package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.EasyController;
import com.hg.dto.Topic;
import com.hg.service.ArticleService;
import com.hg.service.CommentService;
import com.hg.service.TypeService;
import com.hg.util.GaeUtil;
import com.hg.util.ServletUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/article.html")
public class A06ArticleController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private TypeService typeService;

    @RequestMapping
    public String main(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        return makeRootMain(req, resp, model);
    }

    private String makeRootMain(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        // Build the data-model
        Topic topic = null;
        if (!StringUtil.isEmpty(req.getParameter("id"))) {
            topic = articleService.getById(req.getParameter("id"));
        } else {
            topic = articleService.getByAlias(req.getParameter("alias"), req.getParameter("ct"));
        }
        if (topic != null) {
            model.addAttribute("article", topic);
        } else {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return null;
        }

        model.addAttribute("user", GaeUtil.getCurrentUser());
        model.addAttribute("latestCmt", commentService.getLatestCmts());
        model.addAttribute("types", typeService.getTypes());

        String guestName = ServletUtil.getCookie(req, ServletUtil.GUEST_NAME);
        if (!StringUtil.isEmpty(guestName)) {
            model.addAttribute("guestName", guestName);
        }
        String guestUrl = ServletUtil.getCookie(req, ServletUtil.GUEST_URL);
        if (!StringUtil.isEmpty(guestUrl)) {
            model.addAttribute("guestUrl", guestUrl);
        }

        return "article";
    }

    @RequestMapping(params = "m=updcnt")
    public void updcnt(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        articleService.updReadCnt(req.getParameter("id"), ServletUtil.getReqIp(req));
    }
}