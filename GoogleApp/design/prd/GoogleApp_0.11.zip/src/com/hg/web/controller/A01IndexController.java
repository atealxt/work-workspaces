package com.hg.web.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.appengine.api.users.User;
import com.hg.core.EasyController;
import com.hg.dto.PageLink;
import com.hg.service.ArticleService;
import com.hg.util.GaeUtil;

@Controller
public class A01IndexController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @RequestMapping("/index.html")
    public String indexing(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootIndexing(req, model);
        return "index";
    }

    private void makeRootIndexing(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Hero's Grave");
        model.addAttribute("links", makeLink());
        model.addAttribute("appspots", makeAppLink());
        model.addAttribute("articles", articleService.getLatest(1));

        User user = GaeUtil.getCurrentUser();
        if (user != null) {
            model.addAttribute("user", user);
            model.addAttribute("loginUrl", "");
            model.addAttribute("logoutUrl", GaeUtil.getLogoutURL(req.getRequestURI()));
        } else {
            model.addAttribute("loginUrl", GaeUtil.getLoginURL(req.getRequestURI()));
            model.addAttribute("logoutUrl", "");
        }
    }

    private List<PageLink> makeLink() {
        List<PageLink> links = new ArrayList<PageLink>();

        PageLink link = null;

        link = new PageLink();
        link.setTitle("Only webmaster can use");
        link.setLink("/admin.html");
        link.setMsgShow("Website Administer");
        links.add(link);

        link = new PageLink();
        link.setTitle("Website Source Code");
        link.setLink("http://code.google.com/p/herogravebygae/");
        link.setMsgShow("Google Code");
        links.add(link);
        
        link = new PageLink();
        link.setTitle("Google Applications Overview");
        link.setLink("http://appengine.google.com/");
        link.setMsgShow("My Applications");
        links.add(link);

        link = new PageLink();
        link.setTitle("Google Website Analysis");
        link.setLink("https://www.google.com/webmasters/tools");
        link.setMsgShow("Google Webmaster Tool");
        links.add(link);

        link = new PageLink();
        link.setTitle("Google App Engine Official Site");
        link.setLink("http://code.google.com/appengine/");
        link.setMsgShow("Google App Engine");
        links.add(link);

        link = new PageLink();
        link.setTitle("Free Online Google Sitemap Generator");
        link.setLink("http://www.xml-sitemaps.com/");
        link.setMsgShow("Google Sitemap Generator");
        links.add(link);

        link = new PageLink();
        link.setTitle("My Chinese Programming Technology Blog");
        link.setLink("http://www.blogjava.net/atealxt");
        link.setMsgShow("BlogJava");
        links.add(link);

        link = new PageLink();
        link.setTitle("My Chinese Life Blog");
        link.setLink("http://atealxt.ycool.com/");
        link.setMsgShow("Atea的勇士坟墓");
        links.add(link);

        return links;
    }

    private List<PageLink> makeAppLink() {
        List<PageLink> links = new ArrayList<PageLink>();

        PageLink link = null;

        link = new PageLink();
        link.setTitle("Lin Cong(丛林)'s Ideas Repository");
        link.setLink("http://ihere.appspot.com/");
        link.setMsgShow("iHere");
        links.add(link);

        link = new PageLink();
        link.setTitle("Casey Lai's Blog");
        link.setLink("http://casey-lai.appspot.com/");
        link.setMsgShow("Casey Lai");
        links.add(link);

        link = new PageLink();
        link.setTitle("community, blog, 新闻, 技术, 八卦");
        link.setLink("http://niubi.appspot.com/");
        link.setMsgShow("NiuBi.de");
        links.add(link);

        link = new PageLink();
        link.setTitle("GIS, city weather photo, 城市 天气 照片 地图");
        link.setLink("http://icity.appspot.com/");
        link.setMsgShow("icity");
        links.add(link);

        link = new PageLink();
        link.setTitle("a simple project management");
        link.setLink("http://checknerds.appspot.com/");
        link.setMsgShow("CheckNerds");
        links.add(link);

        return links;
    }
}
