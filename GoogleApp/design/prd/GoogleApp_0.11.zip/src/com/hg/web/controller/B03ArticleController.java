package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.constant.CacheConstant;
import com.hg.core.EasyController;
import com.hg.dto.Topic;
import com.hg.service.ArticleService;
import com.hg.service.TypeService;
import com.hg.util.CacheUtil;
import com.hg.util.GaeUtil;
import com.hg.util.ServletUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/articlelist.html")
public class B03ArticleController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @Autowired
    private TypeService typeService;

    @RequestMapping
    public String list(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        if ("d".equals(req.getParameter("m"))) {
            articleService.remove(req.getParameter("id"));
        }

        makeRootList(req, model);
        return "admin/article";
    }

    private void makeRootList(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Articles");

        int iPage = 0;
        String page = req.getParameter("page");
        if (!StringUtil.isEmpty(page)) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        int maxP = articleService.getMaxPage(true);
        if (iPage > maxP) {
            iPage = maxP;
        }
        model.addAttribute("currentP", iPage);
        model.addAttribute("maxP", maxP);

        model.addAttribute("articles", articleService.getList(iPage, true));
    }

    @RequestMapping(params = "m=create")
    public String create(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootCreate(req, model);
        return "admin/articleInfo";
    }

    private void makeRootCreate(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Create New Article");
        model.addAttribute("m", "post");
        model.addAttribute("user", GaeUtil.getCurrentUser());
        model.addAttribute("types", typeService.getTypes(false));
    }

    @RequestMapping(params = "m=post")
    public String post(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Topic t = new Topic();
        t.setTitle(req.getParameter("title"));
        t.setSummary(req.getParameter("summery"));
        t.setContent(req.getParameter("content"));
        t.setPostBySummary(req.getParameter("chkSummery") != null);
        t.setType(req.getParameter("nCatalog"));
        t.setAlias(req.getParameter("alias"));
        t.setIp(ServletUtil.getReqIp(req));
        if (articleService.postArticle(t)) {
            CacheUtil.remove(CacheConstant.CALENDAR_TIME);
            CacheUtil.remove(CacheConstant.CALENDAR);
            return "redirect:/articlelist.html";
        } else {
            StringBuilder sb = new StringBuilder("<b>发布失败(Post fail)</b><br>");
            sb.append("● 同一天发表的文章别名不能有重复(alias cannot duplicate in one day)<br>");
            sb.append("<br><a href=\"/articlelist.html\">返回(return)</a>");
            initResponse(resp);
            resp.getWriter().println(sb.toString());
            return null;
        }
    }

    @RequestMapping(params = "m=edit")
    public String edit(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootEdit(req, model);
        return "admin/articleInfo";
    }

    private void makeRootEdit(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Edit Article");
        model.addAttribute("m", "update");
        model.addAttribute("topic", articleService.getById(req.getParameter("id")));
        model.addAttribute("types", typeService.getTypes(false));
    }

    @RequestMapping(params = "m=update")
    public String update(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Topic t = new Topic();
        t.setId(req.getParameter("id"));
        t.setTitle(req.getParameter("title"));
        t.setSummary(req.getParameter("summery"));
        t.setContent(req.getParameter("content"));
        t.setPostBySummary(req.getParameter("chkSummery") != null);
        t.setType(req.getParameter("nCatalog"));
        t.setAlias(req.getParameter("alias"));
        if (articleService.updateArticle(t)) {
            return "redirect:/articlelist.html";
        } else {
            StringBuilder sb = new StringBuilder("<b>发布失败(post fail)</b>");
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">返回(return)</a>");

            initResponse(resp);
            resp.getWriter().println(sb.toString());
            return null;
        }
    }

}
