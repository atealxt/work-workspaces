package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hg.core.EasyController;
import com.hg.dto.Mail;
import com.hg.util.DateUtil;
import com.hg.util.GaeUtil;
import com.hg.util.MailUtil;
import com.hg.util.ServletUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/contact.html")
public class A04ContactController extends EasyController {

    @RequestMapping
    public String main(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootMain(req, model);
        return "contact";
    }

    private void makeRootMain(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Contact Me");

        model.addAttribute("user", GaeUtil.getCurrentUser());
        String guestName = ServletUtil.getCookie(req, ServletUtil.GUEST_NAME);
        if (!StringUtil.isEmpty(guestName)) {
            model.addAttribute("guestName", guestName);
        }
        String guestUrl = ServletUtil.getCookie(req, ServletUtil.GUEST_URL);
        if (!StringUtil.isEmpty(guestUrl)) {
            model.addAttribute("guestUrl", guestUrl);
        }

        // CAPTCHA
        model.addAttribute("captcha", ServletUtil.makeCaptcha(req.getSession()));
    }

    @RequestMapping(params = "sending", method = RequestMethod.POST)
    public void sending(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        initResponse(resp);

        String captcha = req.getParameter("captcha");
        if (StringUtil.isEmpty(captcha)// 
                || !StringUtil.isNum(captcha)// 
                || !ServletUtil.checkCaptcha(Integer.parseInt(captcha), req.getSession())) {
            StringBuilder sb = new StringBuilder();
            sb.append("<b>Input captcha error!<br>验证码输入错误！</b><br>");
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");
            resp.getWriter().println(sb.toString());
            return;
        }

        String guestName = req.getParameter("yourname");
        if (!StringUtil.isEmpty(guestName)) {
            ServletUtil.setCookie(req, resp, ServletUtil.GUEST_NAME, guestName);
        }
        String guestUrl = req.getParameter("youremail");
        if (!StringUtil.isEmpty(guestUrl)) {
            ServletUtil.setCookie(req, resp, ServletUtil.GUEST_URL, guestUrl);
        }

        String from = "atealxt@gmail.com";
        String to = "atealxt@gmail.com";
        String subject = new StringBuilder(guestName).append(" ")//
                .append(DateUtil.getCurrentTime()).toString();
        String text = new StringBuilder(guestName).append(" ").append(guestUrl).append("<hr>")
                .append(req.getParameter("content")).toString();
        Mail mail = new Mail();
        mail.setFrom(from);
        mail.setTo(to);
        mail.setSubject(subject);
        mail.setText(text);
        mail.setMultiPart(StringUtil.isEmpty(req.getParameter("base")));

        StringBuilder sb = new StringBuilder();
        boolean sendOk = MailUtil.sendMail(mail);
        if (!sendOk) {
            sb.append("<b>Send failed!<br>");
            sb.append("发送失败！</b><br>");
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");
        } else {
            sb.append("<b>Send success!<br>");
            sb.append("发送成功！</b><br>");
            sb.append("<a href=\"");
            sb.append("/home/");
            sb.append("\">return</a>");
        }

        resp.getWriter().println(sb.toString());
    }
}
