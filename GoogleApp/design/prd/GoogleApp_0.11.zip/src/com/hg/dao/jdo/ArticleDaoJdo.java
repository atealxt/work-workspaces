package com.hg.dao.jdo;

import java.util.Date;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.hg.core.dao.BaseDaoJdo;
import com.hg.core.dao.JdoManager;
import com.hg.dao.ArticleDao;
import com.hg.dao.TypeDao;
import com.hg.pojo.Article;
import com.hg.pojo.Type;
import com.hg.util.DateUtil;

public class ArticleDaoJdo extends BaseDaoJdo implements ArticleDao {

    private static Log logger = LogFactory.getLog(ArticleDaoJdo.class);

    @Autowired
    private TypeDao typeDao;

    @Override
    public Article insert(Article a) {

        if (a.getAlias() != null && findAll(a.getAlias(), a.getCreateTime()) != null) {
            // alias cannot duplicate in one day
            return null;
        }

        Type t = typeDao.findByName(a.getType());
        t.setCountArticle(t.getCountArticle() + 1);

        return save(a);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findAll(int start, int length) {
        List<Article> articles = null;
        PersistenceManager manager = JdoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class);
            query.setOrdering("createTime desc");
            query.setRange(start, start + length);
            articles = (List<Article>) query.execute();
        } catch (Exception e) {
            logger.error(e);
        }
        return articles;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findAll(int start, int length, String typeName) {
        List<Article> articles = null;
        PersistenceManager manager = JdoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class, "type == typeParam");
            query.declareParameters("String typeParam");
            query.setOrdering("createTime desc");
            query.setRange(start, start + length);
            articles = (List<Article>) query.execute(typeName);
        } catch (Exception e) {
            logger.error(e);
        }
        return articles;
    }

    @Override
    public long count() {
        return count(Article.class);
    }

    @Override
    public long countByType(String typeName) {
        com.google.appengine.api.datastore.Query query = new com.google.appengine.api.datastore.Query(Article.class
                .getSimpleName());
        query.addFilter("type", FilterOperator.EQUAL, typeName);
        return DatastoreServiceFactory.getDatastoreService().prepare(query).countEntities();
    }

    @Override
    public long countByTime(Date from, Date to) {
        com.google.appengine.api.datastore.Query query = new com.google.appengine.api.datastore.Query(Article.class
                .getSimpleName());
        query.addFilter("createTime", FilterOperator.GREATER_THAN_OR_EQUAL, from);
        query.addFilter("createTime", FilterOperator.LESS_THAN, to);
        return DatastoreServiceFactory.getDatastoreService().prepare(query).countEntities();
    }

    @Override
    public Article deleteById(String id) {

        Type t = typeDao.findByName(findAllById(id).getType());
        t.setCountArticle(t.getCountArticle() - 1);

        // need not manual delete - comment
        return delete(findById(Article.class, id));
    }

    @Override
    public Article findAllById(String id) {
        return findById(Article.class, id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Article findAll(String alias, Date createTime) {
        List<Article> articles = null;
        PersistenceManager manager = JdoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class,
                                           "alias == aliasParam && createTime >= Today && createTime < Tomorrow");
            query.declareParameters("String aliasParam, java.util.Date Today, java.util.Date Tomorrow");
            articles = (List<Article>) query.execute(alias, DateUtil.getZeroClock(createTime), DateUtil
                    .getTwentyFourClock(createTime));
            return articles.size() > 0 ? articles.get(0) : null;
        } catch (Exception e) {
            logger.error(e);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findAllByTime(int start, int length, Date from, Date to) {
        List<Article> articles = null;
        PersistenceManager manager = JdoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class, "createTime >= from && createTime < to");
            query.declareParameters("java.util.Date from, java.util.Date to");
            query.setRange(start, start + length);
            query.setOrdering("createTime desc");
            articles = (List<Article>) query.execute(from, to);
            return articles;
        } catch (Exception e) {
            logger.error(e);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findLatast(int size) {
        List<Article> articles = null;
        PersistenceManager manager = JdoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class);
            query.setOrdering("createTime desc");
            query.setRange(0, size);
            articles = (List<Article>) query.execute();
        } catch (Exception e) {
            logger.error(e);
        }
        return articles;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findAllByType(String typeName) {
        Query query = JdoManager.getSession().newQuery(Article.class, "type == typeParam");
        query.declareParameters("String typeParam");
        return (List<Article>) query.execute(typeName);
    }

}
