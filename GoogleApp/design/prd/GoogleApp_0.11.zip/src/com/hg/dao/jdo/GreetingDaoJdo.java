package com.hg.dao.jdo;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hg.core.dao.BaseDaoJdo;
import com.hg.core.dao.JdoManager;
import com.hg.dao.GreetingDao;
import com.hg.pojo.Greeting;

public class GreetingDaoJdo extends BaseDaoJdo implements GreetingDao {

    private static Log logger = LogFactory.getLog(GreetingDaoJdo.class);

    @SuppressWarnings("unchecked")
    @Override
    public List<Greeting> findAll(int start, int length) {
        List<Greeting> greetings = null;
        PersistenceManager manager = JdoManager.getSession();
        try {
            Query query = manager.newQuery(Greeting.class);
            query.setOrdering("date desc");
            query.setRange(start, start + length);
            greetings = (List<Greeting>) query.execute();
        } catch (Exception e) {
            logger.error(e);
        }
        return greetings;
    }

    @Override
    public Greeting insert(Greeting g) {
        return save(g);
    }

    @Override
    public Greeting deleteById(String id) {
        return delete(findById(Greeting.class, id));
    }

    @Override
    public long count() {
        return count(Greeting.class);
    }
}
