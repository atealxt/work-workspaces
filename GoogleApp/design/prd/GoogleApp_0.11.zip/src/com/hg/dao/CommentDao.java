package com.hg.dao;

import java.util.List;

import com.hg.core.dao.IBaseDaoOrm;
import com.hg.pojo.Comment;

public interface CommentDao extends IBaseDaoOrm{

    Comment insert(Comment g);

    List<Comment> findLatast(int size);

    List<Comment> findAll(int start, int length);

    long count();

    Comment deleteById(String id);

}
