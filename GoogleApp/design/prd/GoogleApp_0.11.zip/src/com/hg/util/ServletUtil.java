package com.hg.util;

import java.util.Random;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletUtil {

    /** captcha number's Key */
    public static String CAPTCHA = "CAPTCHA";
    /** captcha number's max value */
    private static int MAX_VALUE = 10;
    /** guest name */
    public static String GUEST_NAME = "GUEST_NAME";
    /** guest contact url */
    public static String GUEST_URL = "GUEST_URL";

    private ServletUtil() {}

    public static String getReqIp(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    /**
     * create captcha and save to session.<br>
     * 在session中生成验证码，并返回运算式的表示形式.<br>
     * 
     * @return operation
     */
    public static String makeCaptcha(HttpSession sess) {

        Random ran = new Random(System.currentTimeMillis());
        int firstNumber = ran.nextInt(MAX_VALUE + 1);
        int secondNumber = ran.nextInt(MAX_VALUE + 1);
        String operator = null;
        int result = -1;
        if (ran.nextInt() % 2 == 0) {
            operator = "+";
            result = firstNumber + secondNumber;
        } else {
            operator = "-";
            result = firstNumber - secondNumber;
        }
        sess.setAttribute(CAPTCHA, result);

        return new StringBuilder().append(firstNumber).append(" ").append(operator)//
                .append(" ").append(secondNumber).append(" ").append("= ").toString();
    }

    public static boolean checkCaptcha(int result, HttpSession sess) {
        return ((Integer) sess.getAttribute(CAPTCHA)).intValue() == result;
    }

    public static String getCookie(HttpServletRequest req, String ckName) {
        Cookie[] cookies = req.getCookies();
        if (cookies == null) {
            return null;
        }
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals(ckName)) {
                return cookie.getValue();
            }
        }
        return null;
    }

    public static void setCookie(HttpServletRequest req, HttpServletResponse resp, String key, String value) {
        delCookieIfExist(req, key);
        Cookie c = new Cookie(key, value);
        c.setMaxAge(3600);
        resp.addCookie(c);
    }

    private static void delCookieIfExist(HttpServletRequest req, String ckName) {
        Cookie[] cookies = req.getCookies();
        if (cookies == null) {
            return;
        }
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals(ckName)) {
                cookie.setMaxAge(0);
                return;
            }
        }
    }
}
