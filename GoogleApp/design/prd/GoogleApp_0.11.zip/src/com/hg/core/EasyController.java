package com.hg.core;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hg.util.StringUtil;

public abstract class EasyController {

    protected void initResponse(HttpServletResponse resp) {
        resp.setContentType("text/html; charset=UTF-8");
        resp.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
        resp.setHeader("Pragma", "no-cache");
    }

    protected int getCurrentPage(HttpServletRequest req, int maxPage) {
        int iPage = 0;
        String page = req.getParameter("page");
        if (!StringUtil.isEmpty(page)) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        if (iPage > maxPage) {
            iPage = maxPage;
        }
        return iPage;
    }

}
