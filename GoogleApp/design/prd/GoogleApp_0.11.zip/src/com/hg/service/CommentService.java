package com.hg.service;

import java.util.List;

import com.hg.dto.CommentInfo;

public interface CommentService {

    List<CommentInfo> getLatestCmts();

    int getMaxPage();

    List<CommentInfo> getList(int pageNo);

    void remove(String id);
}
