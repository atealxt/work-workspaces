package com.hg.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.hg.constant.PagingConstant;
import com.hg.constant.TypeConstant;
import com.hg.dao.ArticleDao;
import com.hg.dao.CommentDao;
import com.hg.dao.TypeDao;
import com.hg.dto.CommentInfo;
import com.hg.dto.Topic;
import com.hg.pojo.Article;
import com.hg.pojo.Comment;
import com.hg.pojo.Type;
import com.hg.pojo.User;
import com.hg.service.ArticleService;
import com.hg.util.DateUtil;
import com.hg.util.GaeUtil;
import com.hg.util.StringUtil;

public class ArticleServiceImpl implements ArticleService {

    private static Log logger = LogFactory.getLog(ArticleServiceImpl.class);

    @Autowired
    private ArticleDao articleDao;

    @Autowired
    private CommentDao commentDao;

    @Autowired
    private TypeDao typeDao;

    @Override
    public boolean postArticle(Topic t) {

        Article article = new Article(t.getTitle(), new User(GaeUtil.getCurrentUser().getNickname(), t.getIp()));
        article.setSummary(t.getSummary());
        article.setPostBySummary(t.isPostBySummary());
        article.setContent(t.getContent());
        if (!StringUtil.isEmpty(t.getAlias()) && StringUtil.isCharOrNum(t.getAlias())) {
            article.setAlias(t.getAlias());
        }
        if (StringUtil.isEmpty(t.getType())) {
            article.setType(TypeConstant.DEFAULT);
        } else {
            article.setType(t.getType());
        }
        // do not update pojo Type,do in Dao flow
        try {
            return articleDao.insert(article) != null;
        } catch (Exception e) {
            logger.error(e);
            return false;
        }
    }

    @Override
    public boolean updateArticle(Topic t) {
        try {
            Article article = articleDao.findAllById(t.getId());

            // update Type
            if (StringUtil.isEmpty(t.getType())) {
                t.setType(TypeConstant.DEFAULT);
            }
            if (StringUtil.isEmpty(article.getType())) {
                // error data check
                article.setType(TypeConstant.DEFAULT);
                Type type = typeDao.findByName(TypeConstant.DEFAULT);
                type.setCountArticle(type.getCountArticle() + 1);
            }
            if (!t.getType().equals(article.getType())) {
                Type typeOld = typeDao.findByName(article.getType());
                typeOld.setCountArticle(typeOld.getCountArticle() - 1);
                Type typeNew = typeDao.findByName(t.getType());
                typeNew.setCountArticle(typeNew.getCountArticle() + 1);
            }
            article.setType(t.getType());
            article.setTitle(t.getTitle());
            article.setSummary(t.getSummary());
            article.setContent(t.getContent());
            article.setPostBySummary(t.isPostBySummary());
            if (!StringUtil.isEmpty(t.getAlias()) && StringUtil.isCharOrNum(t.getAlias())) {
                article.setAlias(t.getAlias());
            } else {
                article.setAlias(null);
            }

            System.out.println(1 / 0);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }

        return true;
    }

    @Override
    public boolean updReadCnt(String id, String ip) {
        Article article = articleDao.findAllById(id);
        Set<String> set = article.getReadIP();
        set.add(ip);
        article.setReadIP(set);
        return true;
    }

    @Override
    public boolean updateComment(CommentInfo info) {
        Article article = articleDao.findAllById(info.getArticleId());
        Comment cmt = new Comment(info.getTitle(), info.getContent(), //
                                  new User(info.getName(), info.getContact(), info.getIp()), article);
        commentDao.insert(cmt);
        return true;
    }

    @Override
    public List<Topic> getList(int pageNo, boolean manager) {
        return getList(pageNo, manager, null);
    }

    @Override
    public List<Topic> getList(int pageNo, boolean manager, String typeName) {
        List<Article> arts = null;

        if (StringUtil.isEmpty(typeName)) {
            arts = manager //
                    ? articleDao.findAll(pageNo * PagingConstant.ARTICLE_MANAGE, PagingConstant.ARTICLE_MANAGE) //
                    : articleDao.findAll(pageNo * PagingConstant.ARTICLE_VIEW, PagingConstant.ARTICLE_VIEW);
        } else {
            arts = manager //
                    ? articleDao.findAll(pageNo * PagingConstant.ARTICLE_MANAGE, PagingConstant.ARTICLE_MANAGE,
                                         typeName) //
                    : articleDao.findAll(pageNo * PagingConstant.ARTICLE_VIEW, PagingConstant.ARTICLE_VIEW, typeName);
        }
        return convertVo(arts);
    }

    @Override
    public List<Topic> getList(int pageNo, Date from, Date to) {
        List<Article> arts = articleDao.findAllByTime(pageNo * PagingConstant.ARTICLE_VIEW,
                                                      PagingConstant.ARTICLE_VIEW, from, to);
        return convertVo(arts);
    }

    @Override
    public int getMaxPage(boolean manager) {
        int count = (int) articleDao.count();
        int maxP = 0;
        if (manager) {
            maxP = count / PagingConstant.ARTICLE_MANAGE;
            if (count % PagingConstant.ARTICLE_MANAGE == 0) {
                maxP--;
            }
        } else {
            maxP = count / PagingConstant.ARTICLE_VIEW;
            if (count % PagingConstant.ARTICLE_VIEW == 0) {
                maxP--;
            }
        }
        return maxP < 0 ? 0 : maxP;
    }

    @Override
    public int getMaxPage(String typeName, boolean manager) {
        if (StringUtil.isEmpty(typeName)) {
            return getMaxPage(manager);
        }
        int count = (int) articleDao.countByType(typeName);
        int maxP = 0;
        if (manager) {
            maxP = count / PagingConstant.ARTICLE_MANAGE;
            if (count % PagingConstant.ARTICLE_MANAGE == 0) {
                maxP--;
            }
        } else {
            maxP = count / PagingConstant.ARTICLE_VIEW;
            if (count % PagingConstant.ARTICLE_VIEW == 0) {
                maxP--;
            }
        }
        return maxP < 0 ? 0 : maxP;
    }

    @Override
    public int getMaxPage(Date from, Date to) {
        int count = (int) articleDao.countByTime(from, to);
        int maxP = count / PagingConstant.ARTICLE_VIEW;
        if (count % PagingConstant.ARTICLE_VIEW == 0) {
            maxP--;
        }
        return maxP;
    }

    @Override
    public void remove(String id) {
        articleDao.deleteById(id);
    }

    @Override
    public Topic getById(String id) {
        return convertVo(articleDao.findAllById(id));
    }

    @Override
    public Topic getByAlias(String alias, String createTime) {
        return convertVo(articleDao.findAll(alias, DateUtil.parse(createTime, "yyyyMMdd")));
    }

    @Override
    public Article getArticleById(String id) {
        return articleDao.findAllById(id);
    }

    @Override
    public List<Topic> getLatest(int size) {
        List<Article> arts = articleDao.findLatast(size);
        return convertVo(arts);
    }

    private Topic convertVo(Article art) {
        if (art == null) {
            return null;
        }
        Topic vo = new Topic();
        BeanUtils.copyProperties(art, vo);
        vo.setCreateby(art.getFounder().getName());
        vo.setCreateTime(art.getCreateTime());
        vo.setReadCnt(art.getReadIP().size());
        vo.setCommentCnt(art.getComments().size());
        return vo;
    }

    private List<Topic> convertVo(List<Article> arts) {
        List<Topic> vos = new ArrayList<Topic>(arts.size());
        for (Article a : arts) {
            vos.add(convertVo(a));
        }
        return vos;
    }

    @Override
    public boolean contains(Date from, Date to) {
        return articleDao.countByTime(from, to) > 0;
    }

}
