/*
 * Copyright 2009 atealxt@gmail.com All rights reserved.
 */
function init(){
    if($("selAll")){
        Event.observe($("selAll"), "click", selAll);
    }
    if($("addCategory")){
        Event.observe($("addCategory"), "click", addCategory);
    }
}

function selAll(){
    $A(cmnApi.$N("sel")).each(function(node){
        node.checked = !node.checked;
    });
}

function beforeDel() {
    if (confirm("您确定要删除该信息？")) {
        return true;
    }
    return false;
}

function addCategory(){
    $("fCategory").action = "?m=add";
}

function edit(tId,oldName){
    var newName = window.prompt("请输入新的分类名",oldName);
    if(newName!=null){
        $("Category").value = newName;
        $("fCategory").action = "?m=upd&id=" + tId;
        $("fCategory").submit();
    }
}

cmnApi.addOnEventListener("load", init);