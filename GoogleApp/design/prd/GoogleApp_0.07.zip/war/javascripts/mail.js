/*
 * Copyright 2009 atealxt@gmail.com All rights reserved.
 */
function pageInit() {
  if($("reset")){
      Event.observe($("reset"), "click", resetForm);
      Event.observe($("textStyle"), "click", plainText);
  }
}

function resetForm() {
  document.getElementById("to").value = "";
  document.getElementById("Subject").value = "";
  document.getElementById("content").value="";
  if(document.getElementsByTagName("iframe")[0]){
      document.getElementsByTagName("iframe")[0].contentWindow.document.body.innerHTML = "";
  }
}

function plainText(){
  if (!confirm("Converting this message to plain text will lose some formatting.\r\nAre you sure you want to continue?")) {
    return;
  }
  $("base").value = "base";
  $("textStyle").innerHTML = "";
  var content = getBaseContent();
  tinyMCE.get('content').hide();
  $("content").value = content;
}

function getBaseContent(){
  var content = document.getElementsByTagName("iframe")[0].contentWindow.document.body.innerHTML;
  if(content == "<br>"){
    return "";
  }
  content = content.replace("<br>","\r\n").replace(/<\/?.+?>/g,"");
  return content;
}

cmnApi.addOnEventListener("load", pageInit);