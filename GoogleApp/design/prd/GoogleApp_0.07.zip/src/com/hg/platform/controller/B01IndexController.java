package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.util.RoleUtil;

@Controller
public class B01IndexController extends EasyController {

    @RequestMapping("/admin.html")
    public void indexing(HttpServletResponse resp) throws IOException {
        if (!RoleUtil.isMaster()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        makeTemplate("admin/index.ftl", makeRootIndexing(), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootIndexing() {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Website Administer");
        return root;
    }

}
