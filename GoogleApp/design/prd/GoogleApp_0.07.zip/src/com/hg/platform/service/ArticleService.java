package com.hg.platform.service;

import java.util.List;

import com.hg.components.dto.CommentInfo;
import com.hg.components.dto.Topic;
import com.hg.components.pojo.Article;

public interface ArticleService {

    boolean postArticle(Topic t);

    boolean updateArticle(Topic t);

    boolean updReadCnt(String id, String ip);

    boolean updateComment(CommentInfo info);

    /**
     * @param pageNo 所需要数据的页号
     * @param manager 是后台管理的请求还是前台浏览的请求
     */
    List<Topic> getList(int pageNo, boolean manager);

    List<Topic> getList(int pageNo, boolean manager, String typeName);

    Topic getById(String id);

    Topic getByAlias(String alias, String createTime);

    List<Topic> getLatest(int size);

    Article getArticleById(String id);

    int getMaxPage(boolean manager);

    int getMaxPage(String typeName, boolean manager);

    void remove(String id);
}
