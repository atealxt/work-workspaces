package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.EasyController;

@Controller
public class Z00SpecialController extends EasyController {

    @RequestMapping("/releasenote.html")
    public void releaseNote(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        makeTemplate("releasenote.ftl", makeRootRelease(req), resp);
    }

    private Map<String, Object> makeRootRelease(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Release Notes");
        return root;
    }
}
