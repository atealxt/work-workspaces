package com.hg.platform.service.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.hg.components.dao.ArticleDao;
import com.hg.components.dao.CommentDao;
import com.hg.components.dao.TypeDao;
import com.hg.components.dto.CommentInfo;
import com.hg.components.dto.Topic;
import com.hg.components.pojo.Article;
import com.hg.components.pojo.Comment;
import com.hg.components.pojo.Type;
import com.hg.components.pojo.User;
import com.hg.constant.PagingConstant;
import com.hg.constant.TypeConstant;
import com.hg.core.DaoManager;
import com.hg.platform.service.ArticleService;
import com.hg.util.DateUtil;
import com.hg.util.GaeUtil;
import com.hg.util.StringUtil;

public class ArticleServiceImpl implements ArticleService {

    private static Log logger = LogFactory.getLog(ArticleServiceImpl.class);

    @Autowired
    private ArticleDao articleDao;

    @Autowired
    private CommentDao commentDao;

    @Autowired
    private TypeDao typeDao;

    @Override
    public boolean postArticle(Topic t) {

        Article article = new Article(t.getTitle(), new User(GaeUtil.getCurrentUser().getNickname()));
        article.setSummary(t.getSummary());
        article.setPostBySummary(t.isPostBySummary());
        article.setContent(t.getContent());
        if (!StringUtil.isEmpty(t.getAlias()) && StringUtil.isCharOrNum(t.getAlias())) {
            article.setAlias(t.getAlias());
        }
        if (StringUtil.isEmpty(t.getType())) {
            article.setType(TypeConstant.DEFAULT);
        } else {
            article.setType(t.getType());
        }
        // do not update pojo Type,do in Dao flow
        try {
            return articleDao.insert(article) != null;
        } catch (Exception e) {
            logger.error(e);
            return false;
        }
    }

    @Override
    public boolean updateArticle(Topic t) {
        try {
            Article article = articleDao.findAllById(t.getId());

            // update Type
            if (StringUtil.isEmpty(t.getType())) {
                t.setType(TypeConstant.DEFAULT);
            }
            if (StringUtil.isEmpty(article.getType())) {
                // error data check
                DaoManager.getSession().currentTransaction().begin();
                article.setType(TypeConstant.DEFAULT);
                Type type = typeDao.findAllByName(TypeConstant.DEFAULT);
                type.setCountArticle(type.getCountArticle() + 1);
                DaoManager.getSession().currentTransaction().commit();
            }
            if (!t.getType().equals(article.getType())) {
                DaoManager.getSession().currentTransaction().begin();
                Type typeOld = typeDao.findAllByName(article.getType());
                typeOld.setCountArticle(typeOld.getCountArticle() - 1);
                Type typeNew = typeDao.findAllByName(t.getType());
                typeNew.setCountArticle(typeNew.getCountArticle() + 1);
                DaoManager.getSession().currentTransaction().commit();
            }
            article.setType(t.getType());
            article.setTitle(t.getTitle());
            article.setSummary(t.getSummary());
            article.setContent(t.getContent());
            article.setPostBySummary(t.isPostBySummary());
            if (!StringUtil.isEmpty(t.getAlias()) && StringUtil.isCharOrNum(t.getAlias())) {
                article.setAlias(t.getAlias());
            } else {
                article.setAlias(null);
            }
        } catch (Exception e) {
            logger.error(e);
            DaoManager.getSession().currentTransaction().rollback();
        }

        return true;
    }

    @Override
    public boolean updReadCnt(String id, String ip) {
        Article article = articleDao.findAllById(id);
        // article.getReadIP().add(ip);
        Set<String> set = article.getReadIP();
        set.add(ip);
        article.setReadIP(set);
        return true;
    }

    @Override
    public boolean updateComment(CommentInfo info) {
        Article article = articleDao.findAllById(info.getArticleId());
        Comment cmt = new Comment(info.getTitle(), info.getContent(), //
                                  new User(info.getName(), info.getContact(), info.getIp()), article);
        commentDao.insert(cmt);
        return true;
    }

    @Override
    public List<Topic> getList(int pageNo, boolean manager) {
        return getList(pageNo, manager, null);
    }

    @Override
    public List<Topic> getList(int pageNo, boolean manager, String typeName) {
        List<Article> arts = null;
        if (StringUtil.isEmpty(typeName)) {
            arts = manager //
                    ? articleDao.findAll(pageNo * PagingConstant.ARTICLE_MANAGE, PagingConstant.ARTICLE_MANAGE) //
                    : articleDao.findAll(pageNo * PagingConstant.ARTICLE_VIEW, PagingConstant.ARTICLE_VIEW);
        } else {
            arts = manager //
                    ? articleDao.findAll(pageNo * PagingConstant.ARTICLE_MANAGE, PagingConstant.ARTICLE_MANAGE,
                                         typeName) //
                    : articleDao.findAll(pageNo * PagingConstant.ARTICLE_VIEW, PagingConstant.ARTICLE_VIEW, typeName);
        }
        List<Topic> vos = new ArrayList<Topic>();
        for (Article a : arts) {
            vos.add(convertVo(a));
        }
        return vos;
    }

    @Override
    public int getMaxPage(boolean manager) {
        return getMaxPage(null, manager);
    }

    @Override
    public int getMaxPage(String typeName, boolean manager) {
        int count = 0;
        if (StringUtil.isEmpty(typeName)) {
            count = (int) articleDao.count();
        } else {
            count = (int) articleDao.count(typeName);
        }
        int maxP = manager //
                ? count / PagingConstant.ARTICLE_MANAGE //
                : count / PagingConstant.ARTICLE_VIEW;
        if (count % PagingConstant.ARTICLE_MANAGE == 0) {
            maxP--;
        }
        return maxP;
    }

    @Override
    public void remove(String id) {
        articleDao.deleteById(id);
    }

    @Override
    public Topic getById(String id) {
        return convertVo(articleDao.findAllById(id));
    }

    @Override
    public Topic getByAlias(String alias, String createTime) {
        Topic t = null;
        try {
            t = convertVo(articleDao.findAllByAlias(alias, DateUtil.getDateFormat(createTime, "yyyyMMdd")));
        } catch (ParseException e) {
            logger.error(e);
        }
        return t;
    }

    @Override
    public Article getArticleById(String id) {
        return articleDao.findAllById(id);
    }

    private Topic convertVo(Article art) {
        if (art == null) {
            return null;
        }
        Topic vo = new Topic();
        BeanUtils.copyProperties(art, vo);
        vo.setCreateby(art.getFounder().getName());
        vo.setCreateTime(art.getCreateTime());
        vo.setReadCnt(art.getReadIP().size());
        vo.setCommentCnt(art.getComments().size());
        return vo;
    }

    @Override
    public List<Topic> getLatest(int size) {
        List<Article> arts = articleDao.findLatast(size);
        List<Topic> vos = new ArrayList<Topic>(arts.size());
        for (Article a : arts) {
            vos.add(convertVo(a));
        }
        return vos;
    }

}
