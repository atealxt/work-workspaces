package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.platform.service.ArticleService;
import com.hg.util.RoleUtil;
import com.hg.util.StringUtil;

@Controller
public class B03ArticleController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @RequestMapping("/articlelist.html")
    public void list(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!RoleUtil.isMaster()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        if ("d".equals(req.getParameter("m"))) {
            articleService.remove(req.getParameter("id"));
        }

        makeTemplate("admin/article.ftl", makeRootList(req), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootList(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Articles");

        int iPage = 0;
        String page = req.getParameter("page");
        if (!StringUtil.isEmpty(page)) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        int maxP = articleService.getMaxPage(true);
        if (iPage > maxP) {
            iPage = maxP;
        }
        root.put("currentP", iPage);
        root.put("maxP", maxP);

        root.put("articles", articleService.getList(iPage, true));
        return root;
    }
}
