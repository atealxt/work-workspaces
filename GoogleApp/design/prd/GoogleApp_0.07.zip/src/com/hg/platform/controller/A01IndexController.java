package com.hg.platform.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.appengine.api.users.User;
import com.hg.components.dto.PageLink;
import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.platform.service.ArticleService;
import com.hg.util.GaeUtil;

@Controller
public class A01IndexController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @RequestMapping("/index.html")
    public void indexing(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        makeTemplate("index.ftl", makeRootIndexing(req), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootIndexing(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Hero's Grave");
        // root.put("subtitle", "Object-oriented, Open Source, Framework, Agile, Cloud Computing, Programming ideas");
        root.put("links", makeLink());
        root.put("appspots", makeAppLink());
        root.put("articles", articleService.getLatest(1));

        User user = GaeUtil.getCurrentUser();
        if (user != null) {
            root.put("user", user);
            root.put("loginUrl", "");
            root.put("logoutUrl", GaeUtil.getLogoutURL(req.getRequestURI()));
        } else {
            root.put("loginUrl", GaeUtil.getLoginURL(req.getRequestURI()));
            root.put("logoutUrl", "");
        }

        return root;
    }

    private List<PageLink> makeLink() {
        List<PageLink> links = new ArrayList<PageLink>();

        PageLink link = null;

        link = new PageLink();
        link.setTitle("Only webmaster can use");
        link.setLink("/admin.html");
        link.setMsgShow("Website Administer");
        links.add(link);

        link = new PageLink();
        link.setTitle("Google Applications Overview");
        link.setLink("http://appengine.google.com/");
        link.setMsgShow("My Applications");
        links.add(link);

        link = new PageLink();
        link.setTitle("Google Website Analysis");
        link.setLink("https://www.google.com/webmasters/tools");
        link.setMsgShow("Google Webmaster Tool");
        links.add(link);

        link = new PageLink();
        link.setTitle("Google App Engine Official Site");
        link.setLink("http://code.google.com/appengine/");
        link.setMsgShow("Google App Engine");
        links.add(link);

        link = new PageLink();
        link.setTitle("Free Online Google Sitemap Generator");
        link.setLink("http://www.xml-sitemaps.com/");
        link.setMsgShow("Google Sitemap Generator");
        links.add(link);

        link = new PageLink();
        link.setTitle("My Chinese Programming Technology Blog");
        link.setLink("http://www.blogjava.net/atealxt");
        link.setMsgShow("BlogJava");
        links.add(link);

        link = new PageLink();
        link.setTitle("My Chinese Life Blog");
        link.setLink("http://atealxt.ycool.com/");
        link.setMsgShow("Atea的勇士坟墓");
        links.add(link);

        return links;
    }

    private List<PageLink> makeAppLink() {
        List<PageLink> links = new ArrayList<PageLink>();

        PageLink link = null;

        link = new PageLink();
        link.setTitle("Lin Cong(丛林)'s Ideas Repository");
        link.setLink("http://ihere.appspot.com/");
        link.setMsgShow("iHere");
        links.add(link);

        link = new PageLink();
        link.setTitle("Casey Lai's Blog");
        link.setLink("http://casey-lai.appspot.com/");
        link.setMsgShow("Casey Lai");
        links.add(link);

        link = new PageLink();
        link.setTitle("community, blog, 新闻, 技术, 八卦");
        link.setLink("http://niubi.appspot.com/");
        link.setMsgShow("NiuBi.de");
        links.add(link);

        return links;
    }
}
