package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.components.dto.TypeInfo;
import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.platform.service.TypeService;
import com.hg.util.RoleUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/typelist.html")
public class B05TypeController extends EasyController {

    @Autowired
    private TypeService typeService;

    @RequestMapping
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!RoleUtil.isMaster()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        if ("add".equals(req.getParameter("m"))) {
            addType(req, resp);
        } else if ("del".equals(req.getParameter("m"))) {
            delType(req, resp);
        } else if ("upd".equals(req.getParameter("m"))) {
            updType(req, resp);
        } else {
            makeTemplate("admin/type.ftl", makeRootMain(req), resp);
        }
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootMain(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Type");
        root.put("types", typeService.getTypes());
        return root;
    }

    private void addType(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (StringUtil.isEmpty(req.getParameter("Category"), true)) {
            setErr(req, resp, "名称不能为空！");
        } else {
            TypeInfo info = new TypeInfo();
            info.setName(req.getParameter("Category"));
            if (!typeService.postType(info)) {
                setErr(req, resp, "不能添加重复的分类！");
            } else {
                resp.sendRedirect("typelist.html");
            }
        }
    }

    private void delType(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!typeService.removeType(req.getParameter("id"))) {
            setErr(req, resp, "不能删除默认分类！");
        } else {
            resp.sendRedirect("typelist.html");
        }
    }

    private void updType(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        TypeInfo info = new TypeInfo();
        info.setId(req.getParameter("id"));
        info.setName(req.getParameter("Category"));
        if (!typeService.updateType(info)) {
            setErr(req, resp, "更新失败！");
        } else {
            DaoManager.closeSession();
            resp.sendRedirect("typelist.html");
        }
    }

    private void setErr(HttpServletRequest req, HttpServletResponse resp, String errMsg) throws IOException {
        StringBuilder sb = new StringBuilder("<b>");
        sb.append(errMsg);
        sb.append("</b>");
        sb.append("<a href=\"");
        sb.append(req.getRequestURI());
        sb.append("\">返回</a>");

        initResponse(resp);
        resp.getWriter().println(sb.toString());
    }
}
