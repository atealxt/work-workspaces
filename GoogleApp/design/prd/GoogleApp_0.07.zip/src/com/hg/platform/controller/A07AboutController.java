package com.hg.platform.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.components.dto.PageLink;
import com.hg.core.DaoManager;
import com.hg.core.EasyController;

@Controller
@RequestMapping("/about.html")
public class A07AboutController extends EasyController {

    @RequestMapping
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        makeTemplate("about.ftl", makeRootMain(req), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootMain(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "About");
        root.put("technology", makeTechLink());
        return root;
    }

    private List<PageLink> makeTechLink() {
        List<PageLink> links = new ArrayList<PageLink>();

        PageLink link = new PageLink();
        link.setTitle("Google App Engine");
        link.setLink("http://code.google.com/appengine/");
        link.setMsgShow("Offers users the ability to build and host web applications on Google's infrastructure.");
        links.add(link);

        link = new PageLink();
        link.setTitle("Spring Framework");
        link.setLink("http://www.springsource.org/");
        link.setMsgShow("An open source application framework.");
        links.add(link);

        link = new PageLink();
        link.setTitle("FreeMarker");
        link.setLink("http://freemarker.org/");
        link.setMsgShow("Java Template Engine Library.");
        links.add(link);

        link = new PageLink();
        link.setTitle("Prototype");
        link.setLink("http://www.prototypejs.org/");
        link.setMsgShow("A JavaScript Framework that aims to ease development of dynamic web applications.");
        links.add(link);

        link = new PageLink();
        link.setTitle("TinyMCE");
        link.setLink("http://tinymce.moxiecode.com/");
        link.setMsgShow("A platform independent web based Javascript HTML WYSIWYG editor control.");
        links.add(link);

        link = new PageLink();
        link.setTitle("SyntaxHighlighter");
        link.setLink("http://alexgorbatchev.com/wiki/SyntaxHighlighter/");
        link.setMsgShow("A fully functional self-contained code syntax highlighter developed in JavaScript.");
        links.add(link);

        link = new PageLink();
        link.setTitle("Free CSS Templates");
        link.setLink("http://www.freecsstemplates.org/");
        link.setMsgShow("Free standards compliant CSS templates.");
        links.add(link);

        return links;
    }
}