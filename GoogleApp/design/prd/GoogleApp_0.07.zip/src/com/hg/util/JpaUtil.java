package com.hg.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaUtil {

    private static final EntityManagerFactory INSTANCE = Persistence
            .createEntityManagerFactory("transactions-optional");

    private JpaUtil() {
    }

    public static EntityManagerFactory getFactory() {
        return INSTANCE;
    }

}
