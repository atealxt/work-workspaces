package com.hg.util;

import javax.jdo.JDOHelper; // import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;

public class JdoUtil {

    private static final PersistenceManagerFactory pmfInstance = JDOHelper
            .getPersistenceManagerFactory("transactions-optional");

    private JdoUtil() {
    }

    public static PersistenceManagerFactory getPMF() {
        return pmfInstance;
    }
}
