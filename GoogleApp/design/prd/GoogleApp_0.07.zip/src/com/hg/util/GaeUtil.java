package com.hg.util;

import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;

public class GaeUtil {

    private GaeUtil() {
    };

    public static User getCurrentUser() {
        UserService userService = UserServiceFactory.getUserService();
        final User user = userService.getCurrentUser();
        return user;
    }

    public static String getLogoutURL(String origin) {
        UserService userService = UserServiceFactory.getUserService();
        return userService.createLogoutURL(origin);
    }

    public static String getLoginURL(String origin) {
        UserService userService = UserServiceFactory.getUserService();
        return userService.createLoginURL(origin);
    }

}
