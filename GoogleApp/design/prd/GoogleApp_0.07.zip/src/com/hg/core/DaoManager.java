package com.hg.core;

import javax.jdo.PersistenceManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hg.util.JdoUtil;

public class DaoManager {

    private static Log logger = LogFactory.getLog(DaoManager.class);

    private static final ThreadLocal<PersistenceManager> session = new ThreadLocal<PersistenceManager>();

    private DaoManager() {
    }

    public static PersistenceManager getSession() {

        PersistenceManager sess = session.get();
        if (sess == null || sess.isClosed()) {
            logger.debug("create new session");
            sess = JdoUtil.getPMF().getPersistenceManager();
            session.set(sess);
        }
        return sess;
    }

    public static void closeSession() {
        PersistenceManager sess = session.get();
        session.set(null);

        if (sess != null && !sess.isClosed()) {
            logger.debug("close session");
            sess.close();
        }
    }
}
