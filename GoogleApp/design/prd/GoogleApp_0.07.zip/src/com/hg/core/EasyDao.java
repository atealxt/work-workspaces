package com.hg.core;

import javax.jdo.PersistenceManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Query;

public abstract class EasyDao {

    private static Log logger = LogFactory.getLog(EasyDao.class);

    @SuppressWarnings("unchecked")
    protected <T> T FindById(Class clazz, Object id) {
        PersistenceManager manager = DaoManager.getSession();
        T t = null;
        try {
            t = (T) manager.getObjectById(clazz, id);
        } catch (Exception e) {
            logger.error(e);
        }
        return t;
    }

    protected <T> T Insert(T t) {
        PersistenceManager manager = DaoManager.getSession();
        try {
            manager.makePersistent(t);
        } catch (Exception e) {
            logger.error(e);
        } finally {
            manager.close();
        }
        return t;
    }

    /**
     * Needn't
     *
     * @deprecated
     */
    protected <T> T Update(T t) {
        PersistenceManager manager = DaoManager.getSession();
        try {
            manager.close();
        } catch (Exception e) {
            logger.error(e);
        }
        return t;
    }

    @SuppressWarnings("unchecked")
    protected <T> T Delete(Class clazz, Object id) {
        PersistenceManager manager = DaoManager.getSession();
        Object o = null;
        try {
            o = manager.getObjectById(clazz, id);
            manager.deletePersistent(o);
        } catch (Exception e) {
            logger.error(e);
        } finally {
            manager.close();
        }
        return (T) o;
    }

    @SuppressWarnings("unchecked")
    protected <T> T Delete(Object obj) {
        PersistenceManager manager = DaoManager.getSession();
        try {
            manager.deletePersistent(obj);
        } catch (Exception e) {
            logger.error(e);
        } finally {
            manager.close();
        }
        return (T) obj;
    }

    @SuppressWarnings("unchecked")
    protected long Count(Class clazz) {
        Query query = new Query(clazz.getSimpleName());
        return DatastoreServiceFactory.getDatastoreService().prepare(query).countEntities();
    }
}
