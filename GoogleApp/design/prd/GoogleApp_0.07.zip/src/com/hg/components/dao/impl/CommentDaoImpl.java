package com.hg.components.dao.impl;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hg.components.dao.CommentDao;
import com.hg.components.pojo.Article;
import com.hg.components.pojo.Comment;
import com.hg.core.DaoManager;
import com.hg.core.EasyDao;

public class CommentDaoImpl extends EasyDao implements CommentDao {

    private static Log logger = LogFactory.getLog(CommentDaoImpl.class);

    @Override
    public Comment insert(Comment g) {
        PersistenceManager manager = DaoManager.getSession();
        try {
            Article article = manager.getObjectById(Article.class, g.getArticle().getId());
            g.setArticle(article);
            article.getComments().add(g); // important
            manager.makePersistent(g);
        } catch (Exception e) {
            logger.error(e);
        } finally {
            manager.close();
        }
        return g;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Comment> findLatast(int size) {
        List<Comment> comments = null;
        PersistenceManager manager = DaoManager.getSession();
        try {
            Query query = manager.newQuery(Comment.class);
            query.setOrdering("createTime desc");
            query.setRange(0, size);
            comments = (List<Comment>) query.execute();
        } catch (Exception e) {
            logger.error(e);
        }
        return comments;
    }

    @Override
    public long count() {
        return Count(Comment.class);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Comment> findAll(int start, int length) {
        List<Comment> comments = null;
        PersistenceManager manager = DaoManager.getSession();
        try {
            Query query = manager.newQuery(Comment.class);
            query.setOrdering("createTime desc");
            query.setRange(start, start + length);
            comments = (List<Comment>) query.execute();
        } catch (Exception e) {
            logger.error(e);
        }
        return comments;
    }

    @Override
    public Comment deleteById(String id) {
        return Delete(Comment.class, id);
    }

}
