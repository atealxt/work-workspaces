package com.hg.components.dao.impl;

import java.util.Date;
import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Query.FilterOperator;
import com.hg.components.dao.ArticleDao;
import com.hg.components.dao.TypeDao;
import com.hg.components.pojo.Article;
import com.hg.components.pojo.Type;
import com.hg.core.DaoManager;
import com.hg.core.EasyDao;
import com.hg.util.DateUtil;

public class ArticleDaoImpl extends EasyDao implements ArticleDao {

    private static Log logger = LogFactory.getLog(ArticleDaoImpl.class);

    @Autowired
    private TypeDao typeDao;

    @Override
    public Article insert(Article a) {

        if (a.getAlias() != null && findAllByAlias(a.getAlias(), a.getCreateTime()) != null) {
            // 一天之内的文章的别名不能有重复
            return null;
        }

        // 首先更新对应的文章分类数量
        Type t = typeDao.findAllByName(a.getType());
        t.setCountArticle(t.getCountArticle() + 1);

        return Insert(a);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findAll(int start, int length) {
        List<Article> articles = null;
        PersistenceManager manager = DaoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class);
            query.setOrdering("createTime desc");
            query.setRange(start, start + length);
            articles = (List<Article>) query.execute();
        } catch (Exception e) {
            logger.error(e);
        }
        return articles;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findAll(int start, int length, String typeName) {
        List<Article> articles = null;
        PersistenceManager manager = DaoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class, "type == typeParam");
            query.declareParameters("String typeParam");
            query.setOrdering("createTime desc");
            query.setRange(start, start + length);
            articles = (List<Article>) query.execute(typeName);
        } catch (Exception e) {
            logger.error(e);
        }
        return articles;
    }

    @Override
    public long count() {
        return Count(Article.class);
    }

    @Override
    public long count(String typeName) {
        com.google.appengine.api.datastore.Query query = new com.google.appengine.api.datastore.Query(Article.class
                .getSimpleName());
        query.addFilter("type", FilterOperator.EQUAL, typeName);
        return DatastoreServiceFactory.getDatastoreService().prepare(query).countEntities();
    }

    @Override
    public Article deleteById(String id) {

        // 首先更新对应的文章分类数量
        Type t = typeDao.findAllByName(findAllById(id).getType());
        t.setCountArticle(t.getCountArticle() - 1);

        // 不需要手动删除级联数据 - comment
        return Delete(Article.class, id);
    }

    @Override
    public Article findAllById(String id) {
        return FindById(Article.class, id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Article findAllByAlias(String alias, Date createTime) {
        List<Article> articles = null;
        PersistenceManager manager = DaoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class,
                                           "alias == aliasParam && createTime >= Today && createTime < Tomorrow");
            query.declareParameters("String aliasParam, java.util.Date Today, java.util.Date Tomorrow");
            articles = (List<Article>) query.execute(alias, DateUtil.getToday(createTime), DateUtil
                    .getTomorrow(createTime));
            return articles.size() > 0 ? articles.get(0) : null;
        } catch (Exception e) {
            logger.error(e);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findLatast(int size) {
        List<Article> articles = null;
        PersistenceManager manager = DaoManager.getSession();
        try {
            Query query = manager.newQuery(Article.class);
            query.setOrdering("createTime desc");
            query.setRange(0, size);
            articles = (List<Article>) query.execute();
        } catch (Exception e) {
            logger.error(e);
        }
        return articles;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Article> findAllByType(String typeName) {
        Query query = DaoManager.getSession().newQuery(Article.class, "type == typeParam");
        query.declareParameters("String typeParam");
        return (List<Article>) query.execute(typeName);
    }

}
