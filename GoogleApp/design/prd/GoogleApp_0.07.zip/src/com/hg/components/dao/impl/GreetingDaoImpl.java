package com.hg.components.dao.impl;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hg.components.dao.GreetingDao;
import com.hg.components.pojo.Greeting;
import com.hg.core.DaoManager;
import com.hg.core.EasyDao;

public class GreetingDaoImpl extends EasyDao implements GreetingDao {

    private static Log logger = LogFactory.getLog(GreetingDaoImpl.class);

    @SuppressWarnings("unchecked")
    @Override
    public List<Greeting> findAll(int start, int length) {
        // List<Greeting> greetings = CacheUtil.get(CacheConstant.GREETING_ALL);
        // if (greetings == null) {
        List<Greeting> greetings = null;
        PersistenceManager manager = DaoManager.getSession();
        try {
            Query query = manager.newQuery(Greeting.class);
            query.setOrdering("date desc");
            query.setRange(start, start + length);
            greetings = (List<Greeting>) query.execute();
//            greetings = (List<Greeting>) manager.detachCopyAll(greetings);
        } catch (Exception e) {
            logger.error(e);
        } finally {
            // manager.close();
        }
        // }
        return greetings;
    }

    @Override
    public Greeting insert(Greeting g) {
        return Insert(g);
    }

    @Override
    public Greeting deleteById(String id) {
        return Delete(Greeting.class, id);
    }

    @Override
    public long count() {
        return Count(Greeting.class);
    }
}
