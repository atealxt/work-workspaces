package com.hg.constant;

/**
 * 系统分页大小的常量类
 */
public class PagingConstant {

    public final static int ARTICLE_MANAGE = 10;

    public final static int ARTICLE_VIEW = 5;

    public final static int LATEST_COMMENT = 5;

    public final static int COMMENT_MANAGE = 10;

}
