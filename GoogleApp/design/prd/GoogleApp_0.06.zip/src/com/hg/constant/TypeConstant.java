package com.hg.constant;

public class TypeConstant {

    private TypeConstant() {
    }

    public static String DEFAULT = "Unclassified";// support changing
}
