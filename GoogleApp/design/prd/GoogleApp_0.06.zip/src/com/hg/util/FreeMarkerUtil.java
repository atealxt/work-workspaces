package com.hg.util;

import java.io.IOException;
import java.util.Locale;

import com.hg.platform.configeration.ServletConfig;

import freemarker.template.Configuration;
import freemarker.template.ObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

public class FreeMarkerUtil {

    private static Configuration cfg;

    private FreeMarkerUtil() {
    }

    private synchronized static void init() {
        // Initialize the FreeMarker configuration;
        // - Create a configuration instance
        cfg = new Configuration();
        // - Templates are stoted in the WEB-INF/templates directory of the Web app.
        cfg.setServletContextForTemplateLoading(ServletConfig.getRealServletContext(), "WEB-INF/templates");
        // - Set update dealy to 0 for now, to ease debugging and testing.
        // Higher value should be used in production environment.
        cfg.setTemplateUpdateDelay(0);
        // - Set an error handler that prints errors so they are readable with a HTML browser.
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.IGNORE_HANDLER);// HTML_DEBUG_HANDLER
        // - Use beans wrapper (recommmended for most applications)
        cfg.setObjectWrapper(ObjectWrapper.BEANS_WRAPPER);
        // - Set the default charset of the template files
        cfg.setDefaultEncoding("ISO-8859-1");
        // - Set the charset of the output. This is actually just a hint, that templates may require for URL encoding
        // and for generating META element that uses http-equiv="Content-type".
        cfg.setOutputEncoding("UTF-8");
        // - Set the default locale
        cfg.setLocale(Locale.US);
        cfg.setEncoding(Locale.US, "UTF-8");
        // - Set the locale-sensitive number formatting
        cfg.setNumberFormat("0.####");
    }

    public static Template getTemplate(String templateName) throws IOException {
        if (templateName == null) {
            throw new IllegalArgumentException("Param templateName cannot be null!");
        }
        if (cfg == null) {
            init();
        }
        return cfg.getTemplate(templateName);
    }
}
