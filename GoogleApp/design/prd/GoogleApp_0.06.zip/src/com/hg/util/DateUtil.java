package com.hg.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * TODO TimeZone(UTC2GMT)
 */
public class DateUtil {

    private DateUtil() {
    }

    public static Date getCurrentTime() {
        return new Date();
    }

    /** 取得年月日 */
    public static String getDateFormat(java.sql.Date date) {
        if (date == null) {
            throw new IllegalArgumentException("InParam date cannnot be null!");
        }
        SimpleDateFormat sy1 = new SimpleDateFormat("yyyy/MM/dd");
        return sy1.format(new Date(date.getTime()));
    }

    /**
     * 取得日期的字符串表示形式
     *
     * @param date java.util.Date
     * @param format "example:yyyy/MM/dd"
     */
    public static String getDateFormat(Date date, String format) {
        if (date == null || format == null) {
            throw new IllegalArgumentException("InParam error!");
        }
        SimpleDateFormat sy1 = new SimpleDateFormat(format);
        return sy1.format(date);
    }
}
