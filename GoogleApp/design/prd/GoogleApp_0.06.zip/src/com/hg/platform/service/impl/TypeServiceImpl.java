package com.hg.platform.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.hg.components.dao.ArticleDao;
import com.hg.components.dao.TypeDao;
import com.hg.components.dto.TypeInfo;
import com.hg.components.pojo.Article;
import com.hg.components.pojo.Type;
import com.hg.constant.TypeConstant;
import com.hg.platform.service.TypeService;

public class TypeServiceImpl implements TypeService {

    @Autowired
    private TypeDao typeDao;

    @Autowired
    private ArticleDao articleDao;

    @Override
    public boolean updateType(TypeInfo info) {
        Type type = typeDao.findAllById(info.getId());
        List<Article> arts = articleDao.findAllByType(type.getName());
        for (Article a : arts) {
            a.setType(info.getName());
        }
        type.setName(info.getName());
        return true;
    }

    @Override
    public List<TypeInfo> getTypes() {
        return getTypes(true);
    }

    @Override
    public List<TypeInfo> getTypes(boolean containsDefault) {
        List<Type> types = typeDao.findAll();
        List<TypeInfo> vos = new ArrayList<TypeInfo>(types.size());
        for (Type t : types) {
            if (!containsDefault && TypeConstant.DEFAULT.equals(t.getName())) {
                continue;
            }
            TypeInfo vo = new TypeInfo();
            BeanUtils.copyProperties(t, vo);
            vo.setCount(t.getCountArticle());
            vos.add(vo);
        }
        return vos;
    }

    @Override
    public boolean postType(TypeInfo info) {
        Type t = new Type(info.getName());
        return typeDao.insert(t) != null;
    }

    @Override
    public boolean removeType(String typeId) {
        return typeDao.deleteById(typeId) != null;
    }

}
