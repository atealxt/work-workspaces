package com.hg.platform.configeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

public class ServletConfig extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static ServletContext CONTEXT;

    public final void init() throws ServletException {
        CONTEXT = getServletContext();
        new SystemSetup();
    }

    public static ServletContext getRealServletContext() {
        final ServletContext context = CONTEXT;
        return context;
    }
}