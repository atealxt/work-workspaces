package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.appengine.api.users.User;
import com.hg.components.dto.Mail;
import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.util.GaeUtil;
import com.hg.util.MailUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/sendmail.html")
public class A03MailController extends EasyController {

    @RequestMapping
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        makeTemplate("mail.ftl", makeRootMain(req), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootMain(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Send Mail");

        User user = GaeUtil.getCurrentUser();
        if (user != null) {
            root.put("user", user);
            root.put("touser", req.getParameter("to"));
            root.put("logoutUrl", GaeUtil.getLogoutURL(req.getRequestURI()));
        } else {
            root.put("loginUrl", GaeUtil.getLoginURL(req.getRequestURI()));
        }
        return root;
    }

    private boolean validate(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        User user = GaeUtil.getCurrentUser();
        if (user == null) {
            StringBuilder sb = new StringBuilder();
            sb.append("<b>请先登录！</b>");
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");

            resp.getWriter().println(sb.toString());
            return false;
        }

        return true;
    }

    @RequestMapping(params = "sending", method = RequestMethod.POST)
    public void sending(HttpServletRequest req, HttpServletResponse resp/* , @RequestParam("file") MultipartFile file */)
            throws IOException {

        initResponse(resp);
        if (!validate(req, resp)) {
            return;
        }

        User user = GaeUtil.getCurrentUser();
        String from = user.getEmail(); // currently only support gmail :<
        String to = req.getParameter("to");
        String subject = req.getParameter("Subject");
        String text = req.getParameter("content");
        Mail mail = new Mail();
        mail.setFrom(from);
        mail.setTo(to);
        mail.setSubject(subject);
        mail.setText(text);
        mail.setMultiPart(StringUtil.isEmpty(req.getParameter("base")));

        StringBuilder sb = new StringBuilder();
        boolean sendOk = MailUtil.sendMail(mail);
        if (!sendOk) {
            sb.append("<b>Send failed!<br>");
            sb.append("发送失败！</b><br>");
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");
        } else {
            sb.append("<b>Send success!<br>");
            sb.append("发送成功！</b><br>");
            sb.append("<a href=\"");
            sb.append("/guestbook.html");
            sb.append("\">return</a>");
        }

        resp.getWriter().println(sb.toString());
        DaoManager.closeSession();
    }
}

/*
 * // Check that we have a file upload request boolean isMultipart = ServletFileUpload.isMultipartContent(request);
 *
 * Now we are ready to parse the request into its constituent items. Here's how we do it:
 *
 * // Create a new file upload handler ServletFileUpload upload = new ServletFileUpload();
 *
 * // Parse the request FileItemIterator iter = upload.getItemIterator(request); while (iter.hasNext()) { FileItemStream
 * item = iter.next(); String name = item.getFieldName(); InputStream stream = item.openStream(); if
 * (item.isFormField()) { System.out.println("Form field " + name + " with value " + Streams.asString(stream) +
 * " detected."); } else { System.out.println("File field " + name + " with file name " + item.getName() +
 * " detected."); // Process the input stream ... } }
 */
