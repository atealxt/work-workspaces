package com.hg.platform.configeration;

import org.springframework.beans.factory.annotation.Autowired;

import com.hg.components.dao.TypeDao;
import com.hg.components.pojo.Type;
import com.hg.constant.TypeConstant;

/**
 * 交由Spring托管
 */
public class SystemSetup {

    @Autowired
    private TypeDao typeDao;

    public SystemSetup() {
    }

    /**
     * 为系统建立新分类(文件夹)
     */
    protected void createType() {
        long cnt = typeDao.count();
        if (cnt == 0) {
            Type t = new Type(TypeConstant.DEFAULT);
            typeDao.insert(t);
        }
    }
}
