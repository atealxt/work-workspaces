package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.appengine.api.users.User;
import com.hg.components.dto.GreetingDto;
import com.hg.components.pojo.Greeting;
import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.platform.service.GreetingService;
import com.hg.util.GaeUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/guestbook.html")
public class A02GuestbookController extends EasyController {

    private static Log logger = LogFactory.getLog(A02GuestbookController.class);

    @Autowired
    private GreetingService greetingService;

    @RequestMapping
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        makeTemplate("guestbook.ftl", makeRootMain(req), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootMain(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Guestbook");

        User user = GaeUtil.getCurrentUser();
        if (user != null) {
            root.put("user", user);
            root.put("logoutUrl", GaeUtil.getLogoutURL(req.getRequestURI()));
        } else {
            root.put("loginUrl", GaeUtil.getLoginURL(req.getRequestURI()));
        }

        int iPage = 0;
        String page = req.getParameter("page");
        if (!StringUtil.isEmpty(page)) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        GreetingDto dto = greetingService.makeInfo(iPage);
        root.put("greeting", dto);
        // root.put("greetings", greetingService.getGreetings());
        return root;
    }

    @RequestMapping(params = "putmsg")
    public String putmsg(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String content = req.getParameter("content");
        logger.debug("content: " + content);
        int contentSize = StringUtil.getByteSize(StringUtil.delFtmlTag(content));
        if (content == null || contentSize < 5 || contentSize > Greeting.getMaxLen()) {
            StringBuilder sb = new StringBuilder();
            sb.append("<b>Content length must between 5 and ");
            sb.append(Greeting.getMaxLen());
            sb.append("!<br>");
            sb.append("文字长度错误！</b><br>");

            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");

            initResponse(resp);
            resp.getWriter().println(sb.toString());
            return null;
        }

        greetingService.addGreeting(content);

        DaoManager.closeSession();
        return "redirect:/guestbook/";
    }

    @RequestMapping(params = "delmsg")
    public String delmsg(@RequestParam("delmsg") String greetingId) throws IOException {
        logger.debug(greetingId);
        greetingService.removeGreeting(greetingId);
        DaoManager.closeSession();
        return "redirect:/guestbook/";
    }

}
