package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.DaoManager;
import com.hg.core.EasyController;

@Controller
@RequestMapping("/error.html")
public class A00ErrorController extends EasyController {

    @RequestMapping
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        makeTemplate("error.ftl", makeRootMain(req), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootMain(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Page Error");
        if (String.valueOf(HttpServletResponse.SC_NOT_FOUND).equals(req.getParameter("code"))) {
            root.put("information", make404Html());
        } else if (String.valueOf(HttpServletResponse.SC_FORBIDDEN).equals(req.getParameter("code"))) {
            root.put("information", make403Html());
        } else {
            root.put("information", "I'm sorry, an error occurred!");
        }
        return root;
    }

    private String make404Html() {
        // return
        // "<div id=\"birds\"><h2>Whoops looks like we lost one!</h2><h3>404 - Page can not be found.</h3></div>";
        // TODO 增加404特效
        return "HTTP Status 404 - Requested address is not available.";
    }

    private String make403Html() {
        return "HTTP Status 403 - Access to the requested resource has been denied.";
    }
}
