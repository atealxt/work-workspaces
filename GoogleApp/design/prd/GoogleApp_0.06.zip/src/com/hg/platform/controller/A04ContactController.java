package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hg.components.dto.Mail;
import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.util.DateUtil;
import com.hg.util.GaeUtil;
import com.hg.util.MailUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/contact.html")
public class A04ContactController extends EasyController {

    @RequestMapping
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        makeTemplate("contact.ftl", makeRootMain(req), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootMain(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Contact Me");
        root.put("user", GaeUtil.getCurrentUser());
        return root;
    }

    @RequestMapping(params = "sending", method = RequestMethod.POST)
    public void sending(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        initResponse(resp);

        String from = "atealxt@gmail.com";
        String to = "atealxt@gmail.com";
        String subject = new StringBuilder(req.getParameter("yourname")).append(" 于 ")
                .append(DateUtil.getCurrentTime()).append(" 发表留言").toString();
        String text = new StringBuilder(req.getParameter("yourname")).append(" ").append(req.getParameter("youremail"))
                .append("<hr>").append(req.getParameter("content")).toString();
        Mail mail = new Mail();
        mail.setFrom(from);
        mail.setTo(to);
        mail.setSubject(subject);
        mail.setText(text);
        mail.setMultiPart(StringUtil.isEmpty(req.getParameter("base")));

        StringBuilder sb = new StringBuilder();
        boolean sendOk = MailUtil.sendMail(mail);
        if (!sendOk) {
            sb.append("<b>Send failed!<br>");
            sb.append("发送失败！</b><br>");
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");
        } else {
            sb.append("<b>Send success!<br>");
            sb.append("发送成功！</b><br>");
            sb.append("<a href=\"");
            sb.append("/home/");
            sb.append("\">return</a>");
        }

        resp.getWriter().println(sb.toString());
        DaoManager.closeSession();
    }
}
