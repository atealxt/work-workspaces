package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.platform.service.ArticleService;
import com.hg.platform.service.CommentService;
import com.hg.platform.service.TypeService;
import com.hg.util.GaeUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/blog.html")
public class A05BlogController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private TypeService typeService;

    @RequestMapping
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        makeTemplate("blog.ftl", makeRootMain(req), resp);
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootMain(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Blog");
        root.put("user", GaeUtil.getCurrentUser());

        int iPage = 0;
        if (!StringUtil.isEmpty(req.getParameter("page"))) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        int maxP = articleService.getMaxPage(req.getParameter("t"), false);
        if (iPage > maxP) {
            iPage = maxP;
        }
        root.put("currentP", iPage);
        root.put("maxP", maxP);
        root.put("articles", articleService.getList(iPage, false, req.getParameter("t")));
        root.put("latestCmt", commentService.getLatestCmts());
        root.put("types", typeService.getTypes());

        return root;
    }

}
