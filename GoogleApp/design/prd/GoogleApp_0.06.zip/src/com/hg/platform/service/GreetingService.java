package com.hg.platform.service;

import java.util.List;

import com.hg.components.dto.GreetingDto;
import com.hg.components.pojo.Greeting;

public interface GreetingService {

    List<Greeting> getGreetings(int page);

    void addGreeting(String content);

    void removeGreeting(String id);

    GreetingDto makeInfo(int page);
}
