package com.hg.platform.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.appengine.api.users.User;
import com.hg.components.dao.GreetingDao;
import com.hg.components.dto.GreetingDto;
import com.hg.components.pojo.Greeting;
import com.hg.platform.service.GreetingService;
import com.hg.util.GaeUtil;
import com.hg.util.RoleUtil;

public class GreetingServiceImpl implements GreetingService {

    @Autowired
    private GreetingDao greetingDao;

    @Override
    public List<Greeting> getGreetings(int page) {
        return greetingDao.findAll(page * Greeting.getPagingSize(), Greeting.getPagingSize());
    }

    @Override
    public void addGreeting(String content) {
        User user = GaeUtil.getCurrentUser();
        if (user != null) {
            Greeting greeting = new Greeting(user, content);
            greetingDao.insert(greeting);
        }
    }

    @Override
    public void removeGreeting(String id) {
        if (RoleUtil.isMaster()) {
            greetingDao.deleteById(id);
        }
    }

    @Override
    public GreetingDto makeInfo(int page) {
        GreetingDto dto = new GreetingDto();

        int count = (int) greetingDao.count();
        int maxP = count / Greeting.getPagingSize();
        if (count % Greeting.getPagingSize() == 0) {
            maxP--;
        }
        dto.setMaxP(maxP);

        if (page > maxP) {
            page = maxP;
        }
        dto.setGreetings(getGreetings(page));
        dto.setCurrentP(page);

        return dto;
    }
}
