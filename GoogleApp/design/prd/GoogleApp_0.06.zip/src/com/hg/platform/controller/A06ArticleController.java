package com.hg.platform.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.components.dto.Topic;
import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.platform.service.ArticleService;
import com.hg.platform.service.CommentService;
import com.hg.platform.service.TypeService;
import com.hg.util.GaeUtil;
import com.hg.util.RoleUtil;
import com.hg.util.ServletUtil;

@Controller
public class A06ArticleController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private TypeService typeService;

    @RequestMapping("/article.html")
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        if ("updcnt".equals(req.getParameter("m"))) {// 更新已读IP
            articleService.updReadCnt(req.getParameter("id"), ServletUtil.getReqIp(req));
        } else if ("create".equals(req.getParameter("m"))) {// 创建新文章
            create(req, resp);
        } else if ("post".equals(req.getParameter("m"))) {// 提交新文章新文章
            post(req, resp);
        } else if ("edit".equals(req.getParameter("m"))) {// 修改文章
            edit(req, resp);
        } else if ("update".equals(req.getParameter("m"))) {// 提交修改文章
            update(req, resp);
        } else {
            makeTemplate("article.ftl", makeRootMain(req), resp);
        }
        DaoManager.closeSession();
    }

    private Map<String, Object> makeRootMain(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("user", GaeUtil.getCurrentUser());
        root.put("article", articleService.getById(req.getParameter("id")));
        root.put("latestCmt", commentService.getLatestCmts());
        root.put("types", typeService.getTypes());
        return root;
    }

    private void create(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!RoleUtil.isMaster()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        makeTemplate("admin/articleInfo.ftl", makeRootCreate(req), resp);
    }

    private Map<String, Object> makeRootCreate(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Create New Article");
        root.put("m", "post");
        root.put("user", GaeUtil.getCurrentUser());
        root.put("types", typeService.getTypes(false));
        return root;
    }

    private void post(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        // TODO 整个B**系列的Controller要实现拦截(用Interceptor或AOP)
        if (!RoleUtil.isMaster()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        Topic t = new Topic();
        t.setTitle(req.getParameter("title"));
        t.setSummary(req.getParameter("summery"));
        t.setContent(req.getParameter("content"));
        t.setPostBySummary(req.getParameter("chkSummery") != null);
        t.setType(req.getParameter("nCatalog"));
        if (articleService.postArticle(t)) {
            resp.sendRedirect("articlelist.html");
        } else {
            StringBuilder sb = new StringBuilder("<b>发布失败</b>");
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">返回</a>");

            initResponse(resp);
            resp.getWriter().println(sb.toString());
        }
        return;
    }

    private void edit(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!RoleUtil.isMaster()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        makeTemplate("admin/articleInfo.ftl", makeRootEdit(req), resp);
    }

    private Map<String, Object> makeRootEdit(HttpServletRequest req) {
        // Build the data-model
        Map<String, Object> root = new HashMap<String, Object>();
        root.put("title", "Edit Article");
        root.put("m", "update");
        root.put("topic", articleService.getById(req.getParameter("id")));
        root.put("types", typeService.getTypes(false));

        return root;
    }

    private void update(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        if (!RoleUtil.isMaster()) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        Topic t = new Topic();
        t.setId(req.getParameter("id"));
        t.setTitle(req.getParameter("title"));
        t.setSummary(req.getParameter("summery"));
        t.setContent(req.getParameter("content"));
        t.setPostBySummary(req.getParameter("chkSummery") != null);
        t.setType(req.getParameter("nCatalog"));
        if (articleService.updateArticle(t)) {
            resp.sendRedirect("articlelist.html");
        } else {
            StringBuilder sb = new StringBuilder("<b>发布失败</b>");
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">返回</a>");

            initResponse(resp);
            resp.getWriter().println(sb.toString());
        }
        return;
    }
}