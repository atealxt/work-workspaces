package com.hg.platform.service;

import java.util.List;

import com.hg.components.dto.CommentInfo;

public interface CommentService {

    List<CommentInfo> getLatestCmts();

    int getMaxPage();

    List<CommentInfo> getList(int pageNo);

    void remove(String id);
}
