package com.hg.platform.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.components.dto.CommentInfo;
import com.hg.components.pojo.Article;
import com.hg.components.pojo.Comment;
import com.hg.core.DaoManager;
import com.hg.core.EasyController;
import com.hg.platform.service.ArticleService;
import com.hg.util.DateUtil;
import com.hg.util.GaeUtil;
import com.hg.util.ServletUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/comment.html")
public class A08CommentController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @RequestMapping
    public void main(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        if ("get".equals(req.getParameter("m"))) {
            writeCommentInfo(req.getParameter("id"), resp);
        } else if ("add".equals(req.getParameter("m"))) {
            addComment(req);

            StringBuffer sb = new StringBuffer("article/");
            sb.append(req.getParameter("aid"));
            sb.append(".html#comment");
            resp.sendRedirect(sb.toString());
        }
        DaoManager.closeSession();
    }

    private void writeCommentInfo(String articleId, HttpServletResponse resp) throws IOException {
        Article art = articleService.getArticleById(articleId);
        List<Comment> comments = art.getComments();
        StringBuilder sb = new StringBuilder("<h3 class=\"title\">");
        if (comments.size() == 0) {
            sb.append("No Comment.</h3>");
        } else {
            sb.append("Comments:</h3>");
            for (int i = 0; i < comments.size(); i++) {
                Comment cmt = comments.get(i);
                sb.append("<div class=\"reply\"><p class=\"byline\">");
                sb.append(i + 1);
                sb.append("<a name=\"#");
                sb.append(cmt.getId());
                sb.append("\"></a># ");
                sb.append(StringUtil.escape(cmt.getTitle()));
                sb.append(" ");
                sb.append(DateUtil.getDateFormat(cmt.getCreateTime(), "yyyy-MM-dd HH:mm"));
                sb.append(" | ");
                if (!StringUtil.isEmpty(cmt.getFounder().getContact(), true)) {
                    sb.append("<a target=\"_blank\" href=\"");
                    sb.append(StringUtil.escape(GaeUtil.getContactUrl(cmt.getFounder().getContact())));
                    sb.append("\">");
                    sb.append(StringUtil.escape(cmt.getFounder().getName()));
                    sb.append("</a>");
                } else {
                    sb.append(StringUtil.escape(cmt.getFounder().getName()));
                }
                sb.append("</p><p class=\"byline\">");
                sb.append(StringUtil.escape(cmt.getContent()));
                sb.append(" <a onclick=\"setReplyTitle('");
                sb.append(StringUtil.escape(cmt.getFounder().getName()));
                sb.append("')\">Reply</a></p> </div>");
            }
        }

        initResponse(resp);
        resp.getWriter().println(sb.toString());
    }

    private void addComment(HttpServletRequest req) {
        CommentInfo info = new CommentInfo();
        info.setArticleId(req.getParameter("aid"));
        info.setTitle(req.getParameter("title"));
        info.setName(req.getParameter("yourname"));
        info.setContact(req.getParameter("contact"));
        info.setContent(req.getParameter("rep_content"));
        info.setIp(ServletUtil.getReqIp(req));
        articleService.updateComment(info);
    }
}
