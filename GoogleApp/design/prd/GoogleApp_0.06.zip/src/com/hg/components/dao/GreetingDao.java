package com.hg.components.dao;

import java.util.List;

import com.hg.components.pojo.Greeting;

public interface GreetingDao {

    List<Greeting> findAll(int start, int length);

    Greeting insert(Greeting g);

    Greeting deleteById(String id);

    long count();
}
