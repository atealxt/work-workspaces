package com.hg.components.dao;

import java.util.List;

import com.hg.components.pojo.Type;

public interface TypeDao {

    Type insert(Type t);

    Type findAllById(String id);

    Type findAllByName(String name);

    List<Type> findAll();

    Type deleteById(String id);

    long count();
}
