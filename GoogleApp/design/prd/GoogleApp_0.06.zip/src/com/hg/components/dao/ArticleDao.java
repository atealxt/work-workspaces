package com.hg.components.dao;

import java.util.List;

import com.hg.components.pojo.Article;

public interface ArticleDao {

    Article insert(Article g);

    List<Article> findAll(int start, int length);

    List<Article> findAll(int start, int length, String typeName);

    Article findAllById(String id);

    List<Article> findAllByType(String typeName);

    List<Article> findLatast(int size);

    long count();

    long count(String typeName);

    Article deleteById(String id);

}
