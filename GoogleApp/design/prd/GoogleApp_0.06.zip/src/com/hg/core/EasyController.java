package com.hg.core;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hg.util.FreeMarkerUtil;

import freemarker.template.Template;

public abstract class EasyController {

    private static Log logger = LogFactory.getLog(EasyController.class);

    protected void initResponse(HttpServletResponse resp) {
        resp.setContentType("text/html; charset=UTF-8");
        // TODO no cache?
        resp.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
        resp.setHeader("Pragma", "no-cache");
    }

    protected void makeTemplate(String templateName, Map<String, Object> root, HttpServletResponse resp)
            throws IOException {

        // Get the templat object
        Template t = FreeMarkerUtil.getTemplate(templateName);

        initResponse(resp);
        // Merge the data-model and the template
        try {
            t.process(root, resp.getWriter());
        } catch (Exception e) {
            logger.error(e);
        }
    }

}
