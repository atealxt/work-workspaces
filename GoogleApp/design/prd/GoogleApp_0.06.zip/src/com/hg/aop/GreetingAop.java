package com.hg.aop;

import java.util.ArrayList;
import java.util.List;

import org.aspectj.lang.ProceedingJoinPoint;

import com.hg.components.dto.Mail;
import com.hg.components.pojo.Greeting;
import com.hg.constant.CacheConstant;
import com.hg.util.CacheUtil;
import com.hg.util.GaeUtil;
import com.hg.util.MailUtil;

public class GreetingAop {

    // public void setCache(Greeting g) {
    // System.out.println(g);
    // }

    public Object doBasicProfiling(ProceedingJoinPoint pjp) throws Throwable {

        // start stopwatch
        Object retVal = pjp.proceed();
        // stop stopwatch

        String methodName = pjp.getSignature().getName();
        // String className = pjp.getSignature().getDeclaringTypeName();
        // System.out.println(methodName);
        // System.out.println(className);
        if (methodName.startsWith("insert")) {
            Greeting g = Greeting.class.cast(retVal);
            addCache(g);

            // if (true) {
            // sendMail(g);
            // }
        } else if (methodName.startsWith("delete")) {
            removeCache(Greeting.class.cast(retVal));
        }

        return retVal;
    }

    private void addCache(Greeting g) {
        if (g != null) {
            List<Greeting> greetings = CacheUtil.get(CacheConstant.GREETING_ALL);
            if (greetings != null) {
                greetings.add(g);
            } else {
                greetings = new ArrayList<Greeting>();
                greetings.add(g);
            }
            CacheUtil.put(CacheConstant.GREETING_ALL, greetings);
        }
    }

    private void removeCache(Greeting g) {
        if (g != null) {
            List<Greeting> greetings = CacheUtil.get(CacheConstant.GREETING_ALL);
            if (greetings != null) {
                for (Greeting gTemp : greetings) {
                    if (gTemp.getId().equals(g.getId())) {
                        greetings.remove(gTemp);
                        break;
                    }
                }
                CacheUtil.put(CacheConstant.GREETING_ALL, greetings);
            }
        }
    }

    @SuppressWarnings("unused")
    private void sendMail(Greeting g) {
        String from = "atealxt@gmail.com";
        String to = "atealxt@gmail.com";
        String subject = new StringBuilder(GaeUtil.getCurrentUser().getNickname()).append("于 ").append(g.getDate())
                .append(" 发表留言").toString();
        String text = new StringBuilder("From: ").append(g.getAuthor().getEmail()).append("<hr>")
                .append(g.getContent()).toString();
        Mail mail = new Mail();
        mail.setFrom(from);
        mail.setTo(to);
        mail.setSubject(subject);
        mail.setText(text);
        mail.setMultiPart(true);
        MailUtil.sendMail(mail);
    }

}
