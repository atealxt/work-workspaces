/*
 * Copyright 2009 atealxt@gmail.com All rights reserved.
 */
window.CommonApi = Class.create();

CommonApi.prototype = {

    initialize : function() {},
    addOnEventListener : function(type, fnc) {
        try {
            if (window.attachEvent) {
                window.attachEvent("on" + type, fnc);
            } else {
                window.addEventListener(type, fnc, false);
            }
        } catch (e) {
            alert(e);
        }
        return;
    },
    removeOnEventListener : function(type, fnc) {
        try {
            if (window.detatchEvent) {
                window.detatchEvent("on" + type, fnc);
            } else {
                window.removeEventListener(type, fnc, false);
            }
        } catch (e) {
            alert(e);
        }
        return;
    },
    SearchGoogle : function(key, evt, site) {
        if (evt.keyCode == 13 || evt.keyCode == 0 || evt.type == 'click') {
            key.focus();
            var keystr = encodeURIComponent(key.value);
            url = "http://www.google.com/search?q=";
            url = url + keystr;
            url += "&ie=UTF-8&domains=" + site + "&sitesearch=" + site;
            window.location = url;
            return false;
        }
    },
    $N : function(pName) {
        return document.getElementsByName(pName);
    },
    addPagingParam : function(oriUrl, currentPage) {
        if (currentPage == undefined) {
            currentPage = 0;
        }
        var newUrl = oriUrl.replace(/([\?\&]page=?)(\d+)/g, "$1" + currentPage);
        newUrl = newUrl.replace(/([\?]{1})$/g, "?page=" + currentPage);
        if (!newUrl.match(/[\?\&]/g)) {
            newUrl = newUrl + "?page=" + currentPage;
        } else if (!newUrl.match(/[\?\&]{1}page=\d+/g)) {
            newUrl = newUrl + "&page=" + currentPage;
        }
        return newUrl;
    },
    hiddenWhenLoading : function(objId, time) {
        $(objId).style.visibility = "hidden";
        var timer = window.setTimeout( function() {
            $(objId).style.visibility = "";
            clearTimeout(timer);
        }, time);
    }
};

( function() {
    window.cmnApi = new CommonApi();
})();