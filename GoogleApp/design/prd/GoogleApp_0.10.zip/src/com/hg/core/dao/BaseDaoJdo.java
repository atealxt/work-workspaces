package com.hg.core.dao;

import java.io.Serializable;
import java.util.List;

import javax.jdo.PersistenceManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.appengine.api.datastore.DatastoreServiceFactory;

/**
 * JDO BaseDao class
 */
public abstract class BaseDaoJdo implements IBaseDaoOrm {

    private static Log logger = LogFactory.getLog(BaseDaoJdo.class);

    @Override
    public <T> T findById(Class<T> clazz, Serializable id) {
        PersistenceManager manager = JdoManager.getSession();
        try {
            return clazz.cast(manager.getObjectById(clazz, id));
        } catch (RuntimeException e) {
            logger.error(e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public <T> T getById(Class<T> clazz, Serializable id) {
        flush();
        return findById(clazz, id);
    }

    @Override
    public <T> List<T> findByQuery(String query) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> List<T> findByQuery(String query, Object... values) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> List<T> findByQuery(String query, Pager pager, Object... values) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> List<T> findByQuery(String query, Pager pager) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long count(Class<? extends Object> clazz) {
        com.google.appengine.api.datastore.Query query = new com.google.appengine.api.datastore.Query(clazz
                .getSimpleName());
        return DatastoreServiceFactory.getDatastoreService().prepare(query).countEntities();
    }

    @Override
    public <T> T save(T t) {
        PersistenceManager manager = JdoManager.getSession();
        try {
            return manager.makePersistent(t);
        } catch (RuntimeException e) {
            logger.error(e);
            throw new RuntimeException(e);
        } finally {
            manager.close();
        }
    }

    @Override
    public <T> T delete(T obj) {
        PersistenceManager manager = JdoManager.getSession();
        try {
            manager.deletePersistent(obj);
            return obj;
        } catch (RuntimeException e) {
            logger.error(e);
            throw new RuntimeException(e);
        } finally {
            manager.close();
        }
    }

    @Override
    public <T> T merge(T detachedInstance, Class<T> clazz) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void flush() {
        PersistenceManager manager = JdoManager.getSession();
        try {
            manager.flush();
        } catch (RuntimeException e) {
            logger.error(e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void initialize(Object obj) {
        throw new UnsupportedOperationException();
    }

}
