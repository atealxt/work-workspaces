package com.hg.constant;

/**
 * 缓存Key常量类
 */
public class CacheConstant {

    public final static String GREETING_ALL = "GREETING_ALL";

    // public static String LATEST_COMMENT = "LATEST_COMMENT";
}
