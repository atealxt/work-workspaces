package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.EasyController;
import com.hg.service.ArticleService;
import com.hg.service.CommentService;
import com.hg.service.TypeService;
import com.hg.util.GaeUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/blog.html")
public class A05BlogController extends EasyController {

    @Autowired
    private ArticleService articleService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private TypeService typeService;

    @RequestMapping
    public String main(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootMain(req, model);
        return "blog";
    }

    private void makeRootMain(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Blog");
        model.addAttribute("user", GaeUtil.getCurrentUser());

        int iPage = 0;
        if (!StringUtil.isEmpty(req.getParameter("page"))) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        int maxP = articleService.getMaxPage(req.getParameter("t"), false);
        if (iPage > maxP) {
            iPage = maxP;
        }
        model.addAttribute("currentP", iPage);
        model.addAttribute("maxP", maxP);
        model.addAttribute("articles", articleService.getList(iPage, false, req.getParameter("t")));
        model.addAttribute("latestCmt", commentService.getLatestCmts());
        model.addAttribute("types", typeService.getTypes());
    }

}
