package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.appengine.api.users.User;
import com.hg.core.EasyController;
import com.hg.dto.GreetingDto;
import com.hg.pojo.Greeting;
import com.hg.service.GreetingService;
import com.hg.util.GaeUtil;
import com.hg.util.RoleUtil;
import com.hg.util.ServletUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/guestbook.html")
public class A02GuestbookController extends EasyController {

    @Autowired
    private GreetingService greetingService;

    @RequestMapping
    public String main(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootMain(req, model);
        return "guestbook";
    }

    private void makeRootMain(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Guestbook");

        User user = GaeUtil.getCurrentUser();
        if (user != null) {
            model.addAttribute("user", user);
            model.addAttribute("logoutUrl", GaeUtil.getLogoutURL(req.getRequestURI()));
        } else {
            model.addAttribute("loginUrl", GaeUtil.getLoginURL(req.getRequestURI()));
            model.addAttribute("captcha", ServletUtil.makeCaptcha(req.getSession()));

            String guestName = ServletUtil.getCookie(req, ServletUtil.GUEST_NAME);
            if (!StringUtil.isEmpty(guestName)) {
                model.addAttribute("guestName", guestName);
            }
        }
        model.addAttribute("master", RoleUtil.isMaster());

        int iPage = 0;
        String page = req.getParameter("page");
        if (!StringUtil.isEmpty(page)) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        GreetingDto dto = greetingService.makeInfo(iPage);
        model.addAttribute("greeting", dto);
    }

    @RequestMapping(params = "putmsg")
    public String putmsg(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        initResponse(resp);

        // 非登录用户需要输入认证码
        if (GaeUtil.getCurrentUser() == null) {
            String captcha = req.getParameter("captcha");
            if (StringUtil.isEmpty(captcha)// 
                    || !StringUtil.isNum(captcha)// 
                    || !ServletUtil.checkCaptcha(Integer.parseInt(captcha), req.getSession())) {
                StringBuilder sb = new StringBuilder();
                sb.append("<b>Input captcha error!<br>验证码输入错误！</b><br>");
                sb.append("<a href=\"");
                sb.append(req.getRequestURI());
                sb.append("\">back</a>");
                resp.getWriter().println(sb.toString());
                return null;
            }
        }

        String guestName = req.getParameter("guest");
        if (!StringUtil.isEmpty(guestName)) {
            ServletUtil.setCookie(req, resp, ServletUtil.GUEST_NAME, guestName);
        }

        String content = req.getParameter("content");
        int contentSize = StringUtil.getByteSize(StringUtil.delHtmlTag(content));
        if (content == null || contentSize < 5 || contentSize > Greeting.getMaxLen()) {
            StringBuilder sb = new StringBuilder();
            sb.append("<b>Content length must between 5 and ");
            sb.append(Greeting.getMaxLen());
            sb.append("!<br>");
            sb.append("文字长度错误！</b><br>");

            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");

            resp.getWriter().println(sb.toString());
            return null;
        }

        greetingService.addGreeting(content, guestName);
        return "redirect:/guestbook/";
    }

    @RequestMapping(params = "delmsg")
    public String delmsg(@RequestParam("delmsg") String greetingId) throws IOException {
        greetingService.removeGreeting(greetingId);
        return "redirect:/guestbook/";
    }

}
