package com.hg.web.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.EasyController;
import com.hg.dto.PageLink;

@Controller
@RequestMapping("/menu.html")
public class B02MenuController extends EasyController {

    @RequestMapping
    public String main(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootMain(req, model);
        return "admin/menu";
    }

    private void makeRootMain(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "menu");
        model.addAttribute("links", makeLink());
    }

    private List<PageLink> makeLink() {
        List<PageLink> links = new ArrayList<PageLink>();

        PageLink link = null;

        link = new PageLink();
        link.setLink("/articlelist.html?m=create");
        link.setMsgShow("写新文章");
        links.add(link);

        link = new PageLink();
        link.setLink("/articlelist.html");
        link.setMsgShow("文章");
        links.add(link);

        link = new PageLink();
        link.setLink("/commentlist.html");
        link.setMsgShow("评论");
        links.add(link);

        link = new PageLink();
        link.setLink("/guestbooklist.html");
        link.setMsgShow("留言");
        links.add(link);

        link = new PageLink();
        link.setLink("#");
        link.setMsgShow("相册");
        links.add(link);

        link = new PageLink();
        link.setLink("/typelist.html");
        link.setMsgShow("文章分类");
        links.add(link);

        link = new PageLink();
        link.setLink("#");
        link.setMsgShow("友情链接");
        links.add(link);

        return links;
    }
}
