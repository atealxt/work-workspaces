package com.hg.dao.jdo;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hg.constant.TypeConstant;
import com.hg.core.dao.BaseDaoJdo;
import com.hg.core.dao.JdoManager;
import com.hg.dao.ArticleDao;
import com.hg.dao.TypeDao;
import com.hg.pojo.Article;
import com.hg.pojo.Type;

public class TypeDaoJdo extends BaseDaoJdo implements TypeDao {

    private static Log logger = LogFactory.getLog(TypeDaoJdo.class);

    @Autowired
    private ArticleDao articleDao;

    @Override
    public Type insert(Type t) {
        Type tTemp = findByName(t.getName());
        if (tTemp != null) {
            return null;
        }
        return save(t);
    }

    @Override
    public Type findById(String id) {
        return findById(Type.class, id);
    }

    @Override
    public Type findByName(String name) {
        Query query = JdoManager.getSession().newQuery(Type.class, "name == nameParam");
        query.declareParameters("String nameParam");
        query.setUnique(true);
        return Type.class.cast(query.execute(name));
    }

    @Override
    public long count() {
        return count(Type.class);
    }

    /**
     * 如果旗下还有文章，因为有级联删除机制，所以不能直接删除.<br>
     */
    @Override
    public Type deleteById(String id) {

        Type t = findById(id);
        if (TypeConstant.DEFAULT.equals(t.getName())) {
            logger.warn("Default type folder cannnot be removed");
            return null;
        }

        Type typeDefault = findByName(TypeConstant.DEFAULT);
        List<Article> acts = articleDao.findAllByType(t.getName());
        for (Article a : acts) {
            // 把那些文章放到指定默认分类去
            a.setType(TypeConstant.DEFAULT);
            typeDefault.setCountArticle(typeDefault.getCountArticle() + 1);
        }

        return delete(findById(Type.class, id));
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Type> findAll() {
        List<Type> types = null;
        PersistenceManager manager = JdoManager.getSession();
        try {
            Query query = manager.newQuery(Type.class);
            query.setOrdering("name asc");// TODO 目前区分大小写（今后改为不区分）
            types = (List<Type>) query.execute();
        } catch (Exception e) {
            logger.error(e);
        }
        return types;
    }

}
