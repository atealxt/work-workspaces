package com.hg.dao;

import java.util.Date;
import java.util.List;

import com.hg.core.dao.IBaseDaoOrm;
import com.hg.pojo.Article;

public interface ArticleDao extends IBaseDaoOrm{

    Article insert(Article g);

    List<Article> findAll(int start, int length);

    List<Article> findAll(int start, int length, String typeName);

    Article findAllById(String id);

    Article findAllByAlias(String alias, Date createTime);

    List<Article> findAllByType(String typeName);

    List<Article> findLatast(int size);

    long count();

    long count(String typeName);

    Article deleteById(String id);

}
