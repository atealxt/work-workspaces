package com.hg.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.hg.constant.PagingConstant;
import com.hg.dao.CommentDao;
import com.hg.dto.CommentInfo;
import com.hg.pojo.Comment;
import com.hg.service.CommentService;
import com.hg.util.DateUtil;
import com.hg.util.StringUtil;

public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentDao commentDao;

    @Override
    public List<CommentInfo> getLatestCmts() {
        List<Comment> comments = commentDao.findLatast(PagingConstant.LATEST_COMMENT);
        List<CommentInfo> vos = new ArrayList<CommentInfo>(comments.size());
        for (Comment cmt : comments) {
            CommentInfo vo = new CommentInfo();
            BeanUtils.copyProperties(cmt, vo);
            vo.setName(cmt.getFounder().getName());
            vo.setArticleId(cmt.getArticle().getId());
            vo.setAlias(cmt.getArticle().getAlias());
            vo.setCreateTime(cmt.getArticle().getCreateTime());
            vos.add(vo);
        }
        return vos;
    }

    @Override
    public int getMaxPage() {
        int count = (int) commentDao.count();
        int maxP = count / PagingConstant.COMMENT_MANAGE;
        if (count % PagingConstant.COMMENT_MANAGE == 0) {
            maxP--;
        }
        return maxP;
    }

    @Override
    public List<CommentInfo> getList(int pageNo) {
        List<Comment> cmts = commentDao.findAll(pageNo * PagingConstant.COMMENT_MANAGE, PagingConstant.COMMENT_MANAGE);
        List<CommentInfo> vos = new ArrayList<CommentInfo>();
        for (Comment c : cmts) {
            CommentInfo vo = new CommentInfo();
            BeanUtils.copyProperties(c, vo);
            vo.setContent(StringUtil.escape(c.getContent()));
            vo.setArticleId(c.getArticle().getId());
            vo.setIp(c.getFounder().getIp());
            vo.setName(c.getFounder().getName());
            vo.setContact(StringUtil.getContactUrl(c.getFounder().getContact()));
            vo.setTime(DateUtil.getDateFormat(c.getCreateTime(), "yyyy-MM-dd HH:mm:ss"));
            vos.add(vo);
        }
        return vos;
    }

    @Override
    public void remove(String id) {
        commentDao.deleteById(id);
    }

}
