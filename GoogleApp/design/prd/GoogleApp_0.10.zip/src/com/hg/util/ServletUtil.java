package com.hg.util;

import java.util.Random;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletUtil {

    /** 验证码数字的最大数 */
    private static int MAX_VALUE = 10;
    /** 验证码数字的最大数 */
    public static String CAPTCHA = "CAPTCHA";
    /** 访客名 */
    public static String GUEST_NAME = "GUEST_NAME";
    /** 访客联系地址 */
    public static String GUEST_URL = "GUEST_URL";

    private ServletUtil() {
    }

    public static String getReqIp(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    /** 在session中生成验证码，并返回运算式的表示形式 */
    public static String makeCaptcha(HttpSession sess) {

        Random ran = new Random(System.currentTimeMillis());
        int firstNumber = ran.nextInt(MAX_VALUE + 1);
        int secondNumber = ran.nextInt(MAX_VALUE + 1);
        String operator = null;
        int result = -1;
        if (ran.nextInt() % 2 == 0) {
            operator = "+";
            result = firstNumber + secondNumber;
        } else {
            operator = "-";
            result = firstNumber - secondNumber;
        }
        sess.setAttribute(CAPTCHA, result);

        return new StringBuilder().append(firstNumber).append(" ").append(operator)//
                .append(" ").append(secondNumber).append(" ").append("= ").toString();
    }

    /** 核实验证码 */
    public static boolean checkCaptcha(int input, HttpSession sess) {
        return ((Integer) sess.getAttribute(CAPTCHA)).intValue() == input;
    }

    public static String getCookie(HttpServletRequest req, String ckName) {
        Cookie[] cookies = req.getCookies();
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals(ckName)) {
                return cookie.getValue();
            }
        }
        return null;
    }

    public static void setCookie(HttpServletRequest req, HttpServletResponse resp, String key, String value) {
        delCookieIfExist(req, key);
        Cookie c = new Cookie(key, value);
        c.setMaxAge(3600);
        resp.addCookie(c);
    }

    private static void delCookieIfExist(HttpServletRequest req, String ckName) {
        Cookie[] cookies = req.getCookies();
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals(ckName)) {
                cookie.setMaxAge(0);
                return;
            }
        }
    }
}
