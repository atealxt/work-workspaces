package com.hg.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * TODO TimeZone(UTC2GMT)
 */
public class DateUtil {

    private DateUtil() {
    }

    public static Date getCurrentTime() {
        return new Date();
    }

    /** 取得年月日 */
    public static String getDateFormat(java.sql.Date date) {
        if (date == null) {
            throw new IllegalArgumentException("InParam date cannnot be null!");
        }
        SimpleDateFormat sy1 = new SimpleDateFormat("yyyy/MM/dd");
        return sy1.format(new Date(date.getTime()));
    }

    /**
     * 取得日期的字符串表示形式
     *
     * @param date java.util.Date
     * @param format "example:yyyy/MM/dd"
     */
    public static String getDateFormat(Date date, String format) {
        if (date == null || format == null) {
            throw new IllegalArgumentException("InParam error!");
        }
        SimpleDateFormat sy1 = new SimpleDateFormat(format);
        return sy1.format(date);
    }

    /**
     * 取得日期的日期表示形式
     *
     * @param date 日期的字符串表示形式
     * @param format "example:yyyy/MM/dd"
     * @throws ParseException
     */
    public static Date getDateFormat(String date, String format) throws ParseException {
        if (date == null || format == null) {
            throw new IllegalArgumentException("InParam error!");
        }
        SimpleDateFormat sy1 = new SimpleDateFormat(format);
        return sy1.parse(date);
    }

    public static Date getTomorrow(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }

    public static Date getToday(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        return cal.getTime();
    }
}
