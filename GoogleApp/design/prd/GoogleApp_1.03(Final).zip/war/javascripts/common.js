window.CommonApi = Class.create();

CommonApi.prototype = {

	initialize : function() {
	},
	addOnEventListener : function(type, fnc) {
		try {
			if (window.attachEvent) {
				window.attachEvent("on" + type, fnc);
			} else {
				window.addEventListener(type, fnc, false);
			}
		} catch (e) {
			alert(e);
		}
		return;
	},
	removeOnEventListener : function(type, fnc) {
		try {
			if (window.detatchEvent) {
				window.detatchEvent("on" + type, fnc);
			} else {
				window.removeEventListener(type, fnc, false);
			}
		} catch (e) {
			alert(e);
		}
		return;
	},
	SearchGoogle : function(key, evt, site) {
		if (evt.keyCode == 13 || evt.keyCode == 0 || evt.type == 'click') {
			key.focus();
			var keystr = encodeURIComponent(key.value);
			url = "http://www.google.com/search?q=";
			url = url + keystr;
			url += "&ie=UTF-8&domains=" + site + "&sitesearch=" + site;
			window.location = url;
			return false;
		}
	},
	$N : function(pName) {
		return document.getElementsByName(pName);
	},
	$T : function(tName) {
		return document.getElementsByTagName(tName);
	},
	addPagingParam : function(oriUrl, currentPage) {
		if (currentPage == undefined) {
			currentPage = 0;
		}
		var newUrl = oriUrl.replace(/([\?\&]page=?)(\d+)/g, "$1" + currentPage);// change currentPage if has exist
		newUrl = newUrl.replace(/([\?]{1})$/g, "?page=" + currentPage);// add currentPage if end with '?'
		if (!newUrl.match(/[\?\&]/g)) {
			// no param yet
			newUrl = newUrl + "?page=" + currentPage;
		} else if (!newUrl.match(/[\?\&]{1}page=\d+/g)) {
			// has param but not contains 'page'
			newUrl = newUrl + "&page=" + currentPage;
		}
		//return newUrl;
		return newUrl.replace(/#/,"");
	},
	hiddenWhenLoading : function(objId, time) {
		$(objId).style.visibility = "hidden";
		var timer = window.setTimeout(function() {
			$(objId).style.visibility = "";
			clearTimeout(timer);
		}, time);
	},
	disableWhenSubmiting : function(obj) {
		obj.disabled = true;
		obj.value = "Waiting..";
	},
	delHtmlTag : function(str, containsEnter) {
		if(!containsEnter){
		    return str.replace(/<[^>]*>/g, "");
		}
		return str.replace(/<[^>]*>/g, "").replace(/\n/g, "");
	}
};

(function() {
	window.cmnApi = new CommonApi();
})();
