function beforeSubmit() {

	tinyMCE.triggerSave();
	var len = cmnApi.delHtmlTag($F("content")).length;
	if(len < 5 || len > 5000){
		alert("Content length must between 5 and 5000!\n文字长度错误!");
		return false;
	}

	cmnApi.disableWhenSubmiting($("submit"));
	return true;
}