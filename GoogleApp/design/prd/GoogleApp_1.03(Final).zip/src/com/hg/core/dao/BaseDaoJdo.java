package com.hg.core.dao;

import java.io.Serializable;
import java.util.List;

import javax.jdo.PersistenceManager;

import com.google.appengine.api.datastore.DatastoreServiceFactory;

/**
 * JDO BaseDao class
 */
public abstract class BaseDaoJdo implements IBaseDaoOrm {

    @Override
    public <T> T findById(Class<T> clazz, Serializable id) {
        PersistenceManager manager = JdoManager.getSession();
        return clazz.cast(manager.getObjectById(clazz, id));
    }

    @Override
    public <T> T getById(Class<T> clazz, Serializable id) {
        flush();
        return findById(clazz, id);
    }

    @Override
    public <T> List<T> findByQuery(String query) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> List<T> findByQuery(String query, Object... values) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> List<T> findByQuery(String query, Pager pager, Object... values) {
        throw new UnsupportedOperationException();
    }

    @Override
    public <T> List<T> findByQuery(String query, Pager pager) {
        throw new UnsupportedOperationException();
    }

    @Override
    public long count(Class<? extends Object> clazz) {

        // DatastoreService datastore = DatastoreServiceFactory.getDatastoreService();
        // com.google.appengine.api.datastore.Query query = new
        // com.google.appengine.api.datastore.Query("__Stat_Kind__");
        // query.addFilter("kind_name", FilterOperator.EQUAL, clazz.getSimpleName());
        // Entity globalStat = datastore.prepare(query).asSingleEntity();
        // Long totalEntities = (Long) globalStat.getProperty("count");
        // System.out.println(totalEntities);
        // return totalEntities != null ? totalEntities : 0;

        com.google.appengine.api.datastore.Query query = new com.google.appengine.api.datastore.Query(clazz
                .getSimpleName());
        return DatastoreServiceFactory.getDatastoreService().prepare(query).countEntities();
    }

    @Override
    public <T> T save(T t) {
        PersistenceManager manager = JdoManager.getSession();
        try {
            return manager.makePersistent(t);
        } finally {
            manager.close();
        }
    }

    @Override
    public <T> T delete(T obj) {
        PersistenceManager manager = JdoManager.getSession();
        try {
            manager.deletePersistent(obj);
            return obj;
        } finally {
            manager.close();
        }
    }

    @Override
    public <T> T merge(T detachedInstance, Class<T> clazz) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void flush() {
        PersistenceManager manager = JdoManager.getSession();
        manager.flush();
    }

    @Override
    public void initialize(Object obj) {
        throw new UnsupportedOperationException();
    }

}
