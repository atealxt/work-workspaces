package com.hg.constant;

public final class TypeConstant {

    private TypeConstant() {}

    public static String DEFAULT = "Unclassified";// support changing
}
