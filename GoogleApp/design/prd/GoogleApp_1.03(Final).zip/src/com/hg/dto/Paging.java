package com.hg.dto;

public class Paging {

    protected int currentP;
    protected int maxP;

    public int getCurrentP() {
        return currentP;
    }

    public void setCurrentP(int currentP) {
        this.currentP = currentP;
    }

    public int getMaxP() {
        return maxP;
    }

    public void setMaxP(int maxP) {
        this.maxP = maxP;
    }

    @Override
    public String toString() {
        return "Paging [currentP=" + currentP + ", maxP=" + maxP + "]";
    }
}
