package com.hg.dao;

import java.util.List;

import com.hg.core.dao.IBaseDaoOrm;
import com.hg.pojo.Greeting;

public interface GreetingDao extends IBaseDaoOrm{

    List<Greeting> findAll(int start, int length);

    Greeting insert(Greeting g);

    Greeting deleteById(String id);

    long count();
}
