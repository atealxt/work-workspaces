package com.hg.dao;

import java.util.List;

import com.hg.core.dao.IBaseDaoOrm;
import com.hg.pojo.Type;

public interface TypeDao extends IBaseDaoOrm{

    Type insert(Type t);

    Type findById(String id);

    Type findByName(String name);

    List<Type> findAll();

    Type deleteById(String id);

    long count();
}
