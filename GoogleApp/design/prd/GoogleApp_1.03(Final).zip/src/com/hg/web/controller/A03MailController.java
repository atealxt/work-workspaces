package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.appengine.api.users.User;
import com.hg.core.EasyController;
import com.hg.dto.Mail;
import com.hg.util.GaeUtil;
import com.hg.util.MailUtil;
import com.hg.util.StringUtil;

@Controller
@RequestMapping("/sendmail.html")
public class A03MailController extends EasyController {

    @RequestMapping
    public String main(final HttpServletRequest req, final HttpServletResponse resp, final ModelMap model) throws IOException {
        makeCommonInfo(req, model);
        makeRootMain(req, model);
        return "mail";
    }

    private void makeRootMain(final HttpServletRequest req, final ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Send Mail");

        User user = GaeUtil.getCurrentUser();
        if (user != null) {
            model.addAttribute("user", user);
            model.addAttribute("touser", req.getParameter("to"));
            model.addAttribute("logoutUrl", GaeUtil.getLogoutURL(req.getRequestURI()));
        } else {
            model.addAttribute("loginUrl", GaeUtil.getLoginURL(req.getRequestURI()));
        }
    }

    private boolean validate(final HttpServletRequest req, final HttpServletResponse resp) throws IOException {

        User user = GaeUtil.getCurrentUser();
        if (user == null) {
            StringBuilder sb = new StringBuilder(getMessage("pleaseLogin"));
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");
            resp.getWriter().println(sb.toString());
            return false;
        }
        return true;
    }

    @RequestMapping(params = "sending", method = RequestMethod.POST)
    public void sending(final HttpServletRequest req, final HttpServletResponse resp)
            throws IOException {

        initResponse(resp);

        if (!validate(req, resp)) {
            return;
        }

        User user = GaeUtil.getCurrentUser();
        String from = user.getEmail(); // only support gmail
        String to = req.getParameter("to");
        String subject = req.getParameter("Subject");
        String content = req.getParameter("content");
        Mail mail = new Mail();
        mail.setFrom(from);
        mail.setTo(to);
        mail.setSubject(subject);
        mail.setText(content);
        mail.setMultiPart(StringUtil.isEmpty(req.getParameter("base")));

        StringBuilder sb = new StringBuilder();
        boolean sendOk = MailUtil.sendMail(mail);
        if (!sendOk) {
            sb.append(getMessage("sendFail"));
            sb.append("<a href=\"");
            sb.append(req.getRequestURI());
            sb.append("\">back</a>");
        } else {
            sb.append(getMessage("sendSuccess"));
            sb.append("<a href=\"");
            sb.append("/guestbook.html");
            sb.append("\">return</a>");
        }

        resp.getWriter().println(sb.toString());
    }
}
