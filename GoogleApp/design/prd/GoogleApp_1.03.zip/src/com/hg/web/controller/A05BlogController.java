package com.hg.web.controller;

import java.io.IOException;
import java.io.StringReader;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import com.hg.core.EasyController;
import com.hg.service.ArticleService;
import com.hg.service.CommentService;
import com.hg.service.TypeService;
import com.hg.util.DateUtil;
import com.hg.util.GaeUtil;
import com.hg.util.StringUtil;

import freemarker.template.Template;

@Controller
public class A05BlogController extends EasyController {

    private static Log logger = LogFactory.getLog(A05BlogController.class);

    @Autowired
    private ArticleService articleService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private TypeService typeService;

    @Autowired
    FreeMarkerConfigurer freemarkerConfig;

    @RequestMapping("/blog.html")
    public String main(final HttpServletRequest req, final HttpServletResponse resp, final ModelMap model) throws IOException {
        makeRootMain(req, model);
        return "blog";
    }

    private void makeRootMain(final HttpServletRequest req, final ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Blog");
        model.addAttribute("user", GaeUtil.getCurrentUser());

        int iPage = 0;
        if (!StringUtil.isEmpty(req.getParameter("page"))) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        int maxP = articleService.getMaxPage(req.getParameter("t"), false);
        if (iPage > maxP) {
            iPage = maxP;
        }
        model.addAttribute("currentP", iPage);
        model.addAttribute("maxP", maxP);
        model.addAttribute("articles", articleService.getList(iPage, false, req.getParameter("t")));
        model.addAttribute("latestCmt", commentService.getLatestCmts());
        model.addAttribute("types", typeService.getTypes());
    }

    @RequestMapping("/blogc.html")
    public void content(final HttpServletRequest req, final HttpServletResponse resp, final ModelMap model) throws IOException {

        makeRootContent(req, model);

        Template t = new Template(
                                  "",
                                  new StringReader(
                                                   "<#import \"macro/articlelist.ftl\" as articlelist><@articlelist.page />"),
                                  freemarkerConfig.getConfiguration());
        initResponse(resp);
        try {
            t.process(model, resp.getWriter());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void makeRootContent(final HttpServletRequest req, final ModelMap model) {
        // Build the data-model

        Date zeroClock = DateUtil.getZeroClock(DateUtil.parse(req.getParameter("day"), "yyyyMMdd"));
        Date twentyFourClock = DateUtil.getTwentyFourClock(DateUtil.parse(req.getParameter("day"), "yyyyMMdd"));

        int iPage = 0;
        if (!StringUtil.isEmpty(req.getParameter("page"))) {
            iPage = Integer.parseInt(req.getParameter("page"));
        }
        int maxP = articleService.getMaxPage(zeroClock, twentyFourClock);
        if (iPage > maxP) {
            iPage = maxP;
        }
        model.addAttribute("currentP", iPage);
        model.addAttribute("maxP", maxP);
        model.addAttribute("pagingUrl", "/blogc.html?day=" + req.getParameter("day"));

        model.addAttribute("articles", articleService.getList(iPage, zeroClock, twentyFourClock));
    }

}
