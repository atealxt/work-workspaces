package com.hg.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hg.core.EasyController;

@Controller
public class Z00ReleaseController extends EasyController {

    @RequestMapping("/releasenote.html")
    public String releaseNote(HttpServletRequest req, HttpServletResponse resp, ModelMap model) throws IOException {
        makeRootRelease(req, model);
        return "releasenote";
    }

    private void makeRootRelease(HttpServletRequest req, ModelMap model) {
        // Build the data-model
        model.addAttribute("title", "Release Notes");
    }
}
