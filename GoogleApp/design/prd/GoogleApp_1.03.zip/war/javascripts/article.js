function init(articleId) {
    _updReadCnt(articleId);
    _getComments(articleId);

    $("rep_content").observe('keydown', _submit);
}

function _updReadCnt(articleId) {
    var url = '/article.html?m=updcnt';
    var pars = 'id=' + articleId;
    new Ajax.Request(url, {
        method : 'get',
        parameters : pars
    });
}

function _getComments(articleId) {
    var url = '/comment.html?m=get';
    var pars = 'id=' + articleId;
    new Ajax.Updater('cmt_content', url, {
        method : 'get',
        parameters : pars
    });
}

function setReplyTitle(name) {
    $("rep_content").value = "@" + name + "\n" + $("rep_content").value;
    window.location.href = "#reply";
    $("rep_content").focus();
}

function beforeSubmit() {
    $("yournameErr").style.visibility = "hidden";
    $("rep_contentErr").style.visibility = "hidden";
    if ($("yourname").value.replace(/(^\s*)|(\s*$)/g, '').replace("\r", "\n")
            .replace("\n", "") == "") {
        $("yourname").focus();
        $("yourname").value = "";
        $("yournameErr").style.visibility = "";
        return false;
    } else if ($("rep_content").value.replace(/(^\s*)|(\s*$)/g, '').replace(
            "\r", "\n").replace("\n", "") == "") {
        $("rep_content").focus();
        $("rep_content").value = "";
        $("rep_contentErr").style.visibility = "";
        return false;
    }
    if ($("title").value.replace(/(^\s*)|(\s*$)/g, '') == "") {
        $("title").value = "Re: " + $("h2title").innerHTML;
    }

    cmnApi.disableWhenSubmiting($("submit"));
    return true;
}

function _submit(k) {
    if (!k.ctrlKey || k.keyCode != 13) {
        return;
    }
    $("submit").click();
}
