package test.base64;

import java.io.IOException;

/**
 * 用Base64来传递url是为了在某些场合请求url时避免非法字符。但不能解决URL超长问题。
 */
public class UrlTransport {

    public static void main(final String args[]) {

        transParamInUrl();

    }

    private static void transParamInUrl() {

        String url = "http://atealxt.appspot.com/guestbook?p=";

        String p = "a=1&b=2&c=3&d=你好&最后一个参数=haha";
        url += Base64.encodeBytes(p.getBytes());

        System.out.println(url);

        // 通常以上部分由js来拼装

        String encodedParams = url.substring(url.indexOf("?p=") + 3);
        System.out.println(encodedParams);
        try {
            System.out.println(new String(Base64.decode(encodedParams)));
        } catch (IOException e) {
            e.printStackTrace();
        }

        /*
         * TODO 如果URL过长怎么办？
         * 1、先用response.write输出HTML表单，然后在客户端浏览器的页面onload事件里用脚本提交这个表单。
         * 2、在后台post，取得返回结果后直接打印输出。
         * 3、共享2个项目的session。在项目A里把url的参数放在session里，然后url里只拼一个sessionid。在项目B里取。
         *
         * 参考url
         * http://benlsoft.javaeye.com/blog/97059
         * http://topic.csdn.net/t/20060321/17/4629804.html
         * http://forums.devshed.com/java-help-9/sendredirect-using-post-48616.html
         * http://www.coderanch.com/t/365770/Servlets/java/sendRedirect-fails-post-data-along
         */

    }
}
